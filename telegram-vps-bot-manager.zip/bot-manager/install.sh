#!/usr/bin/env bash
# Fresh Debian/Ubuntu VPS setup for the Telegram VPS Bot Manager.
# Safe to re-run — every step checks before it changes anything.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "== VPS Bot Manager setup =="

# --- 1. Python check -------------------------------------------------
if ! command -v python3 >/dev/null 2>&1; then
    echo "python3 not found. Install Python 3.11+ before continuing." >&2
    exit 1
fi
PY_VERSION="$(python3 -c 'import sys; print(f"{sys.version_info[0]}.{sys.version_info[1]}")')"
echo "Found Python $PY_VERSION"

# --- 2. OS packages ----------------------------------------------------
if command -v apt-get >/dev/null 2>&1; then
    echo "Checking required OS packages (python3-venv, python3-pip)..."
    MISSING=()
    dpkg -s python3-venv >/dev/null 2>&1 || MISSING+=("python3-venv")
    dpkg -s python3-pip  >/dev/null 2>&1 || MISSING+=("python3-pip")
    if [ "${#MISSING[@]}" -gt 0 ]; then
        echo "Installing: ${MISSING[*]}"
        sudo apt-get update -y
        sudo apt-get install -y "${MISSING[@]}"
    fi
else
    echo "Non-Debian system detected — please make sure python3-venv and pip are available."
fi

# --- 3. venv module sanity check ---------------------------------------
python3 -m venv --help >/dev/null 2>&1 || { echo "python3 -m venv is not available." >&2; exit 1; }

# --- 4. Project directories ---------------------------------------------
mkdir -p managed_bots database logs backups

# --- 5. Manager's own virtual environment --------------------------------
if [ ! -d ".venv" ]; then
    echo "Creating manager virtual environment..."
    python3 -m venv .venv
fi
echo "Installing manager dependencies..."
.venv/bin/pip install --disable-pip-version-check -q -r requirements.txt

# --- 6. .env setup ---------------------------------------------------------
if [ ! -f ".env" ]; then
    cp .env.example .env
    echo
    echo "!! Created .env from template. Edit it now and set BOT_TOKEN and ADMIN_IDS:"
    echo "   nano $SCRIPT_DIR/.env"
    echo
fi

# --- 7. systemd unit for the manager itself --------------------------------
read -rp "Install a systemd service for the manager bot? [y/N] " ans
if [[ "${ans:-N}" =~ ^[Yy]$ ]]; then
    UNIT_PATH="/etc/systemd/system/nyx-bot-manager.service"
    RUN_USER="$(whoami)"
    sudo tee "$UNIT_PATH" >/dev/null <<EOF
[Unit]
Description=VPS Bot Manager (Telegram)
After=network.target

[Service]
Type=simple
User=${RUN_USER}
WorkingDirectory=${SCRIPT_DIR}
ExecStart=${SCRIPT_DIR}/.venv/bin/python -m app.bot
Restart=on-failure
RestartSec=5
EnvironmentFile=${SCRIPT_DIR}/.env

[Install]
WantedBy=multi-user.target
EOF
    sudo systemctl daemon-reload
    sudo systemctl enable nyx-bot-manager.service
    echo "Service installed. Edit .env, then run:"
    echo "   sudo systemctl start nyx-bot-manager"
else
    echo "Skipped. You can start the manager manually with:"
    echo "   .venv/bin/python -m app.bot"
fi

echo
echo "== Setup complete =="

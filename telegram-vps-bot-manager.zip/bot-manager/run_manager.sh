#!/usr/bin/env bash
# Keeps the manager bot alive WITHOUT systemd/root.
# Start it detached so it survives closing this terminal:
#
#   nohup ./run_manager.sh > /dev/null 2>&1 & disown
#
# Stop it with ./stop_manager.sh — don't just Ctrl+C this script from
# a terminal you're about to close, or use stop_manager.sh instead.
set -u
cd "$(dirname "${BASH_SOURCE[0]}")"
mkdir -p logs

echo "$$" > logs/watchdog.pid
echo "$(date '+%F %T') watchdog started (pid $$)" >> logs/watchdog.log

while true; do
    echo "$(date '+%F %T') starting manager" >> logs/watchdog.log
    .venv/bin/python -m app.bot >> logs/manager_stdout.log 2>&1
    code=$?
    echo "$(date '+%F %T') manager exited (code $code) — restarting in 5s" >> logs/watchdog.log
    sleep 5
done

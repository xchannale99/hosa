# VPS Bot Manager (Telegram)

Manage every Python/Telegram bot on your VPS from one Telegram bot —
install, start/stop/restart, view logs, watch CPU/RAM, and get crash
notifications, all without SSH.

## 1. Requirements

- A Debian/Ubuntu VPS with `systemd`
- Python 3.11+
- A Telegram bot token from [@BotFather](https://t.me/BotFather)
- Your numeric Telegram user ID (from [@userinfobot](https://t.me/userinfobot) or similar)

## 2. VPS preparation

```bash
git clone <this-repo> bot-manager
cd bot-manager
```

(Or upload the project as a zip and extract it.)

## 3. Installation

```bash
./install.sh
```

This checks Python, installs `python3-venv`/`python3-pip` if missing,
creates the manager's own virtual environment, installs its
dependencies, and copies `.env.example` to `.env`.

## 4. `.env` configuration

Edit `.env`:

```
BOT_TOKEN=123456:your-bot-token
ADMIN_IDS=111111111,222222222
BASE_DIR=/home/nyx/bot-manager
```

`BASE_DIR` must be the absolute path where you cloned/extracted this project.

## 5. Bot token setup

Talk to [@BotFather](https://t.me/BotFather) → `/newbot` → copy the token into `BOT_TOKEN`.

## 6. Admin ID setup

Only user IDs listed in `ADMIN_IDS` (comma-separated) can use the
manager. Everyone else is silently refused — no bot names or data are
ever shown to them.

## 7. Start the manager

If you let `install.sh` create the systemd service:

```bash
sudo systemctl start nyx-bot-manager
```

Otherwise, run it directly:

```bash
.venv/bin/python -m app.bot
```

## 8. Stop the manager

```bash
sudo systemctl stop nyx-bot-manager
```

## 9. Restart the manager

```bash
sudo systemctl restart nyx-bot-manager
```

## 10. View manager logs

```bash
tail -f logs/manager.log
# or, if running under systemd:
journalctl -u nyx-bot-manager -f
```

## 11. Add a managed bot

In Telegram: **➕ Add Bot** → send a `.zip` of your bot's source
(including `requirements.txt` if it has dependencies) → confirm →
name it → the manager extracts it, creates an isolated virtual
environment, installs dependencies, detects (or asks you to pick) the
entry file, creates a dedicated `systemd` service, and starts it.

## 12. Update a bot

Open the bot → **⚙️ Settings** → **🔄 Update Bot** → send a new `.zip`.
The manager stops the bot, backs up the current version, applies the
update, and restarts it — rolling back automatically if the update
fails.

## 13. Delete a bot

Open the bot → **🗑️ Delete** → confirm twice (including typing
`DELETE`). This removes its source, virtual environment, logs, and
systemd service permanently.

## 14. Troubleshooting

- **Bot won't start / fails health check** — check **📜 Logs** on the
  bot's panel, or `journalctl -u nyx-bot-<id>`.
- **"Permission denied" on systemctl** — the manager needs either to
  run as root, or as a user with a sudoers rule limited to
  `systemctl {start,stop,restart,enable,disable,daemon-reload,show,reset-failed}
  nyx-bot-*.service` (set `SYSTEMD_USE_SUDO=true` in `.env` in that
  case).
- **`requirements.txt` install fails** — the full pip error is shown
  in the install progress message; each bot's dependencies are
  isolated to its own `venv/`, so a broken bot never affects another.

## 15. Security recommendations

- Keep `ADMIN_IDS` limited to people who should have VPS-level control
  — this bot can install and run arbitrary code you upload.
- Never commit `.env` (it's already in `.gitignore`).
- If running the manager as a non-root user, restrict its `sudo`
  rule to exactly the `systemctl` subcommands above — nothing else.
- There is intentionally no `/run <command>` or shell-access feature.
  All operations go through a fixed, whitelisted set of actions
  (`start_bot`, `stop_bot`, `restart_bot`, `install_requirements`,
  `delete_bot`, ...) — the manager never executes arbitrary shell
  input from Telegram.
- Uploaded ZIPs are validated for path traversal, symlinks, size
  limits, and suspicious compression ratios before extraction.
- Every sensitive action is written to `audit_logs` (viewable via
  **🛠️ Tools → 📜 Audit Log**) and to `logs/audit.log`.
- Environment variable values are masked in the UI and never printed
  to logs.

## Project layout

```
bot-manager/
├── app/
│   ├── bot.py              entrypoint
│   ├── config.py           .env loading
│   ├── database.py         SQLite (bots, audit_logs)
│   ├── emoji.py            premium custom-emoji system
│   ├── logging_setup.py    manager/security/audit log files
│   ├── handlers/           Telegram command & callback handlers
│   ├── keyboards/          inline keyboard builders + callback_data
│   ├── services/           systemd, installer, logs, stats, backups
│   ├── middleware/         admin-only auth gate
│   └── utils/              validators, formatting, security, FSM states
├── managed_bots/           one directory per installed bot (source/venv/logs)
├── database/manager.db
├── logs/                   manager.log, security.log, audit.log
├── backups/
├── install.sh
└── .env.example
```

## Extending it

The architecture is intentionally modular — `services/` holds all the
logic, `handlers/` only wires Telegram UI to it. Adding a new feature
(Docker support, GitHub deploy, multi-VPS, scheduled backups, etc.)
means adding a new service + handler pair without touching existing
ones.

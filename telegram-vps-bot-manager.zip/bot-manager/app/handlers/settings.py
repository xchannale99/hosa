from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from app.keyboards.actions import (
    backup_list_keyboard,
    env_list_keyboard,
    settings_keyboard,
    update_confirm_keyboard,
)
from app.keyboards.bots import bot_detail_keyboard
from app.keyboards.reply_menu import MAIN_MENU_LABELS
from app.keyboards.callback_data import AutoRestartToggle, BackupAction, BotAction, EnvAction, SettingsAction, UpdateBotAction
from app.services.backup_manager import BackupError, BackupManager
from app.services.bot_manager import BotManager, BotManagerError
from app.utils.states import EnvVarFSM, SettingsFSM, UpdateBotFSM

router = Router(name="settings")


def _settings_text(bot) -> str:
    return (
        f"⚙️ <b>Settings — {bot.name}</b>\n\n"
        f"📄 Main File: {bot.main_file}\n"
        f"📝 Description: {bot.description or '(none)'}\n"
        f"🔄 Auto Restart: {'ON' if bot.auto_restart else 'OFF'}"
    )


@router.callback_query(BotAction.filter(F.action == "settings"))
async def open_settings(callback: CallbackQuery, callback_data: BotAction, bot_manager: BotManager) -> None:
    bot = await bot_manager.db.get_bot(callback_data.bot_id)
    if bot is None:
        await callback.answer("Bot not found.", show_alert=True)
        return
    await callback.message.edit_text(_settings_text(bot), reply_markup=settings_keyboard(bot))
    await callback.answer()


@router.callback_query(SettingsAction.filter(F.action == "back"))
async def settings_back(callback: CallbackQuery, callback_data: SettingsAction, bot_manager: BotManager) -> None:
    bot = await bot_manager.db.get_bot(callback_data.bot_id)
    if bot is None:
        await callback.answer("Bot not found.", show_alert=True)
        return
    await callback.message.edit_text(_settings_text(bot), reply_markup=settings_keyboard(bot))
    await callback.answer()


@router.callback_query(AutoRestartToggle.filter())
async def toggle_auto_restart(callback: CallbackQuery, callback_data: AutoRestartToggle, bot_manager: BotManager) -> None:
    enabled = callback_data.value == "on"
    await bot_manager.toggle_auto_restart(callback_data.bot_id, enabled)
    await bot_manager.db.log_audit(
        admin_id=callback.from_user.id, action="auto_restart_toggle",
        bot_id=callback_data.bot_id, result="on" if enabled else "off",
    )
    bot = await bot_manager.db.get_bot(callback_data.bot_id)
    await callback.message.edit_text(_settings_text(bot), reply_markup=settings_keyboard(bot))
    await callback.answer("🔄 Auto Restart updated.")


# ------------------------------------------------------------ rename/describe

@router.callback_query(SettingsAction.filter(F.action == "rename"))
async def ask_rename(callback: CallbackQuery, callback_data: SettingsAction, state: FSMContext) -> None:
    await state.update_data(target_bot_id=callback_data.bot_id)
    await state.set_state(SettingsFSM.waiting_for_new_name)
    await callback.message.edit_text("Send the new name for this bot.")
    await callback.answer()


@router.message(SettingsFSM.waiting_for_new_name, F.text, ~F.text.in_(MAIN_MENU_LABELS))
async def do_rename(message: Message, state: FSMContext, bot_manager: BotManager) -> None:
    data = await state.get_data()
    bot_id = data["target_bot_id"]
    name = message.text.strip()[:64]
    await bot_manager.db.update_bot(bot_id, name=name)
    await state.clear()
    bot = await bot_manager.db.get_bot(bot_id)
    await message.answer(_settings_text(bot), reply_markup=settings_keyboard(bot))


@router.callback_query(SettingsAction.filter(F.action == "describe"))
async def ask_describe(callback: CallbackQuery, callback_data: SettingsAction, state: FSMContext) -> None:
    await state.update_data(target_bot_id=callback_data.bot_id)
    await state.set_state(SettingsFSM.waiting_for_new_description)
    await callback.message.edit_text("Send a short description for this bot.")
    await callback.answer()


@router.message(SettingsFSM.waiting_for_new_description, F.text, ~F.text.in_(MAIN_MENU_LABELS))
async def do_describe(message: Message, state: FSMContext, bot_manager: BotManager) -> None:
    data = await state.get_data()
    bot_id = data["target_bot_id"]
    await bot_manager.db.update_bot(bot_id, description=message.text.strip()[:256])
    await state.clear()
    bot = await bot_manager.db.get_bot(bot_id)
    await message.answer(_settings_text(bot), reply_markup=settings_keyboard(bot))


# ------------------------------------------------------------------ env vars

@router.callback_query(SettingsAction.filter(F.action == "env"))
async def open_env(callback: CallbackQuery, callback_data: SettingsAction, bot_manager: BotManager) -> None:
    env = await bot_manager.list_env_masked(callback_data.bot_id)
    if env:
        body = "\n".join(f"{k} = {v}" for k, v in env.items())
    else:
        body = "(no environment variables set)"
    text = f"🌐 <b>Environment</b>\n\n{body}\n\nTap a variable to delete it."
    await callback.message.edit_text(text, reply_markup=env_list_keyboard(callback_data.bot_id, list(env.keys())))
    await callback.answer()


@router.callback_query(EnvAction.filter(F.action == "add"))
async def ask_env_key(callback: CallbackQuery, callback_data: EnvAction, state: FSMContext) -> None:
    await state.update_data(target_bot_id=callback_data.bot_id)
    await state.set_state(EnvVarFSM.waiting_for_key)
    await callback.message.edit_text("Send the variable name (e.g. <code>API_KEY</code>).")
    await callback.answer()


@router.message(EnvVarFSM.waiting_for_key, F.text, ~F.text.in_(MAIN_MENU_LABELS))
async def receive_env_key(message: Message, state: FSMContext) -> None:
    await state.update_data(env_key=message.text.strip())
    await state.set_state(EnvVarFSM.waiting_for_value)
    await message.answer("Now send the value.")


@router.message(EnvVarFSM.waiting_for_value, F.text, ~F.text.in_(MAIN_MENU_LABELS))
async def receive_env_value(message: Message, state: FSMContext, bot_manager: BotManager) -> None:
    data = await state.get_data()
    bot_id = data["target_bot_id"]
    key = data["env_key"]
    try:
        await bot_manager.set_env(bot_id, key, message.text.strip())
    except BotManagerError as exc:
        await message.answer(f"❌ {exc}")
        await state.clear()
        return
    await state.clear()
    await bot_manager.db.log_audit(admin_id=message.from_user.id, action="env_set", bot_id=bot_id, result="success")
    await message.answer(f"✅ {key} saved. Restart the bot to apply it.")
    env = await bot_manager.list_env_masked(bot_id)
    text = "🌐 <b>Environment</b>\n\n" + "\n".join(f"{k} = {v}" for k, v in env.items())
    await message.answer(text, reply_markup=env_list_keyboard(bot_id, list(env.keys())))


@router.callback_query(EnvAction.filter(F.action == "delete"))
async def delete_env_var(callback: CallbackQuery, callback_data: EnvAction, bot_manager: BotManager) -> None:
    env = await bot_manager.list_env(callback_data.bot_id)
    keys = list(env.keys())
    if 0 <= callback_data.idx < len(keys):
        key = keys[callback_data.idx]
        await bot_manager.delete_env(callback_data.bot_id, key)
        await bot_manager.db.log_audit(
            admin_id=callback.from_user.id, action="env_delete", bot_id=callback_data.bot_id, result="success"
        )
    env = await bot_manager.list_env_masked(callback_data.bot_id)
    body = "\n".join(f"{k} = {v}" for k, v in env.items()) or "(no environment variables set)"
    text = f"🌐 <b>Environment</b>\n\n{body}"
    await callback.message.edit_text(text, reply_markup=env_list_keyboard(callback_data.bot_id, list(env.keys())))
    await callback.answer("Deleted.")


# -------------------------------------------------------------------- update

@router.callback_query(UpdateBotAction.filter(F.action == "start"))
async def start_update(callback: CallbackQuery, callback_data: UpdateBotAction, state: FSMContext) -> None:
    await state.update_data(update_bot_id=callback_data.bot_id)
    await state.set_state(UpdateBotFSM.waiting_for_zip)
    await callback.message.edit_text(
        "🔄 <b>Update Bot</b>\n\nSend the new ZIP file. The bot will be stopped, "
        "backed up, updated, and restarted."
    )
    await callback.answer()


@router.message(UpdateBotFSM.waiting_for_zip, F.document)
async def update_receive_zip(message: Message, state: FSMContext) -> None:
    doc = message.document
    if not doc.file_name.lower().endswith(".zip"):
        await message.answer("Please send a .zip file.")
        return
    await state.update_data(update_file_id=doc.file_id)
    data = await state.get_data()
    await message.answer(
        f"📦 {doc.file_name} received. Proceed with update?",
        reply_markup=update_confirm_keyboard(data["update_bot_id"]),
    )


@router.callback_query(UpdateBotAction.filter(F.action == "cancel"))
async def update_cancel(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    await callback.message.edit_text("Update cancelled.")
    await callback.answer()


@router.callback_query(UpdateBotAction.filter(F.action == "confirm"))
async def update_confirm(callback: CallbackQuery, callback_data: UpdateBotAction, state: FSMContext, bot_manager: BotManager, backup_manager: BackupManager) -> None:
    bot_id = callback_data.bot_id
    data = await state.get_data()
    file_id = data.get("update_file_id")
    await state.clear()

    bot = await bot_manager.db.get_bot(bot_id)
    if bot is None or file_id is None:
        await callback.answer("Nothing to update.", show_alert=True)
        return

    msg = callback.message
    await msg.edit_text("🔄 Updating...\n\n⏳ Stopping bot...")
    try:
        await bot_manager.stop_bot(bot_id)
    except BotManagerError:
        pass

    await msg.edit_text("🔄 Updating...\n\n✅ Stopped\n⏳ Backing up current version...")
    try:
        await backup_manager.create_backup(bot)
    except Exception:  # noqa: BLE001 - backup failure shouldn't block the update
        pass

    tg_file = await callback.bot.get_file(file_id)
    buf = await callback.bot.download_file(tg_file.file_path)
    zip_bytes = buf.read()

    lines = ["🔄 <b>Updating...</b>\n", "✅ Stopped", "✅ Backed up"]
    ok = True
    async for step in bot_manager.installer.install_bot(bot_id, zip_bytes):
        icon = "✅" if step.ok else "❌"
        lines.append(f"{icon} {step.label}")
        await msg.edit_text("\n".join(lines))
        if not step.ok:
            ok = False
            lines.append(f"\nError:\n<code>{step.detail[:500]}</code>\n\nRolling back...")
            await msg.edit_text("\n".join(lines))
            backups = backup_manager.list_backups(bot_id)
            if backups:
                await backup_manager.restore_backup(backups[0], bot_manager.installer.bot_dir(bot_id) / "source")
            try:
                await bot_manager.start_bot(bot_id)
            except BotManagerError:
                pass
            break

    if not ok:
        await bot_manager.db.log_audit(admin_id=callback.from_user.id, action="update", bot_id=bot_id, result="rolled_back")
        await callback.answer()
        return

    candidates = bot_manager.detect_main_files(bot_id)
    main_file = bot.main_file if bot.main_file in candidates else (candidates[0] if candidates else bot.main_file)
    ok, reason = await bot_manager.finalize_install(bot_id, main_file)
    await bot_manager.db.log_audit(
        admin_id=callback.from_user.id, action="update", bot_id=bot_id,
        result="success" if ok else "error", detail=reason,
    )
    tail = "\n🚀 Update complete, bot restarted." if ok else f"\n❌ Bot failed health check: {reason}"
    await msg.edit_text("\n".join(lines) + tail)
    await callback.answer()


# ------------------------------------------------------------------- backups

@router.callback_query(BackupAction.filter(F.action == "create"))
async def create_backup(callback: CallbackQuery, callback_data: BackupAction, bot_manager: BotManager, backup_manager: BackupManager) -> None:
    bot = await bot_manager.db.get_bot(callback_data.bot_id)
    if bot is None:
        await callback.answer("Bot not found.", show_alert=True)
        return
    path = await backup_manager.create_backup(bot)
    await bot_manager.db.log_audit(admin_id=callback.from_user.id, action="backup_create", bot_id=bot.id, result="success")
    await callback.answer(f"💾 Backup saved: {path.name}", show_alert=True)


@router.callback_query(BackupAction.filter(F.action == "list"))
async def list_backups(callback: CallbackQuery, callback_data: BackupAction, backup_manager: BackupManager) -> None:
    backups = backup_manager.list_backups(callback_data.bot_id)
    if not backups:
        await callback.answer("No backups yet.", show_alert=True)
        return
    text = "♻️ <b>Restore Backup</b>\n\n" + "\n".join(f"{i+1}. {b.name}" for i, b in enumerate(backups))
    await callback.message.edit_text(text, reply_markup=backup_list_keyboard(callback_data.bot_id, len(backups)))
    await callback.answer()


@router.callback_query(BackupAction.filter(F.action == "restore"))
async def restore_backup(callback: CallbackQuery, callback_data: BackupAction, bot_manager: BotManager, backup_manager: BackupManager) -> None:
    bot = await bot_manager.db.get_bot(callback_data.bot_id)
    backups = backup_manager.list_backups(callback_data.bot_id)
    if bot is None or not (0 <= callback_data.idx < len(backups)):
        await callback.answer("Backup not found.", show_alert=True)
        return
    try:
        await bot_manager.stop_bot(bot.id)
    except BotManagerError:
        pass
    try:
        await backup_manager.restore_backup(backups[callback_data.idx], bot_manager.installer.bot_dir(bot.id) / "source")
    except BackupError as exc:
        await callback.answer(str(exc), show_alert=True)
        return
    try:
        await bot_manager.start_bot(bot.id)
    except BotManagerError:
        pass
    await bot_manager.db.log_audit(admin_id=callback.from_user.id, action="backup_restore", bot_id=bot.id, result="success")
    await callback.answer("♻️ Restored & restarted.", show_alert=True)

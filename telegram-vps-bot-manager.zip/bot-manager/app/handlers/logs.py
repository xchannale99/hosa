from aiogram import F, Router
from aiogram.types import CallbackQuery, FSInputFile

from app.keyboards.actions import logs_keyboard
from app.keyboards.callback_data import BotAction, LogsAction
from app.services.bot_manager import BotManager
from app.utils.formatting import truncate

router = Router(name="logs")


async def _render_logs(callback: CallbackQuery, bot_manager: BotManager, bot_id: str, lines: int) -> None:
    bot = await bot_manager.db.get_bot(bot_id)
    if bot is None:
        await callback.answer("Bot not found.", show_alert=True)
        return
    content = await bot_manager.logs.tail(bot_id, lines)
    text = f"📜 <b>Bot Logs — {bot.name}</b>\n\nShowing last {lines} lines...\n\n<code>{truncate(content, 3500)}</code>"
    await callback.message.edit_text(text, reply_markup=logs_keyboard(bot_id, lines))


@router.callback_query(BotAction.filter(F.action == "logs"))
async def open_logs(callback: CallbackQuery, callback_data: BotAction, bot_manager: BotManager) -> None:
    await _render_logs(callback, bot_manager, callback_data.bot_id, 50)
    await callback.answer()


@router.callback_query(LogsAction.filter(F.action.in_({"refresh", "more"})))
async def refresh_logs(callback: CallbackQuery, callback_data: LogsAction, bot_manager: BotManager) -> None:
    await _render_logs(callback, bot_manager, callback_data.bot_id, callback_data.lines)
    await callback.answer("Refreshed" if callback_data.action == "refresh" else None)


@router.callback_query(LogsAction.filter(F.action == "download"))
async def download_logs(callback: CallbackQuery, callback_data: LogsAction, bot_manager: BotManager) -> None:
    path = await bot_manager.logs.export_path(callback_data.bot_id)
    if not path.exists() or path.stat().st_size == 0:
        await callback.answer("No logs to download yet.", show_alert=True)
        return
    bot = await bot_manager.db.get_bot(callback_data.bot_id)
    filename = f"{(bot.slug if bot else callback_data.bot_id)}.log.txt"
    await callback.message.answer_document(FSInputFile(path, filename=filename))
    await callback.answer()


@router.callback_query(LogsAction.filter(F.action == "clear"))
async def clear_logs(callback: CallbackQuery, callback_data: LogsAction, bot_manager: BotManager) -> None:
    await bot_manager.logs.clear(callback_data.bot_id)
    await bot_manager.db.log_audit(
        admin_id=callback.from_user.id, action="clear_logs", bot_id=callback_data.bot_id, result="success"
    )
    await _render_logs(callback, bot_manager, callback_data.bot_id, callback_data.lines)
    await callback.answer("🧹 Logs cleared.")

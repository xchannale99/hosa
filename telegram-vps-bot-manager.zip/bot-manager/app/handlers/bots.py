from aiogram import F, Router
from aiogram.types import CallbackQuery, Message

from app.database import BotRecord
from app.emoji import render_char
from app.keyboards.actions import delete_confirm_keyboard
from app.keyboards.reply_menu import MAIN_MENU_LABELS
from app.keyboards.bots import bot_detail_keyboard, bots_list_keyboard
from app.keyboards.callback_data import BotAction, BotOpen, BotsPage, ConfirmDelete, MenuNav
from app.keyboards.main_menu import back_button
from app.services.bot_manager import BotManager, BotManagerError
from app.services.process_manager import ProcessStats
from app.services.systemd_manager import UnitStatus
from app.utils.formatting import human_duration_short, status_dot
from app.utils.states import DeleteBotFSM
from aiogram.fsm.context import FSMContext

router = Router(name="bots")


def _list_text(bots: list[BotRecord]) -> str:
    if not bots:
        return "🤖 <b>My Bots</b>\n\nNo bots installed yet. Tap ➕ Add Bot to install your first one."
    lines = [f"{status_dot(b.status)} {b.name}" for b in bots]
    return "🤖 <b>My Bots</b>\n\n" + "\n".join(lines)


@router.callback_query(MenuNav.filter(F.target == "mybots"))
async def nav_mybots(callback: CallbackQuery, bot_manager: BotManager) -> None:
    bots = await bot_manager.list_bots()
    await callback.message.edit_text(_list_text(bots), reply_markup=bots_list_keyboard(bots, page=0))
    await callback.answer()


@router.message(F.text == "🤖 My Bots")
async def reply_mybots(message: Message, state: FSMContext, bot_manager: BotManager) -> None:
    await state.clear()
    bots = await bot_manager.list_bots()
    await message.answer(_list_text(bots), reply_markup=bots_list_keyboard(bots, page=0))


@router.callback_query(BotsPage.filter())
async def nav_bots_page(callback: CallbackQuery, callback_data: BotsPage, bot_manager: BotManager) -> None:
    bots = await bot_manager.list_bots()
    await callback.message.edit_text(
        _list_text(bots), reply_markup=bots_list_keyboard(bots, page=callback_data.page)
    )
    await callback.answer()


def _detail_text(status: BotRecord, unit: UnitStatus | None = None, process: ProcessStats | None = None) -> str:
    lines = [f"🤖 <b>{status.name}</b>\n", f"Status: {status_dot(status.status)} {status.status.title()}"]
    if process and process.alive:
        lines.append(f"PID: {process.pid}")
        lines.append(f"CPU: {process.cpu_percent:.1f}%")
        lines.append(f"RAM: {process.ram_mb:.0f} MB")
        lines.append(f"Uptime: {human_duration_short(process.uptime_seconds)}")
    lines.append(f"Auto Restart: {'🔄 ON' if status.auto_restart else '⏸️ OFF'}")
    if status.restart_count:
        lines.append(f"Restarts: {status.restart_count}")
    return "\n".join(lines)


@router.callback_query(BotOpen.filter())
async def open_bot(callback: CallbackQuery, callback_data: BotOpen, bot_manager: BotManager) -> None:
    try:
        full = await bot_manager.get_full_status(callback_data.bot_id)
    except BotManagerError as exc:
        await callback.answer(str(exc), show_alert=True)
        return
    await callback.message.edit_text(
        _detail_text(full.record, full.unit, full.process),
        reply_markup=bot_detail_keyboard(full.record),
    )
    await callback.answer()


@router.callback_query(BotAction.filter(F.action == "back"))
async def back_to_detail(callback: CallbackQuery, callback_data: BotAction, bot_manager: BotManager) -> None:
    try:
        full = await bot_manager.get_full_status(callback_data.bot_id)
    except BotManagerError as exc:
        await callback.answer(str(exc), show_alert=True)
        return
    await callback.message.edit_text(
        _detail_text(full.record, full.unit, full.process),
        reply_markup=bot_detail_keyboard(full.record),
    )
    await callback.answer()


@router.callback_query(BotAction.filter(F.action.in_({"start", "stop", "restart"})))
async def bot_lifecycle_action(callback: CallbackQuery, callback_data: BotAction, bot_manager: BotManager) -> None:
    action = callback_data.action
    bot_id = callback_data.bot_id
    admin_id = callback.from_user.id

    verbs = {"start": "started", "stop": "stopped", "restart": "restarted"}
    try:
        if action == "start":
            await bot_manager.start_bot(bot_id)
        elif action == "stop":
            await bot_manager.stop_bot(bot_id)
        else:
            await bot_manager.restart_bot(bot_id)
        await bot_manager.db.log_audit(admin_id=admin_id, action=action, bot_id=bot_id, result="success")
        await callback.answer(f"{render_char('success')} Bot {verbs[action]}.")
    except BotManagerError as exc:
        await bot_manager.db.log_audit(admin_id=admin_id, action=action, bot_id=bot_id, result="error", detail=str(exc))
        await callback.answer(str(exc), show_alert=True)
        return
    except Exception as exc:  # noqa: BLE001 - surfaced to admin, not a stack trace
        await bot_manager.db.log_audit(admin_id=admin_id, action=action, bot_id=bot_id, result="error", detail=str(exc))
        await callback.answer(f"❌ {action} failed: {exc}", show_alert=True)
        return

    full = await bot_manager.get_full_status(bot_id)
    await callback.message.edit_text(
        _detail_text(full.record, full.unit, full.process),
        reply_markup=bot_detail_keyboard(full.record),
    )


# ------------------------------------------------------------------- delete

@router.callback_query(ConfirmDelete.filter(F.step == "ask"))
async def delete_ask(callback: CallbackQuery, callback_data: ConfirmDelete, bot_manager: BotManager) -> None:
    bot = await bot_manager.db.get_bot(callback_data.bot_id)
    if bot is None:
        await callback.answer("Bot not found.", show_alert=True)
        return
    text = (
        f"⚠️ <b>Delete Bot</b>\n\n"
        f"Bot:\n{bot.name}\n\n"
        f"This will remove:\n"
        f"• Source files\n• Virtual environment\n• Logs\n• Service configuration\n\n"
        f"Are you sure?"
    )
    await callback.message.edit_text(text, reply_markup=delete_confirm_keyboard(bot.id))
    await callback.answer()


@router.callback_query(ConfirmDelete.filter(F.step == "no"))
async def delete_cancel(callback: CallbackQuery, callback_data: ConfirmDelete, bot_manager: BotManager) -> None:
    full = await bot_manager.get_full_status(callback_data.bot_id)
    await callback.message.edit_text(
        _detail_text(full.record, full.unit, full.process),
        reply_markup=bot_detail_keyboard(full.record),
    )
    await callback.answer("Cancelled.")


@router.callback_query(ConfirmDelete.filter(F.step == "yes"))
async def delete_step2(callback: CallbackQuery, callback_data: ConfirmDelete, state: FSMContext) -> None:
    await state.update_data(delete_bot_id=callback_data.bot_id)
    await state.set_state(DeleteBotFSM.waiting_for_confirm_text)
    await callback.message.edit_text(
        "Type <b>DELETE</b> to confirm.",
        reply_markup=back_button("mybots"),
    )
    await callback.answer()


@router.message(DeleteBotFSM.waiting_for_confirm_text, ~F.text.in_(MAIN_MENU_LABELS))
async def delete_confirm_text(message, state: FSMContext, bot_manager: BotManager) -> None:
    data = await state.get_data()
    bot_id = data.get("delete_bot_id")
    await state.clear()

    if (message.text or "").strip() != "DELETE":
        await message.answer("Cancelled — confirmation text did not match.")
        return

    bot = await bot_manager.db.get_bot(bot_id)
    name = bot.name if bot else bot_id
    try:
        await bot_manager.delete_bot(bot_id)
        await bot_manager.db.log_audit(admin_id=message.from_user.id, action="delete", bot_id=bot_id, result="success")
        await message.answer(f"🗑️ <b>{name}</b> has been deleted.")
    except BotManagerError as exc:
        await bot_manager.db.log_audit(admin_id=message.from_user.id, action="delete", bot_id=bot_id, result="error", detail=str(exc))
        await message.answer(f"❌ {exc}")

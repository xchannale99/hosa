from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from app.config import Settings
from app.keyboards.actions import install_confirm_keyboard, main_file_keyboard
from app.keyboards.callback_data import InstallConfirm, MainFileChoice, MenuNav
from app.keyboards.main_menu import back_button
from app.services.bot_manager import BotManager
from app.utils.formatting import human_size
from app.utils.states import AddBotFSM

router = Router(name="upload")


@router.callback_query(MenuNav.filter(F.target == "addbot"))
async def start_add_bot(callback: CallbackQuery, state: FSMContext) -> None:
    await state.set_state(AddBotFSM.waiting_for_zip)
    await callback.message.edit_text(
        "➕ <b>Add New Bot</b>\n\nSend your bot ZIP file.",
        reply_markup=back_button("dashboard"),
    )
    await callback.answer()


@router.message(AddBotFSM.waiting_for_zip, F.document)
async def receive_zip(message: Message, state: FSMContext, settings: Settings) -> None:
    doc = message.document
    if not doc.file_name.lower().endswith(".zip"):
        await message.answer("Please send a <b>.zip</b> file.")
        return
    if doc.file_size and doc.file_size > settings.max_upload_size_bytes:
        limit_mb = settings.max_upload_size_bytes // (1024 * 1024)
        await message.answer(f"❌ File too large. Limit is {limit_mb} MB.")
        return

    await state.update_data(file_id=doc.file_id, file_name=doc.file_name, file_size=doc.file_size or 0)
    await state.set_state(AddBotFSM.waiting_for_confirm)
    await message.answer(
        f"📦 File: {doc.file_name}\n📏 Size: {human_size(doc.file_size or 0)}\n\nContinue?",
        reply_markup=install_confirm_keyboard(),
    )


@router.message(AddBotFSM.waiting_for_zip)
async def receive_zip_wrong_type(message: Message) -> None:
    await message.answer("Please upload your bot as a <b>.zip</b> file attachment.")


@router.callback_query(AddBotFSM.waiting_for_confirm, InstallConfirm.filter(F.value == "no"))
async def cancel_install(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    from app.keyboards.main_menu import main_menu_keyboard
    await callback.message.edit_text("Cancelled.", reply_markup=main_menu_keyboard())
    await callback.answer()


@router.callback_query(AddBotFSM.waiting_for_confirm, InstallConfirm.filter(F.value == "yes"))
async def confirm_install(callback: CallbackQuery, state: FSMContext) -> None:
    await state.set_state(AddBotFSM.waiting_for_name)
    await callback.message.edit_text("What should I call this bot?\n\nExample: <i>NYX SMS Bot</i>")
    await callback.answer()


@router.message(AddBotFSM.waiting_for_name, F.text)
async def receive_name(message: Message, state: FSMContext, bot_manager: BotManager) -> None:
    name = message.text.strip()
    if not (1 <= len(name) <= 64):
        await message.answer("Please send a name between 1 and 64 characters.")
        return

    data = await state.get_data()
    file_id = data["file_id"]

    progress = await message.answer("📦 Uploading Bot...\n\n⏳ Downloading file...")

    tg_file = await message.bot.get_file(file_id)
    buf = await message.bot.download_file(tg_file.file_path)
    zip_bytes = buf.read()

    record = await bot_manager.start_install(name)

    lines = ["📦 <b>Uploading Bot...</b>\n"]
    ok = True
    async for step in bot_manager.run_pipeline(record.id, zip_bytes):
        icon = "✅" if step.ok else "❌"
        lines.append(f"{icon} {step.label}")
        await progress.edit_text("\n".join(lines))
        if not step.ok:
            ok = False
            lines.append(f"\nError:\n<code>{step.detail[:600]}</code>")
            await progress.edit_text("\n".join(lines), reply_markup=back_button("mybots"))
            await bot_manager.db.log_audit(
                admin_id=message.from_user.id, action="install", bot_id=record.id,
                result="error", detail=step.detail[:500],
            )
            break

    if not ok:
        await state.clear()
        return

    candidates = bot_manager.detect_main_files(record.id)
    if len(candidates) == 1:
        await _finish_install(progress, state, bot_manager, record.id, candidates[0], lines, message.from_user.id)
        return

    if len(candidates) == 0:
        lines.append(
            "\n⚠️ No entry file found (expected one of: bot.py, main.py, app.py, run.py). "
            "Send the filename to use, or /cancel."
        )
        await progress.edit_text("\n".join(lines))
        await state.update_data(bot_id=record.id, lines=lines)
        await state.set_state(AddBotFSM.waiting_for_mainfile)
        return

    lines.append("\nSelect Main File")
    await progress.edit_text("\n".join(lines), reply_markup=main_file_keyboard(candidates))
    await state.update_data(bot_id=record.id, lines=lines, progress_chat_id=progress.chat.id, progress_msg_id=progress.message_id)
    await state.set_state(AddBotFSM.waiting_for_mainfile)


@router.callback_query(AddBotFSM.waiting_for_mainfile, MainFileChoice.filter())
async def choose_main_file(callback: CallbackQuery, callback_data: MainFileChoice, state: FSMContext, bot_manager: BotManager) -> None:
    data = await state.get_data()
    bot_id = data["bot_id"]
    lines = data.get("lines", [])
    await _finish_install(callback.message, state, bot_manager, bot_id, callback_data.file, lines, callback.from_user.id)
    await callback.answer()


@router.message(AddBotFSM.waiting_for_mainfile, F.text)
async def manual_main_file(message: Message, state: FSMContext, bot_manager: BotManager) -> None:
    data = await state.get_data()
    bot_id = data["bot_id"]
    lines = data.get("lines", [])
    filename = message.text.strip()

    from pathlib import Path
    bot = await bot_manager.db.get_bot(bot_id)
    if bot is None or not (Path(bot.source_path) / filename).is_file():
        await message.answer("That file doesn't exist in the uploaded source. Try again, or /cancel.")
        return

    progress = await message.answer("Finishing installation...")
    await _finish_install(progress, state, bot_manager, bot_id, filename, lines, message.from_user.id)


async def _finish_install(progress_msg, state: FSMContext, bot_manager: BotManager, bot_id: str, main_file: str, lines: list[str], admin_id: int) -> None:
    lines = list(lines) + [f"✅ Entry file: {main_file}", "✅ Service created"]
    text = "\n".join(lines) + "\n\n⏳ Starting bot & checking health..."
    await progress_msg.edit_text(text)

    ok, reason = await bot_manager.finalize_install(bot_id, main_file)
    await bot_manager.db.log_audit(
        admin_id=admin_id, action="install", bot_id=bot_id,
        result="success" if ok else "error", detail=reason,
    )

    from app.keyboards.main_menu import back_button as _back
    if ok:
        final = "\n".join(lines) + "\n🚀 Bot started successfully."
        await progress_msg.edit_text(final, reply_markup=_back("mybots"))
    else:
        final = "\n".join(lines) + f"\n\n❌ Bot failed to start.\n\nReason:\n<code>{reason}</code>"
        await progress_msg.edit_text(final, reply_markup=_back("mybots"))

    await state.clear()


@router.message(AddBotFSM.waiting_for_name)
async def receive_name_wrong_type(message: Message) -> None:
    await message.answer("Please send the bot's name as text.")

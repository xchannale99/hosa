from aiogram import F, Router
from aiogram.types import CallbackQuery

from app.keyboards.bots import bot_detail_keyboard
from app.keyboards.callback_data import BotAction, MenuNav
from app.keyboards.main_menu import back_button
from app.services.bot_manager import BotManager
from app.services.stats_manager import get_vps_stats
from app.utils.formatting import human_duration_long, human_duration_short, progress_bar

router = Router(name="stats")


@router.callback_query(MenuNav.filter(F.target == "vpsstats"))
async def nav_vps_stats(callback: CallbackQuery, bot_manager: BotManager) -> None:
    stats = await get_vps_stats()
    bots = await bot_manager.list_bots()
    running = sum(1 for b in bots if b.status == "running")
    stopped = len(bots) - running

    text = (
        "🖥️ <b>VPS STATUS</b>\n\n"
        f"⚙️ CPU\n{progress_bar(stats.cpu_percent)} {stats.cpu_percent:.0f}%\n\n"
        f"🧠 RAM\n{progress_bar(stats.ram_percent)} {stats.ram_percent:.0f}%  "
        f"({stats.ram_used_mb:.0f} / {stats.ram_total_mb:.0f} MB)\n\n"
        f"💾 Disk\n{progress_bar(stats.disk_percent)} {stats.disk_percent:.0f}%  "
        f"({stats.disk_used_gb:.1f} / {stats.disk_total_gb:.1f} GB)\n\n"
        f"🔁 Swap: {stats.swap_percent:.0f}%\n"
        f"📈 Load avg: {stats.load_avg[0]:.2f}, {stats.load_avg[1]:.2f}, {stats.load_avg[2]:.2f}\n"
        f"⏱️ Uptime: {human_duration_long(stats.uptime_seconds)}\n"
        f"🐍 Python: {stats.python_version}\n"
        f"🖥️ Host: {stats.hostname}\n\n"
        f"🤖 Running Bots: {running}\n"
        f"🔴 Stopped Bots: {stopped}"
    )
    await callback.message.edit_text(text, reply_markup=back_button("dashboard"))
    await callback.answer()


@router.callback_query(BotAction.filter(F.action == "stats"))
async def bot_stats(callback: CallbackQuery, callback_data: BotAction, bot_manager: BotManager) -> None:
    full = await bot_manager.get_full_status(callback_data.bot_id)
    p = full.process
    if p.alive:
        body = (
            f"PID: {p.pid}\n"
            f"CPU: {p.cpu_percent:.1f}%\n"
            f"RAM: {p.ram_mb:.0f} MB\n"
            f"Uptime: {human_duration_short(p.uptime_seconds)}\n"
        )
    else:
        body = "Process is not currently running.\n"

    text = (
        f"📊 <b>{full.record.name}</b>\n\n"
        f"{body}"
        f"Restart count: {full.unit.n_restarts}\n"
        f"Auto Restart: {'ON' if full.record.auto_restart else 'OFF'}"
    )
    await callback.message.edit_text(text, reply_markup=bot_detail_keyboard(full.record))
    await callback.answer()

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from app.keyboards.bots import bots_list_keyboard
from app.keyboards.callback_data import MenuNav
from app.keyboards.main_menu import back_button
from app.keyboards.reply_menu import MAIN_MENU_LABELS
from app.services.bot_manager import BotManager
from app.utils.formatting import status_dot
from app.utils.states import SearchFSM

router = Router(name="search")


@router.callback_query(MenuNav.filter(F.target == "search"))
async def start_search(callback: CallbackQuery, state: FSMContext) -> None:
    await state.set_state(SearchFSM.waiting_for_query)
    await callback.message.edit_text("🔎 Send part of a bot's name to search.", reply_markup=back_button("dashboard"))
    await callback.answer()


@router.message(SearchFSM.waiting_for_query, F.text, ~F.text.in_(MAIN_MENU_LABELS))
async def do_search(message: Message, state: FSMContext, bot_manager: BotManager) -> None:
    query = message.text.strip()
    results = await bot_manager.search(query)
    await state.clear()

    if not results:
        await message.answer(f"No bots matching “{query}”.", reply_markup=back_button("dashboard"))
        return

    lines = [f"{status_dot(b.status)} {b.name}" for b in results]
    text = f"🔎 <b>Results for “{query}”</b>\n\n" + "\n".join(lines)
    await message.answer(text, reply_markup=bots_list_keyboard(results, page=0))

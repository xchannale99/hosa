from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message
from aiogram.utils.keyboard import InlineKeyboardBuilder

from app.keyboards.callback_data import MenuNav
from app.keyboards.reply_menu import main_menu_reply_keyboard, remove_reply_keyboard

router = Router(name="keyboard_toggle")


@router.message(F.text == "🙈 Hide Keyboard")
async def hide_keyboard(message: Message, state: FSMContext) -> None:
    await state.clear()
    b = InlineKeyboardBuilder()
    b.button(text="⌨️ Show Keyboard", callback_data=MenuNav(target="show_keyboard"))
    await message.answer(
        "Keyboard hidden. Tap below (or send /menu) to bring it back.",
        reply_markup=remove_reply_keyboard(),
    )
    await message.answer("👇", reply_markup=b.as_markup())


@router.callback_query(MenuNav.filter(F.target == "show_keyboard"))
async def show_keyboard(callback: CallbackQuery) -> None:
    await callback.message.answer("⌨️ Menu restored.", reply_markup=main_menu_reply_keyboard())
    await callback.answer()

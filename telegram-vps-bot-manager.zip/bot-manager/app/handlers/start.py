from aiogram import F, Router
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from app.emoji import render
from app.keyboards.callback_data import MenuNav
from app.keyboards.main_menu import main_menu_keyboard
from app.services.bot_manager import BotManager

router = Router(name="start")


@router.message(Command("cancel"))
async def cmd_cancel(message: Message, state: FSMContext) -> None:
    if await state.get_state() is None:
        await message.answer("Nothing to cancel.")
        return
    await state.clear()
    await message.answer("Cancelled.", reply_markup=main_menu_keyboard())


def _dashboard_text() -> str:
    return (
        f"🤖 <b>VPS BOT MANAGER</b>\n\n"
        f"{render('settings')} Manage every bot on this VPS right from Telegram — "
        f"install, control, and monitor them without ever opening a shell.\n\n"
        f"Choose an option below."
    )


@router.message(CommandStart())
async def cmd_start(message: Message) -> None:
    await message.answer(_dashboard_text(), reply_markup=main_menu_keyboard())


@router.callback_query(MenuNav.filter(F.target == "dashboard"))
async def nav_dashboard(callback: CallbackQuery) -> None:
    await callback.message.edit_text(_dashboard_text(), reply_markup=main_menu_keyboard())
    await callback.answer()


@router.callback_query(MenuNav.filter(F.target == "audit"))
async def nav_audit(callback: CallbackQuery, bot_manager: BotManager) -> None:
    logs = await bot_manager.db.get_audit_logs(limit=15)
    if not logs:
        text = "📜 <b>Audit Log</b>\n\nNo actions recorded yet."
    else:
        lines = [
            f"• <code>{entry.timestamp}</code> — {entry.action} "
            f"({entry.bot_id or '-'}) → {entry.result}"
            for entry in logs
        ]
        text = "📜 <b>Audit Log</b> (last 15)\n\n" + "\n".join(lines)
    from app.keyboards.main_menu import back_button
    await callback.message.edit_text(text, reply_markup=back_button("dashboard"))
    await callback.answer()

from aiogram import F, Router
from aiogram.types import CallbackQuery
from aiogram.utils.keyboard import InlineKeyboardBuilder

from app.config import Settings
from app.keyboards.callback_data import MenuNav
from app.keyboards.main_menu import back_button
from app.services.bot_manager import BotManager
from app.utils.formatting import truncate

router = Router(name="manager")


@router.callback_query(MenuNav.filter(F.target == "settings"))
async def nav_settings(callback: CallbackQuery, settings: Settings) -> None:
    text = (
        "⚙️ <b>Manager Settings</b>\n\n"
        f"Base dir: <code>{settings.base_dir}</code>\n"
        f"Process backend: {settings.process_backend}\n"
        f"Log level: {settings.log_level}\n"
        f"Max upload size: {settings.max_upload_size_mb} MB\n"
        f"Systemd unit dir: <code>{settings.systemd_unit_dir}</code>\n"
        f"Admins configured: {len(settings.admin_ids)}\n\n"
        "To change these, edit <code>.env</code> on the VPS and restart the manager service."
    )
    await callback.message.edit_text(text, reply_markup=back_button("dashboard"))
    await callback.answer()


@router.callback_query(MenuNav.filter(F.target == "syslogs"))
async def nav_syslogs(callback: CallbackQuery, settings: Settings) -> None:
    manager_log = settings.logs_dir / "manager.log"
    content = "(no manager.log yet)"
    if manager_log.exists():
        lines = manager_log.read_text(encoding="utf-8", errors="replace").splitlines()
        content = "\n".join(lines[-40:]) or content
    text = f"📜 <b>System Logs</b>\n\nLast 40 lines of manager.log:\n\n<code>{truncate(content, 3500)}</code>"
    await callback.message.edit_text(text, reply_markup=back_button("dashboard"))
    await callback.answer()


@router.callback_query(MenuNav.filter(F.target == "tools"))
async def nav_tools(callback: CallbackQuery) -> None:
    b = InlineKeyboardBuilder()
    b.button(text="🔎 Search Bot", callback_data=MenuNav(target="search"))
    b.button(text="📜 Audit Log", callback_data=MenuNav(target="audit"))
    b.button(text="⬅️ Back", callback_data=MenuNav(target="dashboard"))
    b.adjust(1, 1, 1)
    await callback.message.edit_text("🛠️ <b>Tools</b>", reply_markup=b.as_markup())
    await callback.answer()

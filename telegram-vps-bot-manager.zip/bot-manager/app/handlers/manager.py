from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message
from aiogram.utils.keyboard import InlineKeyboardBuilder

from app.config import Settings
from app.keyboards.callback_data import MenuNav
from app.keyboards.main_menu import back_button
from app.services.bot_manager import BotManager
from app.utils.formatting import truncate

router = Router(name="manager")


def _settings_text(settings: Settings) -> str:
    return (
        "⚙️ <b>Manager Settings</b>\n\n"
        f"Base dir: <code>{settings.base_dir}</code>\n"
        f"Process backend: {settings.process_backend}\n"
        f"Log level: {settings.log_level}\n"
        f"Max upload size: {settings.max_upload_size_mb} MB\n"
        f"Systemd unit dir: <code>{settings.systemd_unit_dir}</code>\n"
        f"Admins configured: {len(settings.admin_ids)}\n\n"
        "To change these, edit <code>.env</code> on the VPS and restart the manager."
    )


def _syslogs_text(settings: Settings) -> str:
    manager_log = settings.logs_dir / "manager.log"
    content = "(no manager.log yet)"
    if manager_log.exists():
        lines = manager_log.read_text(encoding="utf-8", errors="replace").splitlines()
        content = "\n".join(lines[-40:]) or content
    return f"📜 <b>System Logs</b>\n\nLast 40 lines of manager.log:\n\n<code>{truncate(content, 3500)}</code>"


def _tools_keyboard():
    b = InlineKeyboardBuilder()
    b.button(text="🔎 Search Bot", callback_data=MenuNav(target="search"))
    b.button(text="📜 Audit Log", callback_data=MenuNav(target="audit"))
    b.adjust(1, 1)
    return b.as_markup()


@router.callback_query(MenuNav.filter(F.target == "settings"))
async def nav_settings(callback: CallbackQuery, settings: Settings) -> None:
    await callback.message.edit_text(_settings_text(settings), reply_markup=back_button("dashboard"))
    await callback.answer()


@router.message(F.text == "⚙️ Settings")
async def reply_settings(message: Message, state: FSMContext, settings: Settings) -> None:
    await state.clear()
    await message.answer(_settings_text(settings))


@router.callback_query(MenuNav.filter(F.target == "syslogs"))
async def nav_syslogs(callback: CallbackQuery, settings: Settings) -> None:
    await callback.message.edit_text(_syslogs_text(settings), reply_markup=back_button("dashboard"))
    await callback.answer()


@router.message(F.text == "📜 System Logs")
async def reply_syslogs(message: Message, state: FSMContext, settings: Settings) -> None:
    await state.clear()
    await message.answer(_syslogs_text(settings))


@router.callback_query(MenuNav.filter(F.target == "tools"))
async def nav_tools(callback: CallbackQuery) -> None:
    await callback.message.edit_text("🛠️ <b>Tools</b>", reply_markup=_tools_keyboard())
    await callback.answer()


@router.message(F.text == "🛠️ Tools")
async def reply_tools(message: Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer("🛠️ <b>Tools</b>", reply_markup=_tools_keyboard())

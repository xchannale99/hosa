"""
Central configuration for the VPS Bot Manager.

Everything here is loaded from environment variables (.env). Nothing
sensitive is ever hardcoded. If a required variable is missing, the
app refuses to start with a clear error instead of falling back to an
insecure default.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()


class ConfigError(RuntimeError):
    """Raised when required configuration is missing or invalid."""


def _require(name: str) -> str:
    value = os.getenv(name, "").strip()
    if not value:
        raise ConfigError(f"Missing required environment variable: {name}")
    return value


def _parse_admin_ids(raw: str) -> frozenset[int]:
    ids: set[int] = set()
    for chunk in raw.split(","):
        chunk = chunk.strip()
        if not chunk:
            continue
        if not chunk.isdigit():
            raise ConfigError(f"ADMIN_IDS contains a non-numeric value: {chunk!r}")
        ids.add(int(chunk))
    if not ids:
        raise ConfigError("ADMIN_IDS must contain at least one numeric Telegram user id")
    return frozenset(ids)


@dataclass(frozen=True)
class Settings:
    bot_token: str
    admin_ids: frozenset[int]

    base_dir: Path
    managed_bots_dir: Path = field(init=False)
    database_dir: Path = field(init=False)
    database_path: Path = field(init=False)
    logs_dir: Path = field(init=False)
    backups_dir: Path = field(init=False)

    log_level: str = "INFO"
    max_upload_size_mb: int = 100

    systemd_unit_dir: Path = Path("/etc/systemd/system")
    systemd_use_sudo: bool = False
    service_prefix: str = "nyx-bot-"
    process_backend: str = "systemd"  # "systemd" or "supervisor" (no root/systemd needed)

    backup_encryption_key: str | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "managed_bots_dir", self.base_dir / "managed_bots")
        object.__setattr__(self, "database_dir", self.base_dir / "database")
        object.__setattr__(self, "database_path", self.database_dir / "manager.db")
        object.__setattr__(self, "logs_dir", self.base_dir / "logs")
        object.__setattr__(self, "backups_dir", self.base_dir / "backups")

    @property
    def max_upload_size_bytes(self) -> int:
        return self.max_upload_size_mb * 1024 * 1024

    def ensure_directories(self) -> None:
        for path in (
            self.managed_bots_dir,
            self.database_dir,
            self.logs_dir,
            self.backups_dir,
        ):
            path.mkdir(parents=True, exist_ok=True)


def load_settings() -> Settings:
    base_dir_raw = os.getenv("BASE_DIR", "").strip()
    base_dir = Path(base_dir_raw).expanduser().resolve() if base_dir_raw else Path.cwd()

    process_backend = os.getenv("PROCESS_BACKEND", "systemd").strip().lower()
    if process_backend not in ("systemd", "supervisor"):
        raise ConfigError('PROCESS_BACKEND must be "systemd" or "supervisor"')

    settings = Settings(
        bot_token=_require("BOT_TOKEN"),
        admin_ids=_parse_admin_ids(_require("ADMIN_IDS")),
        base_dir=base_dir,
        log_level=os.getenv("LOG_LEVEL", "INFO").strip().upper() or "INFO",
        max_upload_size_mb=int(os.getenv("MAX_UPLOAD_SIZE_MB", "100")),
        systemd_unit_dir=Path(os.getenv("SYSTEMD_UNIT_DIR", "/etc/systemd/system")),
        systemd_use_sudo=os.getenv("SYSTEMD_USE_SUDO", "false").strip().lower() == "true",
        process_backend=process_backend,
        backup_encryption_key=os.getenv("BACKUP_ENCRYPTION_KEY", "").strip() or None,
    )
    settings.ensure_directories()
    return settings

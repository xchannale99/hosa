"""
Structured logging.

manager.log  — general operational log (startup, errors, lifecycle events)
security.log — auth failures and anything security-relevant
audit.log    — plain-text mirror of the audit_logs DB table, for grepping

Nothing here ever logs secret values — only variable *names*, never
their contents.
"""

from __future__ import annotations

import logging
from pathlib import Path


def _make_file_logger(name: str, path: Path, level: str) -> logging.Logger:
    logger = logging.getLogger(name)
    logger.setLevel(level)
    logger.propagate = False
    if not logger.handlers:
        handler = logging.FileHandler(path, encoding="utf-8")
        handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
        logger.addHandler(handler)
    return logger


def setup_logging(logs_dir: Path, level: str = "INFO") -> tuple[logging.Logger, logging.Logger, logging.Logger]:
    logs_dir.mkdir(parents=True, exist_ok=True)

    logging.basicConfig(level=level, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")

    manager_logger = _make_file_logger("manager", logs_dir / "manager.log", level)
    security_logger = _make_file_logger("security", logs_dir / "security.log", level)
    audit_logger = _make_file_logger("audit", logs_dir / "audit.log", level)

    return manager_logger, security_logger, audit_logger

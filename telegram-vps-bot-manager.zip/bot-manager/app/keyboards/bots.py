from aiogram.types import InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder

from app.database import BotRecord
from app.keyboards.callback_data import (
    AutoRestartToggle,
    BotAction,
    BotOpen,
    BotsPage,
    ConfirmDelete,
    MenuNav,
)
from app.utils.formatting import status_dot

PAGE_SIZE = 6


def bots_list_keyboard(bots: list[BotRecord], page: int = 0) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    start = page * PAGE_SIZE
    page_bots = bots[start:start + PAGE_SIZE]

    for bot in page_bots:
        label = f"{status_dot(bot.status)} {bot.name}"
        b.button(text=label, callback_data=BotOpen(bot_id=bot.id))
    b.adjust(1)

    total_pages = max(1, (len(bots) + PAGE_SIZE - 1) // PAGE_SIZE)
    if total_pages > 1:
        nav_row = InlineKeyboardBuilder()
        if page > 0:
            nav_row.button(text="⬅️", callback_data=BotsPage(page=page - 1))
        nav_row.button(text=f"{page + 1}/{total_pages}", callback_data=BotsPage(page=page))
        if page < total_pages - 1:
            nav_row.button(text="➡️", callback_data=BotsPage(page=page + 1))
        nav_row.adjust(3)
        b.attach(nav_row)

    footer = InlineKeyboardBuilder()
    footer.button(text="➕ Add Bot", callback_data=MenuNav(target="addbot"))
    footer.button(text="⬅️ Back", callback_data=MenuNav(target="dashboard"))
    footer.adjust(2)
    b.attach(footer)
    return b.as_markup()


def bot_detail_keyboard(bot: BotRecord) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    if bot.status == "running":
        b.button(text="⏹️ Stop", callback_data=BotAction(action="stop", bot_id=bot.id))
    else:
        b.button(text="▶️ Start", callback_data=BotAction(action="start", bot_id=bot.id))
    b.button(text="🔄 Restart", callback_data=BotAction(action="restart", bot_id=bot.id))
    b.button(text="📜 Logs", callback_data=BotAction(action="logs", bot_id=bot.id))
    b.button(text="📊 Stats", callback_data=BotAction(action="stats", bot_id=bot.id))
    b.button(text="⚙️ Settings", callback_data=BotAction(action="settings", bot_id=bot.id))
    b.button(text="🗑️ Delete", callback_data=ConfirmDelete(bot_id=bot.id, step="ask"))
    b.button(text="⬅️ Back", callback_data=MenuNav(target="mybots"))
    b.adjust(2, 2, 2, 1)
    return b.as_markup()


def auto_restart_toggle_keyboard(bot: BotRecord) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    if bot.auto_restart:
        b.button(text="🔄 Auto Restart: ON (tap to disable)",
                  callback_data=AutoRestartToggle(bot_id=bot.id, value="off"))
    else:
        b.button(text="⏸️ Auto Restart: OFF (tap to enable)",
                  callback_data=AutoRestartToggle(bot_id=bot.id, value="on"))
    b.adjust(1)
    return b.as_markup()

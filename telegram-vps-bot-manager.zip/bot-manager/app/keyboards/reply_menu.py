from aiogram.types import KeyboardButton, ReplyKeyboardMarkup, ReplyKeyboardRemove

MAIN_MENU_LAYOUT = [
    ["📊 Dashboard", "🤖 My Bots"],
    ["➕ Add Bot", "📈 VPS Stats"],
    ["📜 System Logs", "⚙️ Settings"],
    ["🛠️ Tools", "🙈 Hide Keyboard"],
]

MAIN_MENU_LABELS = {label for row in MAIN_MENU_LAYOUT for label in row}


def main_menu_reply_keyboard() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[[KeyboardButton(text=label) for label in row] for row in MAIN_MENU_LAYOUT],
        resize_keyboard=True,
        is_persistent=True,
        input_field_placeholder="Menu থেকে বেছে নিন...",
    )


def remove_reply_keyboard() -> ReplyKeyboardRemove:
    return ReplyKeyboardRemove()

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder

from app.keyboards.callback_data import MenuNav


def main_menu_keyboard() -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="📊 Dashboard", callback_data=MenuNav(target="dashboard"))
    b.button(text="🤖 My Bots", callback_data=MenuNav(target="mybots"))
    b.button(text="➕ Add Bot", callback_data=MenuNav(target="addbot"))
    b.button(text="📈 VPS Stats", callback_data=MenuNav(target="vpsstats"))
    b.button(text="📜 System Logs", callback_data=MenuNav(target="syslogs"))
    b.button(text="⚙️ Settings", callback_data=MenuNav(target="settings"))
    b.button(text="🛠️ Tools", callback_data=MenuNav(target="tools"))
    b.adjust(2, 2, 2, 1)
    return b.as_markup()


def back_button(target: str = "dashboard") -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="⬅️ Back", callback_data=MenuNav(target=target))
    return b.as_markup()


def yes_no_row(yes_cb, no_cb, yes_text: str = "✅ Yes", no_text: str = "❌ No") -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text=no_text, callback_data=no_cb)
    b.button(text=yes_text, callback_data=yes_cb)
    b.adjust(2)
    return b.as_markup()

from aiogram.types import InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder

from app.keyboards.callback_data import MenuNav


def back_button(target: str = "dashboard") -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="⬅️ Back", callback_data=MenuNav(target=target))
    return b.as_markup()


def yes_no_row(yes_cb, no_cb, yes_text: str = "✅ Yes", no_text: str = "❌ No") -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text=no_text, callback_data=no_cb)
    b.button(text=yes_text, callback_data=yes_cb)
    b.adjust(2)
    return b.as_markup()

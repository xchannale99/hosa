"""Typed callback_data payloads — keeps every button handler unambiguous."""

from aiogram.filters.callback_data import CallbackData


class MenuNav(CallbackData, prefix="nav"):
    target: str  # dashboard | mybots | addbot | vpsstats | settings | tools | search | audit


class BotOpen(CallbackData, prefix="bopen"):
    bot_id: str


class BotAction(CallbackData, prefix="bact"):
    action: str  # start | stop | restart | logs | stats | settings | delete | back
    bot_id: str


class BotsPage(CallbackData, prefix="bpage"):
    page: int


class LogsAction(CallbackData, prefix="blog"):
    action: str  # refresh | download | clear | more | back
    bot_id: str
    lines: int = 50


class ConfirmDelete(CallbackData, prefix="cdel"):
    bot_id: str
    step: str  # ask | yes | no


class MainFileChoice(CallbackData, prefix="mfile"):
    file: str


class InstallConfirm(CallbackData, prefix="binst"):
    value: str  # yes | no


class AutoRestartToggle(CallbackData, prefix="arst"):
    bot_id: str
    value: str  # on | off


class EnvAction(CallbackData, prefix="env"):
    action: str  # list | add | delete | back
    bot_id: str
    idx: int = -1


class SettingsAction(CallbackData, prefix="bset"):
    action: str  # rename | describe | env | deps | autorestart | back
    bot_id: str


class BackupAction(CallbackData, prefix="bkup"):
    action: str  # create | list | restore | back
    bot_id: str
    idx: int = -1


class UpdateBotAction(CallbackData, prefix="upd"):
    action: str  # start | confirm | cancel
    bot_id: str

from aiogram.types import InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder

from app.database import BotRecord
from app.keyboards.callback_data import (
    AutoRestartToggle,
    BackupAction,
    BotAction,
    ConfirmDelete,
    EnvAction,
    InstallConfirm,
    LogsAction,
    MainFileChoice,
    SettingsAction,
    UpdateBotAction,
)


def logs_keyboard(bot_id: str, lines: int) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="🔄 Refresh", callback_data=LogsAction(action="refresh", bot_id=bot_id, lines=lines))
    b.button(text="📥 Download", callback_data=LogsAction(action="download", bot_id=bot_id, lines=lines))
    b.button(text="🧹 Clear", callback_data=LogsAction(action="clear", bot_id=bot_id, lines=lines))
    b.button(text="20", callback_data=LogsAction(action="more", bot_id=bot_id, lines=20))
    b.button(text="50", callback_data=LogsAction(action="more", bot_id=bot_id, lines=50))
    b.button(text="100", callback_data=LogsAction(action="more", bot_id=bot_id, lines=100))
    b.button(text="⬅️ Back", callback_data=BotAction(action="back", bot_id=bot_id))
    b.adjust(3, 3, 1)
    return b.as_markup()


def delete_confirm_keyboard(bot_id: str) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="❌ Cancel", callback_data=ConfirmDelete(bot_id=bot_id, step="no"))
    b.button(text="🗑️ Continue", callback_data=ConfirmDelete(bot_id=bot_id, step="yes"))
    b.adjust(2)
    return b.as_markup()


def install_confirm_keyboard() -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="✅ Install", callback_data=InstallConfirm(value="yes"))
    b.button(text="❌ Cancel", callback_data=InstallConfirm(value="no"))
    b.adjust(2)
    return b.as_markup()


def update_confirm_keyboard(bot_id: str) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="✅ Update", callback_data=UpdateBotAction(action="confirm", bot_id=bot_id))
    b.button(text="❌ Cancel", callback_data=UpdateBotAction(action="cancel", bot_id=bot_id))
    b.adjust(2)
    return b.as_markup()


def main_file_keyboard(candidates: list[str]) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    for c in candidates:
        b.button(text=c, callback_data=MainFileChoice(file=c))
    b.adjust(2)
    return b.as_markup()


def settings_keyboard(bot: BotRecord) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="🤖 Rename", callback_data=SettingsAction(action="rename", bot_id=bot.id))
    b.button(text="📝 Description", callback_data=SettingsAction(action="describe", bot_id=bot.id))
    label = "🔄 Auto Restart: ON" if bot.auto_restart else "⏸️ Auto Restart: OFF"
    toggle_value = "off" if bot.auto_restart else "on"
    b.button(text=label, callback_data=AutoRestartToggle(bot_id=bot.id, value=toggle_value))
    b.button(text="🌐 Environment", callback_data=SettingsAction(action="env", bot_id=bot.id))
    b.button(text="🔄 Update Bot", callback_data=UpdateBotAction(action="start", bot_id=bot.id))
    b.button(text="💾 Backup", callback_data=BackupAction(action="create", bot_id=bot.id))
    b.button(text="♻️ Restore", callback_data=BackupAction(action="list", bot_id=bot.id))
    b.button(text="⬅️ Back", callback_data=BotAction(action="back", bot_id=bot.id))
    b.adjust(2, 2, 2, 1)
    return b.as_markup()


def env_list_keyboard(bot_id: str, keys: list[str]) -> InlineKeyboardMarkup:
    keys_builder = InlineKeyboardBuilder()
    for idx, key in enumerate(keys):
        keys_builder.button(text=f"✏️ {key}", callback_data=EnvAction(action="delete", bot_id=bot_id, idx=idx))
    keys_builder.adjust(2)

    footer = InlineKeyboardBuilder()
    footer.button(text="➕ Add Variable", callback_data=EnvAction(action="add", bot_id=bot_id))
    footer.button(text="⬅️ Back", callback_data=SettingsAction(action="back", bot_id=bot_id))
    footer.adjust(1)

    b = InlineKeyboardBuilder()
    b.attach(keys_builder)
    b.attach(footer)
    return b.as_markup()


def backup_list_keyboard(bot_id: str, count: int) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    for idx in range(count):
        b.button(text=f"♻️ Backup #{idx + 1}", callback_data=BackupAction(action="restore", bot_id=bot_id, idx=idx))
    b.adjust(1)
    b.button(text="⬅️ Back", callback_data=SettingsAction(action="back", bot_id=bot_id))
    b.adjust(1, 1)
    return b.as_markup()

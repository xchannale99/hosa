"""aiogram FSM state groups for every multi-step conversation."""

from aiogram.fsm.state import State, StatesGroup


class AddBotFSM(StatesGroup):
    waiting_for_zip = State()
    waiting_for_name = State()
    waiting_for_mainfile = State()
    waiting_for_confirm = State()


class UpdateBotFSM(StatesGroup):
    waiting_for_zip = State()
    waiting_for_confirm = State()


class DeleteBotFSM(StatesGroup):
    waiting_for_confirm_text = State()


class EnvVarFSM(StatesGroup):
    waiting_for_key = State()
    waiting_for_value = State()


class SearchFSM(StatesGroup):
    waiting_for_query = State()


class SettingsFSM(StatesGroup):
    waiting_for_new_name = State()
    waiting_for_new_description = State()

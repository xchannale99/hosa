"""Small security-related helpers used across the app."""

from __future__ import annotations

import re
import secrets
import string


def mask_secret(value: str) -> str:
    """
    Mask a secret for display: keep a few leading/trailing chars, hide
    the rest. Never returns the original value in full.

        "1234567890789" -> "1234••••••••789"
    """
    if not value:
        return "••••••••"
    if len(value) <= 6:
        return "•" * len(value)
    head, tail = value[:4], value[-3:]
    return f"{head}{'•' * 8}{tail}"


def slugify(name: str) -> str:
    slug = name.strip().lower()
    slug = re.sub(r"[^a-z0-9]+", "-", slug)
    slug = slug.strip("-")
    return slug or f"bot-{secrets.token_hex(3)}"


def random_token(length: int = 8) -> str:
    alphabet = string.ascii_lowercase + string.digits
    return "".join(secrets.choice(alphabet) for _ in range(length))


def is_admin(user_id: int, admin_ids: frozenset[int]) -> bool:
    return user_id in admin_ids

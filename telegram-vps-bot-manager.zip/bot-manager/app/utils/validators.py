"""
Everything that keeps an uploaded ZIP from being able to touch anything
outside its own bot directory.

Rules enforced by validate_zip():
  - total uncompressed size must stay under the configured limit
  - no absolute paths, no ".." segments, no paths that resolve outside
    the destination directory
  - no symlinks packed into the archive
  - a sane compression-ratio ceiling, as a basic zip-bomb guard
  - a sane max file count

safe_extract() re-checks every member's resolved path right before
writing it, so even if validate_zip() is ever bypassed, extraction
itself cannot escape the target directory.
"""

from __future__ import annotations

import zipfile
from dataclasses import dataclass
from pathlib import Path

MAIN_FILE_CANDIDATES = ("bot.py", "main.py", "app.py", "run.py")
MAX_FILES = 5000
MAX_RATIO = 200  # uncompressed / compressed, generous but blocks obvious bombs


class ZipValidationError(ValueError):
    """Raised when an uploaded archive fails a safety check."""


@dataclass
class ZipReport:
    file_count: int
    total_uncompressed: int
    common_root: str | None  # set if every entry lives under one shared top folder


def _is_safe_member_path(name: str, dest_root: Path) -> Path | None:
    if name.startswith("/") or name.startswith("\\"):
        return None
    candidate = (dest_root / name).resolve()
    try:
        candidate.relative_to(dest_root.resolve())
    except ValueError:
        return None
    return candidate


def validate_zip(zip_path: Path, dest_root: Path, max_size_bytes: int) -> ZipReport:
    if not zipfile.is_zipfile(zip_path):
        raise ZipValidationError("This doesn't look like a valid ZIP file.")

    total_uncompressed = 0
    total_compressed = 0
    file_count = 0
    roots: set[str] = set()

    with zipfile.ZipFile(zip_path) as zf:
        infos = zf.infolist()
        if len(infos) == 0:
            raise ZipValidationError("The archive is empty.")
        if len(infos) > MAX_FILES:
            raise ZipValidationError(f"Too many files in archive (max {MAX_FILES}).")

        for info in infos:
            # Reject symlinks: unix mode bits are packed into the top 16
            # bits of external_attr; 0xA000 marks S_IFLNK.
            unix_mode = info.external_attr >> 16
            if unix_mode and (unix_mode & 0xF000) == 0xA000:
                raise ZipValidationError(f"Symlinks are not allowed: {info.filename}")

            if _is_safe_member_path(info.filename, dest_root) is None:
                raise ZipValidationError(f"Unsafe path in archive: {info.filename}")

            top = info.filename.split("/", 1)[0]
            if top:
                roots.add(top)

            file_count += 1
            total_uncompressed += info.file_size
            total_compressed += info.compress_size

            if total_uncompressed > max_size_bytes:
                raise ZipValidationError(
                    f"Archive too large when uncompressed (limit {max_size_bytes // (1024*1024)} MB)."
                )

        if total_compressed > 0:
            ratio = total_uncompressed / max(total_compressed, 1)
            if ratio > MAX_RATIO:
                raise ZipValidationError("Archive looks like a zip bomb (suspicious compression ratio).")

    common_root = None
    if len(roots) == 1:
        only = next(iter(roots))
        with zipfile.ZipFile(zip_path) as zf:
            if all(n == only or n.startswith(only + "/") for n in zf.namelist()):
                common_root = only

    return ZipReport(file_count=file_count, total_uncompressed=total_uncompressed, common_root=common_root)


def safe_extract(zip_path: Path, dest_root: Path) -> None:
    dest_root.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path) as zf:
        for info in zf.infolist():
            target = _is_safe_member_path(info.filename, dest_root)
            if target is None:
                raise ZipValidationError(f"Unsafe path during extraction: {info.filename}")
            if info.is_dir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            with zf.open(info) as src, open(target, "wb") as dst:
                dst.write(src.read())

    report_root = None
    with zipfile.ZipFile(zip_path) as zf:
        roots = {n.split("/", 1)[0] for n in zf.namelist() if n.strip("/")}
    if len(roots) == 1:
        only = next(iter(roots))
        wrapped = dest_root / only
        if wrapped.is_dir():
            report_root = wrapped

    # If everything was packed inside a single wrapping folder, flatten
    # it up one level so main-file detection behaves consistently.
    if report_root is not None:
        for item in report_root.iterdir():
            item.rename(dest_root / item.name)
        report_root.rmdir()


def detect_main_files(source_dir: Path) -> list[str]:
    found = []
    for candidate in MAIN_FILE_CANDIDATES:
        if (source_dir / candidate).is_file():
            found.append(candidate)
    return found


def validate_env_key(key: str) -> bool:
    return bool(key) and all(c.isalnum() or c == "_" for c in key) and not key[0].isdigit()

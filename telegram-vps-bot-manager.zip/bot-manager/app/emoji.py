"""
Premium custom emoji utility.

Telegram premium custom emoji are sent as regular unicode emoji plus a
`custom_emoji_id`. Clients with Telegram Premium render the custom
artwork; everyone else sees the normal fallback emoji. Because of that,
we always keep a real unicode character paired with every custom id.

Usage:
    from app.emoji import get_emoji, render

    icon = get_emoji("success")          # -> Emoji(char="😁", id="521...")
    html = render("success")             # -> '<tg-emoji emoji-id="521...">😁</tg-emoji>'

`get_random_emoji` / `get_emoji` avoid repeating the same emoji twice
in a row so a single message doesn't look spammy.
"""

from __future__ import annotations

import random
from collections import deque
from dataclasses import dataclass

# unicode fallback -> premium custom emoji id, exactly as provided.
_RAW: dict[str, str] = {
    "😀": "5451709985765468632",
    "😁": "5219675837887956268",
    "😅": "5393596088953349309",
    "😂": "5458587027270280607",
    "🙃": "5456174445355875099",
    "🫠": "5222202120471591480",
    "😉": "5458394638505223612",
    "😊": "5397866377367268054",
    "😇": "5341350410252723241",
    "🥰": "5456149049214249060",
    "😍": "5458696196749008675",
    "🤩": "5395597754166682968",
    "😘": "5458421812763307254",
    "🥲": "5202204379079260712",
    "😋": "5456131714726249223",
    "🤪": "5361761791355398330",
    "😝": "5361761791355398330",
    "🤑": "5237695957293875263",
    "🤗": "5280818098960611598",
    "🫢": "5210905596273905344",
    "🤫": "5201817814842755281",
    "🤔": "5278524998741412656",
    "🫡": "5449875850046481967",
    "🤐": "5382224089295365367",
    "🤨": "5447621198374511640",
    "😐": "5456304325166900944",
    "😑": "5438274168422409988",
    "😶": "5335071013447158323",
    "🫥": "5289772607556568230",
    "😶‍🌫️": "5283276370737119006",
    "😏": "5238020759900668600",
    "🙄": "5445091140514620351",
    "😬": "5226962730941955595",
    "🤥": "5219860366862862672",
    "🫨": "5235516089592463902",
    "😔": "5330188279876700094",
    "🤤": "5458779239941681169",
    "😴": "5404654779337034132",
    "🤒": "5346167851730348282",
    "🤕": "5463232030105945136",
    "🤢": "5467629518271299429",
    "🤮": "5474215257914232160",
}


@dataclass(frozen=True)
class Emoji:
    char: str
    id: str

    def html(self) -> str:
        return f'<tg-emoji emoji-id="{self.id}">{self.char}</tg-emoji>'


_ALL: list[Emoji] = [Emoji(char=c, id=i) for c, i in _RAW.items()]

# Contextual categories, per the spec's success/warning/error/etc mapping.
_CATEGORIES: dict[str, list[str]] = {
    "success": ["😁", "🤩", "🥰", "😊", "😇"],
    "warning": ["🤨", "🫡", "😬"],
    "error": ["😔", "🤕", "🤢", "🤮"],
    "loading": ["🫠", "😴"],
    "settings": ["🤔"],
    "security": ["🤫"],
    "delete": ["😬"],
    "restart": ["🫨"],
    "neutral": ["🙂".replace("🙂", "🙃"), "😉", "😐"],
}

_BY_CHAR: dict[str, Emoji] = {e.char: e for e in _ALL}

# Small rolling history so we don't repeat the same emoji back-to-back.
_recent: deque[str] = deque(maxlen=5)


def _pick(pool: list[Emoji]) -> Emoji:
    if not pool:
        pool = _ALL
    candidates = [e for e in pool if e.char not in _recent] or pool
    choice = random.choice(candidates)
    _recent.append(choice.char)
    return choice


def get_random_emoji(category: str | None = None) -> Emoji:
    """Return a random Emoji, optionally scoped to a semantic category."""
    if category and category in _CATEGORIES:
        pool = [_BY_CHAR[c] for c in _CATEGORIES[category] if c in _BY_CHAR]
        return _pick(pool)
    return _pick(_ALL)


def get_emoji(name: str) -> Emoji:
    """Alias for get_random_emoji(category=name) — reads nicer at call sites."""
    return get_random_emoji(category=name)


def render(name_or_category: str) -> str:
    """Return ready-to-send HTML for a contextual emoji (parse_mode=HTML)."""
    return get_emoji(name_or_category).html()


def render_char(category: str) -> str:
    """Return just the plain unicode fallback (no HTML), e.g. for logs/plain text."""
    return get_emoji(category).char

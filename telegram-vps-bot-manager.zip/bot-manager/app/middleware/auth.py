"""
Admin-only gate.

Every message and callback query passes through here first. Anyone
not in ADMIN_IDS gets a short, generic reply — no bot names, no
counts, no hint that anything else exists. This is the single point
of enforcement so no handler can accidentally skip it.
"""

from __future__ import annotations

from typing import Any, Awaitable, Callable

from aiogram import BaseMiddleware
from aiogram.types import CallbackQuery, Message, TelegramObject

from app.config import Settings
from app.database import Database


class AuthMiddleware(BaseMiddleware):
    def __init__(self, settings: Settings, db: Database) -> None:
        self._settings = settings
        self._db = db

    async def __call__(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        user = data.get("event_from_user")
        user_id = getattr(user, "id", None)

        if user_id is None or user_id not in self._settings.admin_ids:
            await self._db.log_audit(
                admin_id=user_id or 0,
                action="unauthorized_access",
                bot_id=None,
                result="denied",
            )
            if isinstance(event, Message):
                await event.answer("🚫 You are not authorized to use this bot.")
            elif isinstance(event, CallbackQuery):
                await event.answer("🚫 Not authorized.", show_alert=True)
            return None

        return await handler(event, data)

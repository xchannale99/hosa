"""
Async SQLite repository.

Kept deliberately dependency-light (aiosqlite only) so the manager has
no external DB server to operate. Swapping to PostgreSQL later only
means replacing this module — nothing above it depends on SQLite
specifics.
"""

from __future__ import annotations

import datetime as dt
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import aiosqlite

_SCHEMA = """
CREATE TABLE IF NOT EXISTS bots (
    id              TEXT PRIMARY KEY,
    name            TEXT NOT NULL,
    slug            TEXT NOT NULL UNIQUE,
    description     TEXT NOT NULL DEFAULT '',
    source_path     TEXT NOT NULL,
    venv_path       TEXT NOT NULL,
    main_file       TEXT NOT NULL,
    service_name    TEXT NOT NULL UNIQUE,
    status          TEXT NOT NULL DEFAULT 'stopped',
    auto_restart    INTEGER NOT NULL DEFAULT 1,
    created_at      TEXT NOT NULL,
    updated_at      TEXT NOT NULL,
    restart_count   INTEGER NOT NULL DEFAULT 0,
    last_started_at TEXT,
    last_stopped_at TEXT
);

CREATE TABLE IF NOT EXISTS audit_logs (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    admin_id    INTEGER NOT NULL,
    action      TEXT NOT NULL,
    bot_id      TEXT,
    timestamp   TEXT NOT NULL,
    result      TEXT NOT NULL,
    detail      TEXT
);

CREATE INDEX IF NOT EXISTS idx_audit_bot ON audit_logs(bot_id);
CREATE INDEX IF NOT EXISTS idx_audit_time ON audit_logs(timestamp);
"""


def _now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")


@dataclass
class BotRecord:
    id: str
    name: str
    slug: str
    description: str
    source_path: str
    venv_path: str
    main_file: str
    service_name: str
    status: str
    auto_restart: bool
    created_at: str
    updated_at: str
    restart_count: int
    last_started_at: str | None
    last_stopped_at: str | None

    @staticmethod
    def from_row(row: aiosqlite.Row) -> "BotRecord":
        d = dict(row)
        d["auto_restart"] = bool(d["auto_restart"])
        return BotRecord(**d)


@dataclass
class AuditLogRecord:
    id: int
    admin_id: int
    action: str
    bot_id: str | None
    timestamp: str
    result: str
    detail: str | None = field(default=None)

    @staticmethod
    def from_row(row: aiosqlite.Row) -> "AuditLogRecord":
        return AuditLogRecord(**dict(row))


class Database:
    def __init__(self, path: Path) -> None:
        self._path = path
        self._conn: aiosqlite.Connection | None = None

    async def connect(self) -> None:
        self._conn = await aiosqlite.connect(self._path)
        self._conn.row_factory = aiosqlite.Row
        await self._conn.execute("PRAGMA foreign_keys = ON;")
        await self._conn.executescript(_SCHEMA)
        await self._conn.commit()

    async def close(self) -> None:
        if self._conn:
            await self._conn.close()
            self._conn = None

    @property
    def conn(self) -> aiosqlite.Connection:
        if self._conn is None:
            raise RuntimeError("Database not connected — call connect() first")
        return self._conn

    # ---------------------------------------------------------------- bots

    async def add_bot(
        self,
        *,
        bot_id: str,
        name: str,
        slug: str,
        source_path: str,
        venv_path: str,
        main_file: str,
        service_name: str,
        description: str = "",
        auto_restart: bool = True,
    ) -> BotRecord:
        now = _now()
        await self.conn.execute(
            """
            INSERT INTO bots (
                id, name, slug, description, source_path, venv_path, main_file,
                service_name, status, auto_restart, created_at, updated_at,
                restart_count, last_started_at, last_stopped_at
            ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,0,NULL,NULL)
            """,
            (
                bot_id, name, slug, description, source_path, venv_path, main_file,
                service_name, "installing", int(auto_restart), now, now,
            ),
        )
        await self.conn.commit()
        return await self.get_bot(bot_id)  # type: ignore[return-value]

    async def get_bot(self, bot_id: str) -> BotRecord | None:
        cur = await self.conn.execute("SELECT * FROM bots WHERE id = ?", (bot_id,))
        row = await cur.fetchone()
        return BotRecord.from_row(row) if row else None

    async def get_bot_by_service(self, service_name: str) -> BotRecord | None:
        cur = await self.conn.execute(
            "SELECT * FROM bots WHERE service_name = ?", (service_name,)
        )
        row = await cur.fetchone()
        return BotRecord.from_row(row) if row else None

    async def list_bots(self) -> list[BotRecord]:
        cur = await self.conn.execute("SELECT * FROM bots ORDER BY created_at ASC")
        rows = await cur.fetchall()
        return [BotRecord.from_row(r) for r in rows]

    async def search_bots(self, query: str) -> list[BotRecord]:
        cur = await self.conn.execute(
            "SELECT * FROM bots WHERE name LIKE ? ORDER BY name ASC",
            (f"%{query}%",),
        )
        rows = await cur.fetchall()
        return [BotRecord.from_row(r) for r in rows]

    async def update_bot(self, bot_id: str, **fields: Any) -> None:
        if not fields:
            return
        fields["updated_at"] = _now()
        if "auto_restart" in fields:
            fields["auto_restart"] = int(bool(fields["auto_restart"]))
        columns = ", ".join(f"{k} = ?" for k in fields)
        values = list(fields.values()) + [bot_id]
        await self.conn.execute(f"UPDATE bots SET {columns} WHERE id = ?", values)
        await self.conn.commit()

    async def set_status(self, bot_id: str, status: str) -> None:
        now = _now()
        extra = {}
        if status == "running":
            extra["last_started_at"] = now
        elif status == "stopped":
            extra["last_stopped_at"] = now
        await self.update_bot(bot_id, status=status, **extra)

    async def increment_restart_count(self, bot_id: str, to_value: int | None = None) -> None:
        if to_value is not None:
            await self.update_bot(bot_id, restart_count=to_value)
            return
        await self.conn.execute(
            "UPDATE bots SET restart_count = restart_count + 1, updated_at = ? WHERE id = ?",
            (_now(), bot_id),
        )
        await self.conn.commit()

    async def delete_bot(self, bot_id: str) -> None:
        await self.conn.execute("DELETE FROM bots WHERE id = ?", (bot_id,))
        await self.conn.commit()

    async def next_bot_id(self) -> str:
        cur = await self.conn.execute("SELECT id FROM bots")
        rows = await cur.fetchall()
        used = set()
        for r in rows:
            try:
                used.add(int(r["id"].split("_")[-1]))
            except (ValueError, IndexError):
                continue
        n = 1
        while n in used:
            n += 1
        return f"bot_{n:03d}"

    # --------------------------------------------------------------- audit

    async def log_audit(
        self,
        *,
        admin_id: int,
        action: str,
        bot_id: str | None,
        result: str,
        detail: str | None = None,
    ) -> None:
        await self.conn.execute(
            """
            INSERT INTO audit_logs (admin_id, action, bot_id, timestamp, result, detail)
            VALUES (?,?,?,?,?,?)
            """,
            (admin_id, action, bot_id, _now(), result, detail),
        )
        await self.conn.commit()

    async def get_audit_logs(self, limit: int = 50) -> list[AuditLogRecord]:
        cur = await self.conn.execute(
            "SELECT * FROM audit_logs ORDER BY id DESC LIMIT ?", (limit,)
        )
        rows = await cur.fetchall()
        return [AuditLogRecord.from_row(r) for r in rows]

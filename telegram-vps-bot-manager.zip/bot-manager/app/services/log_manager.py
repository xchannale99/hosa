"""
Per-bot log handling.

Each bot's systemd unit is configured with
StandardOutput=append:<logs/output.log> and StandardError to the same
file, so log access here is just plain file I/O — no journald parsing
needed, and it works identically on any systemd VPS.
"""

from __future__ import annotations

import asyncio
from pathlib import Path


class LogManager:
    def __init__(self, managed_bots_dir: Path) -> None:
        self._root = managed_bots_dir

    def log_path(self, bot_id: str) -> Path:
        log_dir = self._root / bot_id / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        return log_dir / "output.log"

    def _tail(self, bot_id: str, lines: int) -> str:
        path = self.log_path(bot_id)
        if not path.exists() or path.stat().st_size == 0:
            return "(no logs yet)"
        with open(path, "rb") as f:
            block = 4096
            f.seek(0, 2)
            size = f.tell()
            data = b""
            read = 0
            while read < size and data.count(b"\n") <= lines:
                step = min(block, size - read)
                read += step
                f.seek(size - read)
                data = f.read(step) + data
        text = data.decode(errors="replace").splitlines()
        return "\n".join(text[-lines:]) or "(no logs yet)"

    async def tail(self, bot_id: str, lines: int = 50) -> str:
        return await asyncio.to_thread(self._tail, bot_id, lines)

    async def clear(self, bot_id: str) -> None:
        path = self.log_path(bot_id)

        def _clear() -> None:
            path.write_text("", encoding="utf-8")

        await asyncio.to_thread(_clear)

    async def export_path(self, bot_id: str) -> Path:
        return self.log_path(bot_id)

"""
Fallback process backend for environments without systemd/root access
(shared containers, restricted shells, some cheap "VPS" panels that are
really just a container with a web terminal).

This intentionally mirrors SystemdManager's public interface 1:1
(service_name, render_unit, install_unit, enable, disable, start,
stop, restart, reset_failed, remove_unit, status) so bot_manager.py
and the watcher never need to know which backend is active.

How it stays alive without systemd:
  - Every process is spawned detached (start_new_session=True, i.e.
    the equivalent of `setsid ...`), so it survives the manager
    restarting or the terminal/session that launched the manager
    closing.
  - Crash detection + restarting is done by the watcher polling loop
    (see services/watcher.py) instead of the kernel/init system, since
    there is no Restart=on-failure here — restart_with_limit_check()
    implements the same "burst window" protection systemd's
    StartLimitBurst/StartLimitIntervalSec would.
  - True survival across a full VPS/container *reboot* still requires
    something to re-launch the manager itself on boot (cron @reboot,
    or the hosting panel's own "startup command" feature) — see
    run_manager.sh / README for that piece, which this module cannot
    provide on its own without init access.
"""

from __future__ import annotations

import asyncio
import json
import os
import shlex
import signal
import time
from dataclasses import dataclass
from pathlib import Path

import psutil

from app.services.systemd_manager import UnitStatus

BURST_WINDOW_SECONDS = 60
BURST_LIMIT = 5


class SupervisorError(RuntimeError):
    pass


@dataclass
class _Spec:
    argv: list[str]
    cwd: str
    log_path: str
    env_file: str | None
    auto_restart: bool
    enabled: bool = False
    should_run: bool = False
    pid: int | None = None
    restart_count: int = 0
    crash_timestamps: list[float] | None = None
    result: str = ""

    def to_json(self) -> str:
        return json.dumps(self.__dict__)

    @staticmethod
    def from_json(text: str) -> "_Spec":
        data = json.loads(text)
        data.setdefault("crash_timestamps", [])
        return _Spec(**data)


class ProcessSupervisor:
    # Tells the watcher this backend needs it to actively restart
    # crashed processes (systemd does this itself; this one doesn't).
    requires_active_restart = True

    def __init__(self, managed_bots_dir: Path, service_prefix: str = "nyx-bot-") -> None:
        self._root = managed_bots_dir
        self._prefix = service_prefix
        self._state_dir = managed_bots_dir / "_supervisor_state"
        self._state_dir.mkdir(parents=True, exist_ok=True)

    def service_name(self, bot_id: str) -> str:
        short = bot_id.replace("bot_", "")
        return f"{self._prefix}{short}"

    def _state_path(self, service_name: str) -> Path:
        return self._state_dir / f"{service_name}.json"

    def _load(self, service_name: str) -> _Spec:
        path = self._state_path(service_name)
        if not path.exists():
            raise SupervisorError(f"No process record for {service_name}.")
        return _Spec.from_json(path.read_text(encoding="utf-8"))

    def _save(self, service_name: str, spec: _Spec) -> None:
        self._state_path(service_name).write_text(spec.to_json(), encoding="utf-8")

    # ------------------------------------------------------- unit-file-ish

    def render_unit(
        self,
        *,
        description: str,
        working_dir: Path,
        exec_start: str,
        log_path: Path,
        env_file: Path | None,
        auto_restart: bool,
    ) -> str:
        spec = _Spec(
            argv=shlex.split(exec_start),
            cwd=str(working_dir),
            log_path=str(log_path),
            env_file=str(env_file) if env_file else None,
            auto_restart=auto_restart,
            crash_timestamps=[],
        )
        return spec.to_json()

    async def install_unit(self, service_name: str, unit_content: str) -> None:
        # unit_content here is the JSON produced by render_unit(); preserve
        # any existing runtime state (pid, restart_count) if present.
        new_spec = _Spec.from_json(unit_content)
        try:
            old = self._load(service_name)
            new_spec.enabled = old.enabled
            new_spec.should_run = old.should_run
            new_spec.pid = old.pid
            new_spec.restart_count = old.restart_count
            new_spec.crash_timestamps = old.crash_timestamps or []
        except SupervisorError:
            pass
        self._save(service_name, new_spec)

    async def daemon_reload(self) -> None:  # no-op, kept for interface parity
        return None

    # -------------------------------------------------------------- control

    async def enable(self, service_name: str) -> None:
        spec = self._load(service_name)
        spec.enabled = True
        self._save(service_name, spec)

    async def disable(self, service_name: str) -> None:
        try:
            spec = self._load(service_name)
        except SupervisorError:
            return
        spec.enabled = False
        self._save(service_name, spec)

    def _load_env(self, env_file: str | None) -> dict:
        env = os.environ.copy()
        if env_file and Path(env_file).exists():
            for line in Path(env_file).read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, v = line.split("=", 1)
                env[k.strip()] = v.strip()
        return env

    async def _spawn(self, spec: _Spec) -> int:
        log_path = Path(spec.log_path)
        log_path.parent.mkdir(parents=True, exist_ok=True)
        log_fh = open(log_path, "ab", buffering=0)
        env = self._load_env(spec.env_file)
        proc = await asyncio.create_subprocess_exec(
            *spec.argv,
            cwd=spec.cwd,
            env=env,
            stdout=log_fh,
            stderr=log_fh,
            stdin=asyncio.subprocess.DEVNULL,
            start_new_session=True,  # detach — survives manager restarts
        )
        log_fh.close()
        return proc.pid

    def _is_alive(self, pid: int | None) -> bool:
        if not pid:
            return False
        return psutil.pid_exists(pid)

    def _kill(self, pid: int) -> None:
        try:
            os.kill(pid, signal.SIGTERM)
        except ProcessLookupError:
            return
        for _ in range(20):  # ~5s grace period
            if not psutil.pid_exists(pid):
                return
            time.sleep(0.25)
        try:
            os.kill(pid, signal.SIGKILL)
        except ProcessLookupError:
            pass

    async def start(self, service_name: str) -> None:
        spec = self._load(service_name)
        if self._is_alive(spec.pid):
            spec.should_run = True
            self._save(service_name, spec)
            return
        spec.pid = await self._spawn(spec)
        spec.should_run = True
        spec.result = "success"
        self._save(service_name, spec)

    async def stop(self, service_name: str) -> None:
        spec = self._load(service_name)
        if spec.pid and self._is_alive(spec.pid):
            await asyncio.to_thread(self._kill, spec.pid)
        spec.pid = None
        spec.should_run = False
        self._save(service_name, spec)

    async def restart(self, service_name: str) -> None:
        await self.stop(service_name)
        await self.start(service_name)

    async def reset_failed(self, service_name: str) -> None:
        spec = self._load(service_name)
        spec.crash_timestamps = []
        spec.result = "success"
        self._save(service_name, spec)

    async def remove_unit(self, service_name: str) -> None:
        try:
            await self.stop(service_name)
        except SupervisorError:
            pass
        path = self._state_path(service_name)
        if path.exists():
            path.unlink()

    async def status(self, service_name: str) -> UnitStatus:
        try:
            spec = self._load(service_name)
        except SupervisorError:
            return UnitStatus(active_state="inactive", sub_state="dead", main_pid=0, result="", n_restarts=0)
        alive = self._is_alive(spec.pid)
        return UnitStatus(
            active_state="active" if alive else ("failed" if spec.result == "start-limit-hit" else "inactive"),
            sub_state="running" if alive else ("failed" if spec.result in ("start-limit-hit", "crashed") else "dead"),
            main_pid=spec.pid or 0,
            result=spec.result,
            n_restarts=spec.restart_count,
        )

    # ----------------------------------------------- watcher-driven restart

    async def restart_with_limit_check(self, service_name: str) -> bool:
        """
        Called by the watcher when it finds a bot dead that should be
        running. Restarts it unless it has crashed too many times in
        the burst window, mirroring systemd's StartLimitBurst.
        Returns True if restarted, False if the burst limit was hit.
        """
        spec = self._load(service_name)
        now = time.time()
        timestamps = [t for t in (spec.crash_timestamps or []) if now - t < BURST_WINDOW_SECONDS]
        timestamps.append(now)
        spec.crash_timestamps = timestamps
        spec.restart_count += 1

        if len(timestamps) > BURST_LIMIT:
            spec.result = "start-limit-hit"
            spec.should_run = False
            spec.pid = None
            self._save(service_name, spec)
            return False

        spec.result = "crashed"
        spec.pid = await self._spawn(spec)
        spec.should_run = True
        self._save(service_name, spec)
        return True

"""
BotManager is the orchestration layer: handlers never talk to systemd,
the filesystem, or the DB directly — they go through here. That keeps
every dangerous operation (process control, file deletion, service
creation) behind one auditable, whitelisted surface.
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from pathlib import Path
from typing import AsyncIterator

from app.config import Settings
from app.database import BotRecord, Database
from app.services.installer import InstallStep, Installer
from app.services.log_manager import LogManager
from app.services.process_manager import ProcessStats, get_process_stats
from app.services.process_supervisor import ProcessSupervisor
from app.services.systemd_manager import SystemdManager, UnitStatus
from app.utils.security import mask_secret, slugify
from app.utils.validators import validate_env_key


class BotManagerError(RuntimeError):
    pass


@dataclass
class FullStatus:
    record: BotRecord
    unit: UnitStatus
    process: ProcessStats


class BotManager:
    def __init__(self, settings: Settings, db: Database) -> None:
        self.settings = settings
        self.db = db
        if settings.process_backend == "supervisor":
            self.systemd = ProcessSupervisor(settings.managed_bots_dir, settings.service_prefix)
        else:
            self.systemd = SystemdManager(settings.systemd_unit_dir, settings.systemd_use_sudo, settings.service_prefix)
        self.installer = Installer(settings.managed_bots_dir, settings.max_upload_size_bytes)
        self.logs = LogManager(settings.managed_bots_dir)

    # ------------------------------------------------------------ install

    async def start_install(self, name: str) -> BotRecord:
        bot_id = await self.db.next_bot_id()
        slug = f"{slugify(name)}-{bot_id.split('_')[-1]}"
        source_path = self.installer.bot_dir(bot_id) / "source"
        venv_path = self.installer.bot_dir(bot_id) / "venv"
        service_name = self.systemd.service_name(bot_id)

        return await self.db.add_bot(
            bot_id=bot_id,
            name=name,
            slug=slug,
            source_path=str(source_path),
            venv_path=str(venv_path),
            main_file="",
            service_name=service_name,
        )

    def run_pipeline(self, bot_id: str, zip_bytes: bytes) -> AsyncIterator[InstallStep]:
        return self.installer.install_bot(bot_id, zip_bytes)

    def detect_main_files(self, bot_id: str) -> list[str]:
        return self.installer.detect_main_files(bot_id)

    async def finalize_install(self, bot_id: str, main_file: str) -> tuple[bool, str]:
        """Write the systemd unit, enable + start the bot, and health-check it."""
        bot = await self.db.get_bot(bot_id)
        if bot is None:
            raise BotManagerError("Bot not found.")

        source_dir = Path(bot.source_path)
        venv_path = Path(bot.venv_path)
        python_bin = venv_path / "bin" / "python"
        env_file = self._env_file(bot_id)

        unit_content = self.systemd.render_unit(
            description=f"Managed bot: {bot.name}",
            working_dir=source_dir,
            exec_start=f"{python_bin} {source_dir / main_file}",
            log_path=self.logs.log_path(bot_id),
            env_file=env_file if env_file.exists() else None,
            auto_restart=bot.auto_restart,
        )
        await self.systemd.install_unit(bot.service_name, unit_content)
        await self.systemd.enable(bot.service_name)

        await self.db.update_bot(bot_id, main_file=main_file)

        try:
            await self.systemd.start(bot.service_name)
        except Exception as exc:  # noqa: BLE001 - surfaced to the user as install failure
            await self.db.set_status(bot_id, "failed")
            return False, str(exc)

        ok, reason = await self._health_check(bot.service_name)
        await self.db.set_status(bot_id, "running" if ok else "failed")
        return ok, reason

    async def _health_check(self, service_name: str, attempts: int = 5, delay: float = 1.0) -> tuple[bool, str]:
        for _ in range(attempts):
            await asyncio.sleep(delay)
            status = await self.systemd.status(service_name)
            if status.is_running:
                return True, "running"
            if status.sub_state == "failed":
                return False, f"process exited (result: {status.result or 'unknown'})"
        return False, "startup timed out"

    # ------------------------------------------------------------ lifecycle

    async def start_bot(self, bot_id: str) -> None:
        bot = await self._require_bot(bot_id)
        await self.systemd.reset_failed(bot.service_name)
        await self.systemd.start(bot.service_name)
        await self.db.set_status(bot_id, "running")

    async def stop_bot(self, bot_id: str) -> None:
        bot = await self._require_bot(bot_id)
        await self.systemd.stop(bot.service_name)
        await self.db.set_status(bot_id, "stopped")

    async def restart_bot(self, bot_id: str) -> None:
        bot = await self._require_bot(bot_id)
        await self.systemd.reset_failed(bot.service_name)
        await self.systemd.restart(bot.service_name)
        await self.db.set_status(bot_id, "running")

    async def delete_bot(self, bot_id: str) -> None:
        bot = await self._require_bot(bot_id)
        await self.systemd.remove_unit(bot.service_name)
        self.installer.remove_bot_files(bot_id)
        await self.db.delete_bot(bot_id)

    async def toggle_auto_restart(self, bot_id: str, enabled: bool) -> None:
        bot = await self._require_bot(bot_id)
        await self.db.update_bot(bot_id, auto_restart=enabled)
        source_dir = Path(bot.source_path)
        venv_path = Path(bot.venv_path)
        python_bin = venv_path / "bin" / "python"
        env_file = self._env_file(bot_id)
        unit_content = self.systemd.render_unit(
            description=f"Managed bot: {bot.name}",
            working_dir=source_dir,
            exec_start=f"{python_bin} {source_dir / bot.main_file}",
            log_path=self.logs.log_path(bot_id),
            env_file=env_file if env_file.exists() else None,
            auto_restart=enabled,
        )
        await self.systemd.install_unit(bot.service_name, unit_content)

    # ------------------------------------------------------------- status

    async def get_full_status(self, bot_id: str) -> FullStatus:
        bot = await self._require_bot(bot_id)
        unit = await self.systemd.status(bot.service_name)
        process = await get_process_stats(unit.main_pid)
        return FullStatus(record=bot, unit=unit, process=process)

    async def list_bots(self) -> list[BotRecord]:
        return await self.db.list_bots()

    async def search(self, query: str) -> list[BotRecord]:
        return await self.db.search_bots(query)

    async def _require_bot(self, bot_id: str) -> BotRecord:
        bot = await self.db.get_bot(bot_id)
        if bot is None:
            raise BotManagerError("Bot not found — it may have already been deleted.")
        return bot

    # --------------------------------------------------------- environment

    def _env_file(self, bot_id: str) -> Path:
        return self.installer.bot_dir(bot_id) / ".env"

    async def list_env(self, bot_id: str) -> dict[str, str]:
        path = self._env_file(bot_id)
        if not path.exists():
            return {}
        env: dict[str, str] = {}
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            env[k.strip()] = v.strip()
        return env

    async def list_env_masked(self, bot_id: str) -> dict[str, str]:
        return {k: mask_secret(v) for k, v in (await self.list_env(bot_id)).items()}

    async def set_env(self, bot_id: str, key: str, value: str) -> None:
        if not validate_env_key(key):
            raise BotManagerError("Invalid variable name — use letters, numbers and underscores only.")
        env = await self.list_env(bot_id)
        env[key] = value
        path = self._env_file(bot_id)
        path.write_text(
            "\n".join(f"{k}={v}" for k, v in env.items()) + "\n",
            encoding="utf-8",
        )

    async def delete_env(self, bot_id: str, key: str) -> None:
        env = await self.list_env(bot_id)
        env.pop(key, None)
        path = self._env_file(bot_id)
        path.write_text(
            "\n".join(f"{k}={v}" for k, v in env.items()) + ("\n" if env else ""),
            encoding="utf-8",
        )

    # -------------------------------------------------------------- update

    async def update_source(self, bot_id: str, zip_bytes: bytes) -> AsyncIterator[InstallStep]:
        """Re-run the install pipeline against an existing bot (used by 🔄 Update Bot)."""
        return self.installer.install_bot(bot_id, zip_bytes)

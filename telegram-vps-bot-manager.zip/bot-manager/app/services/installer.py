"""
The install pipeline for a newly uploaded bot.

Every dependency install happens inside that bot's own venv — never
against the system Python — so this is PEP 668 safe by construction
and one bot's dependencies can never collide with another's.

install_bot() is an async generator: each yielded InstallStep lets the
handler edit the Telegram progress message live, matching the spec's
step-by-step upload UI.
"""

from __future__ import annotations

import asyncio
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import AsyncIterator

from app.utils.validators import ZipValidationError, detect_main_files, safe_extract, validate_zip


class InstallError(RuntimeError):
    def __init__(self, step: str, message: str):
        super().__init__(message)
        self.step = step
        self.message = message


@dataclass
class InstallStep:
    key: str
    label: str
    ok: bool = True
    detail: str = ""


@dataclass
class InstallResult:
    source_path: Path
    venv_path: Path
    main_file: str
    candidates: list[str]


async def _run(*argv: str, cwd: Path | None = None) -> tuple[int, str, str]:
    proc = await asyncio.create_subprocess_exec(
        *argv,
        cwd=str(cwd) if cwd else None,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    out, err = await proc.communicate()
    return proc.returncode or 0, out.decode(errors="replace"), err.decode(errors="replace")


class Installer:
    def __init__(self, managed_bots_dir: Path, max_upload_size_bytes: int) -> None:
        self._root = managed_bots_dir
        self._max_size = max_upload_size_bytes

    def bot_dir(self, bot_id: str) -> Path:
        return self._root / bot_id

    async def save_upload(self, bot_id: str, data: bytes) -> Path:
        bot_dir = self.bot_dir(bot_id)
        bot_dir.mkdir(parents=True, exist_ok=True)
        (bot_dir / "logs").mkdir(exist_ok=True)
        zip_path = bot_dir / "_upload.zip"
        zip_path.write_bytes(data)
        return zip_path

    async def extract(self, bot_id: str, zip_path: Path) -> Path:
        bot_dir = self.bot_dir(bot_id)
        source_dir = bot_dir / "source"
        if source_dir.exists():
            shutil.rmtree(source_dir)
        source_dir.mkdir(parents=True)

        report = await asyncio.to_thread(validate_zip, zip_path, source_dir, self._max_size)
        await asyncio.to_thread(safe_extract, zip_path, source_dir)
        zip_path.unlink(missing_ok=True)
        return source_dir

    async def create_venv(self, bot_id: str) -> Path:
        venv_path = self.bot_dir(bot_id) / "venv"
        if venv_path.exists():
            shutil.rmtree(venv_path)
        rc, _, err = await _run("python3", "-m", "venv", str(venv_path))
        if rc != 0:
            raise InstallError("venv", err.strip() or "Could not create virtual environment.")
        return venv_path

    async def install_requirements(self, bot_id: str) -> str:
        source_dir = self.bot_dir(bot_id) / "source"
        venv_path = self.bot_dir(bot_id) / "venv"
        req_file = source_dir / "requirements.txt"
        pip = venv_path / "bin" / "pip"

        if not req_file.exists():
            return "No requirements.txt found — skipping dependency install."

        rc, out, err = await _run(
            str(pip), "install", "--disable-pip-version-check", "--no-input",
            "-r", str(req_file),
            cwd=source_dir,
        )
        if rc != 0:
            raise InstallError("requirements", (err or out).strip()[-2000:])
        return out[-2000:]

    def detect_main_files(self, bot_id: str) -> list[str]:
        return detect_main_files(self.bot_dir(bot_id) / "source")

    async def install_bot(self, bot_id: str, zip_bytes: bytes) -> AsyncIterator[InstallStep]:
        yield InstallStep("received", "File received")

        zip_path = await self.save_upload(bot_id, zip_bytes)

        try:
            await self.extract(bot_id, zip_path)
        except ZipValidationError as exc:
            yield InstallStep("extract", "Archive verified", ok=False, detail=str(exc))
            return
        yield InstallStep("extract", "Archive verified & extracted")

        try:
            venv_path = await self.create_venv(bot_id)
        except InstallError as exc:
            yield InstallStep("venv", "Virtual environment created", ok=False, detail=exc.message)
            return
        yield InstallStep("venv", "Virtual environment created")

        try:
            await self.install_requirements(bot_id)
        except InstallError as exc:
            yield InstallStep("deps", "Dependencies installed", ok=False, detail=exc.message)
            return
        yield InstallStep("deps", "Dependencies installed")

        candidates = self.detect_main_files(bot_id)
        yield InstallStep("mainfile", "Entry file detected", detail=",".join(candidates))

    def remove_bot_files(self, bot_id: str) -> None:
        bot_dir = self.bot_dir(bot_id)
        if bot_dir.exists():
            shutil.rmtree(bot_dir)

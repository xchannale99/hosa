"""
Optional backup/restore for managed bots.

A backup is a zip of the bot's `source/` directory plus a metadata.json
snapshot of its DB row. If BACKUP_ENCRYPTION_KEY is set, the archive is
encrypted at rest with Fernet (symmetric AES). Without a key, backups
are plain zips — still useful, just not encrypted, which is why
secrets/env files are handled specially (see note below).
"""

from __future__ import annotations

import asyncio
import datetime as dt
import json
import shutil
import zipfile
from dataclasses import asdict
from pathlib import Path

from cryptography.fernet import Fernet

from app.database import BotRecord


class BackupError(RuntimeError):
    pass


class BackupManager:
    def __init__(self, backups_dir: Path, managed_bots_dir: Path, encryption_key: str | None) -> None:
        self._root = backups_dir
        self._bots_root = managed_bots_dir
        self._fernet = Fernet(encryption_key.encode()) if encryption_key else None

    def _bot_backup_dir(self, bot_id: str) -> Path:
        d = self._root / bot_id
        d.mkdir(parents=True, exist_ok=True)
        return d

    def _build_zip(self, bot: BotRecord, dest_zip: Path) -> None:
        source_dir = Path(bot.source_path)
        with zipfile.ZipFile(dest_zip, "w", zipfile.ZIP_DEFLATED) as zf:
            for path in source_dir.rglob("*"):
                if path.is_file():
                    zf.write(path, arcname=path.relative_to(source_dir))
            metadata = asdict(bot)
            zf.writestr("__metadata__.json", json.dumps(metadata, indent=2))

    def _create(self, bot: BotRecord) -> Path:
        timestamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%d-%H%M%S")
        raw_zip = self._bot_backup_dir(bot.id) / f"{bot.id}_{timestamp}.zip.tmp"
        self._build_zip(bot, raw_zip)

        final_name = f"{bot.id}_{timestamp}.zip"
        final_path = self._bot_backup_dir(bot.id) / final_name

        if self._fernet:
            data = raw_zip.read_bytes()
            encrypted = self._fernet.encrypt(data)
            final_path = self._bot_backup_dir(bot.id) / f"{final_name}.enc"
            final_path.write_bytes(encrypted)
            raw_zip.unlink()
        else:
            raw_zip.rename(final_path)

        return final_path

    async def create_backup(self, bot: BotRecord) -> Path:
        return await asyncio.to_thread(self._create, bot)

    def list_backups(self, bot_id: str) -> list[Path]:
        d = self._bot_backup_dir(bot_id)
        return sorted(d.glob("*.zip*"), reverse=True)

    def _restore(self, backup_path: Path, target_source_dir: Path) -> None:
        data = backup_path.read_bytes()
        if backup_path.suffix == ".enc":
            if not self._fernet:
                raise BackupError("This backup is encrypted but no BACKUP_ENCRYPTION_KEY is configured.")
            data = self._fernet.decrypt(data)

        tmp_zip = backup_path.with_suffix(".restore.zip")
        tmp_zip.write_bytes(data)
        try:
            if target_source_dir.exists():
                shutil.rmtree(target_source_dir)
            target_source_dir.mkdir(parents=True)
            with zipfile.ZipFile(tmp_zip) as zf:
                for name in zf.namelist():
                    if name == "__metadata__.json":
                        continue
                    zf.extract(name, target_source_dir)
        finally:
            tmp_zip.unlink(missing_ok=True)

    async def restore_backup(self, backup_path: Path, target_source_dir: Path) -> None:
        await asyncio.to_thread(self._restore, backup_path, target_source_dir)

    @staticmethod
    def generate_key() -> str:
        return Fernet.generate_key().decode()

"""
Thin, whitelist-only wrapper around systemd.

This is the ONLY module that shells out to `systemctl`. Every call
builds an argv list (never a shell string), so there is no command
injection surface regardless of what a bot's name or path contains.
Unit filenames are always derived from our own generated service_name
(bot_XXX -> nyx-bot-XXX.service), never from raw user input.
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from pathlib import Path


class SystemdError(RuntimeError):
    pass


@dataclass
class UnitStatus:
    active_state: str      # active | inactive | failed | activating | deactivating
    sub_state: str         # running | dead | failed | start-limit-hit | ...
    main_pid: int
    result: str            # success | exit-code | start-limit-hit | ...
    n_restarts: int

    @property
    def is_running(self) -> bool:
        return self.active_state == "active" and self.sub_state == "running"

    @property
    def is_start_limit_hit(self) -> bool:
        return self.sub_state == "failed" and self.result == "start-limit-hit"


class SystemdManager:
    def __init__(self, unit_dir: Path, use_sudo: bool, service_prefix: str = "nyx-bot-") -> None:
        self._unit_dir = unit_dir
        self._use_sudo = use_sudo
        self._prefix = service_prefix

    def service_name(self, bot_id: str) -> str:
        short = bot_id.replace("bot_", "")
        return f"{self._prefix}{short}.service"

    def unit_path(self, service_name: str) -> Path:
        return self._unit_dir / service_name

    async def _systemctl(self, *args: str) -> tuple[int, str, str]:
        argv: list[str] = ["systemctl"]
        if self._use_sudo:
            argv = ["sudo", "-n", "systemctl"]
        argv.extend(args)
        proc = await asyncio.create_subprocess_exec(
            *argv,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        out, err = await proc.communicate()
        return proc.returncode or 0, out.decode(errors="replace"), err.decode(errors="replace")

    async def daemon_reload(self) -> None:
        rc, _, err = await self._systemctl("daemon-reload")
        if rc != 0:
            raise SystemdError(f"daemon-reload failed: {err.strip()}")

    def render_unit(
        self,
        *,
        description: str,
        working_dir: Path,
        exec_start: str,
        log_path: Path,
        env_file: Path | None,
        auto_restart: bool,
    ) -> str:
        restart_line = "Restart=on-failure" if auto_restart else "Restart=no"
        env_line = f"EnvironmentFile=-{env_file}" if env_file else ""
        return f"""[Unit]
Description={description}
After=network.target

[Service]
Type=simple
WorkingDirectory={working_dir}
ExecStart={exec_start}
{restart_line}
RestartSec=5
StartLimitIntervalSec=60
StartLimitBurst=5
{env_line}
StandardOutput=append:{log_path}
StandardError=append:{log_path}

[Install]
WantedBy=multi-user.target
"""

    async def install_unit(self, service_name: str, unit_content: str) -> None:
        path = self.unit_path(service_name)
        path.write_text(unit_content, encoding="utf-8")
        await self.daemon_reload()

    async def enable(self, service_name: str) -> None:
        rc, _, err = await self._systemctl("enable", service_name)
        if rc != 0:
            raise SystemdError(f"enable failed: {err.strip()}")

    async def disable(self, service_name: str) -> None:
        await self._systemctl("disable", service_name)

    async def start(self, service_name: str) -> None:
        rc, _, err = await self._systemctl("start", service_name)
        if rc != 0:
            raise SystemdError(err.strip() or "start failed")

    async def stop(self, service_name: str) -> None:
        rc, _, err = await self._systemctl("stop", service_name)
        if rc != 0:
            raise SystemdError(err.strip() or "stop failed")

    async def restart(self, service_name: str) -> None:
        rc, _, err = await self._systemctl("restart", service_name)
        if rc != 0:
            raise SystemdError(err.strip() or "restart failed")

    async def reset_failed(self, service_name: str) -> None:
        await self._systemctl("reset-failed", service_name)

    async def remove_unit(self, service_name: str) -> None:
        await self._systemctl("disable", service_name)
        await self._systemctl("stop", service_name)
        path = self.unit_path(service_name)
        if path.exists():
            path.unlink()
        await self.daemon_reload()

    async def status(self, service_name: str) -> UnitStatus:
        rc, out, _ = await self._systemctl(
            "show", service_name,
            "--property=ActiveState,SubState,MainPID,Result,NRestarts",
        )
        props: dict[str, str] = {}
        for line in out.strip().splitlines():
            if "=" in line:
                k, v = line.split("=", 1)
                props[k] = v
        return UnitStatus(
            active_state=props.get("ActiveState", "unknown"),
            sub_state=props.get("SubState", "unknown"),
            main_pid=int(props.get("MainPID", "0") or 0),
            result=props.get("Result", ""),
            n_restarts=int(props.get("NRestarts", "0") or 0),
        )

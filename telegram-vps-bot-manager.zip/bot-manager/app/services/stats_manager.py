"""VPS/container resource stats — shows what's actually allocated to you."""

from __future__ import annotations

import asyncio
import os
import platform
import socket
import time
from dataclasses import dataclass
from pathlib import Path

import psutil

from app.services import container_stats


@dataclass
class VpsStats:
    cpu_percent: float
    cpu_cores: float
    ram_percent: float
    ram_used_mb: float
    ram_total_mb: float
    swap_percent: float
    disk_percent: float
    disk_used_gb: float
    disk_total_gb: float
    load_avg: tuple[float, float, float]
    uptime_seconds: float
    python_version: str
    hostname: str
    scope: str  # "container" or "host" — which numbers below reflect


def _read(base_dir: Path) -> VpsStats:
    limits = container_stats.detect_limits()
    scope = "host"

    # ---- RAM ----
    vm = psutil.virtual_memory()
    ram_total = vm.total
    ram_used = vm.used
    if limits.memory_limit_bytes and limits.memory_limit_bytes < vm.total:
        scope = "container"
        ram_total = limits.memory_limit_bytes
        cgroup_used = container_stats.read_memory_used_bytes()
        ram_used = cgroup_used if cgroup_used is not None else vm.used
    ram_percent = (ram_used / ram_total * 100) if ram_total else 0.0

    # ---- CPU ----
    cpu_cores = limits.cpu_cores or (os.cpu_count() or 1)
    if limits.cpu_cores:
        scope = "container"
        usage_before = container_stats.read_cpu_usage_seconds()
        time.sleep(0.3)
        usage_after = container_stats.read_cpu_usage_seconds()
        if usage_before is not None and usage_after is not None:
            delta = max(0.0, usage_after - usage_before)
            cpu_percent = min(100.0, (delta / (0.3 * limits.cpu_cores)) * 100)
        else:
            cpu_percent = psutil.cpu_percent(interval=0.0)
    else:
        cpu_percent = psutil.cpu_percent(interval=0.3)

    # ---- Disk (measured where the manager actually lives) ----
    disk = psutil.disk_usage(str(base_dir))

    swap = psutil.swap_memory()
    try:
        load = os.getloadavg()
    except (OSError, AttributeError):
        load = (0.0, 0.0, 0.0)
    uptime = time.time() - psutil.boot_time()

    return VpsStats(
        cpu_percent=cpu_percent,
        cpu_cores=cpu_cores,
        ram_percent=ram_percent,
        ram_used_mb=ram_used / (1024 * 1024),
        ram_total_mb=ram_total / (1024 * 1024),
        swap_percent=swap.percent,
        disk_percent=disk.percent,
        disk_used_gb=disk.used / (1024 ** 3),
        disk_total_gb=disk.total / (1024 ** 3),
        load_avg=load,
        uptime_seconds=uptime,
        python_version=platform.python_version(),
        hostname=socket.gethostname(),
        scope=scope,
    )


async def get_vps_stats(base_dir: Path) -> VpsStats:
    return await asyncio.to_thread(_read, base_dir)

"""System-wide VPS resource stats."""

from __future__ import annotations

import asyncio
import os
import platform
import socket
import time
from dataclasses import dataclass

import psutil


@dataclass
class VpsStats:
    cpu_percent: float
    ram_percent: float
    ram_used_mb: float
    ram_total_mb: float
    swap_percent: float
    disk_percent: float
    disk_used_gb: float
    disk_total_gb: float
    load_avg: tuple[float, float, float]
    uptime_seconds: float
    python_version: str
    hostname: str


def _read() -> VpsStats:
    cpu = psutil.cpu_percent(interval=0.3)
    vm = psutil.virtual_memory()
    swap = psutil.swap_memory()
    disk = psutil.disk_usage("/")
    try:
        load = os.getloadavg()
    except (OSError, AttributeError):
        load = (0.0, 0.0, 0.0)
    uptime = time.time() - psutil.boot_time()

    return VpsStats(
        cpu_percent=cpu,
        ram_percent=vm.percent,
        ram_used_mb=vm.used / (1024 * 1024),
        ram_total_mb=vm.total / (1024 * 1024),
        swap_percent=swap.percent,
        disk_percent=disk.percent,
        disk_used_gb=disk.used / (1024 ** 3),
        disk_total_gb=disk.total / (1024 ** 3),
        load_avg=load,
        uptime_seconds=uptime,
        python_version=platform.python_version(),
        hostname=socket.gethostname(),
    )


async def get_vps_stats() -> VpsStats:
    return await asyncio.to_thread(_read)

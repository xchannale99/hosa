"""
Container-aware resource limits.

psutil reports HOST-wide CPU/RAM. Inside a container that's only given
a slice of a bigger machine, that's misleading — it'll show the whole
host's 32 GB RAM even if your container is capped at 512 MB. This
reads the container's actual cgroup limits (v2 first, v1 fallback) so
"VPS Stats" shows what you actually have to work with.

On a real dedicated VPS (no cgroup limits set), everything here
returns None and stats_manager falls back to plain host-wide psutil
numbers — exactly as before.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

_V2_MEM_MAX = Path("/sys/fs/cgroup/memory.max")
_V2_MEM_CUR = Path("/sys/fs/cgroup/memory.current")
_V2_CPU_MAX = Path("/sys/fs/cgroup/cpu.max")
_V2_CPU_STAT = Path("/sys/fs/cgroup/cpu.stat")

_V1_MEM_LIMIT = Path("/sys/fs/cgroup/memory/memory.limit_in_bytes")
_V1_MEM_USAGE = Path("/sys/fs/cgroup/memory/memory.usage_in_bytes")
_V1_CPU_QUOTA = Path("/sys/fs/cgroup/cpu/cpu.cfs_quota_us")
_V1_CPU_PERIOD = Path("/sys/fs/cgroup/cpu/cpu.cfs_period_us")
_V1_CPUACCT_USAGE = Path("/sys/fs/cgroup/cpuacct/cpuacct.usage")

# cgroup v1 represents "no limit" as a huge number close to int64 max.
_NO_LIMIT_SENTINEL = 1 << 62


def _read_int(path: Path) -> int | None:
    try:
        text = path.read_text().strip()
    except OSError:
        return None
    if text == "max":
        return None
    try:
        return int(text)
    except ValueError:
        return None


@dataclass
class ContainerLimits:
    memory_limit_bytes: int | None  # None = no cgroup limit found
    cpu_cores: float | None         # None = no cgroup CPU quota found


def detect_limits() -> ContainerLimits:
    if _V2_MEM_MAX.exists():
        mem = _read_int(_V2_MEM_MAX)
        cpu_cores = None
        if _V2_CPU_MAX.exists():
            try:
                parts = _V2_CPU_MAX.read_text().split()
                if parts and parts[0] != "max":
                    cpu_cores = int(parts[0]) / int(parts[1])
            except (OSError, ValueError, IndexError, ZeroDivisionError):
                cpu_cores = None
        return ContainerLimits(memory_limit_bytes=mem, cpu_cores=cpu_cores)

    if _V1_MEM_LIMIT.exists():
        mem = _read_int(_V1_MEM_LIMIT)
        if mem is not None and mem >= _NO_LIMIT_SENTINEL:
            mem = None
        cpu_cores = None
        quota = _read_int(_V1_CPU_QUOTA)
        period = _read_int(_V1_CPU_PERIOD)
        if quota and quota > 0 and period:
            cpu_cores = quota / period
        return ContainerLimits(memory_limit_bytes=mem, cpu_cores=cpu_cores)

    return ContainerLimits(memory_limit_bytes=None, cpu_cores=None)


def read_memory_used_bytes() -> int | None:
    if _V2_MEM_CUR.exists():
        return _read_int(_V2_MEM_CUR)
    if _V1_MEM_USAGE.exists():
        return _read_int(_V1_MEM_USAGE)
    return None


def read_cpu_usage_seconds() -> float | None:
    """Cumulative CPU time this cgroup has consumed, in seconds."""
    if _V2_CPU_STAT.exists():
        try:
            for line in _V2_CPU_STAT.read_text().splitlines():
                if line.startswith("usage_usec"):
                    return int(line.split()[1]) / 1_000_000
        except (OSError, ValueError, IndexError):
            return None
        return None
    if _V1_CPUACCT_USAGE.exists():
        val = _read_int(_V1_CPUACCT_USAGE)
        return val / 1_000_000_000 if val is not None else None
    return None

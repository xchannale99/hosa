"""
Background poller that keeps the DB in sync with reality and notifies
admins about crashes.

systemd (via Restart=on-failure) already handles the actual restarting;
this task's job is only to observe, record, and notify — it never
fights with systemd's own restart logic.
"""

from __future__ import annotations

import asyncio
import datetime as dt
import logging

from aiogram import Bot

from app.emoji import render
from app.services.bot_manager import BotManager

logger = logging.getLogger("manager")

POLL_INTERVAL_SECONDS = 15


async def watch_loop(bot: Bot, bot_manager: BotManager, admin_ids: frozenset[int]) -> None:
    known_active: dict[str, bool] = {}

    while True:
        try:
            await _poll_once(bot, bot_manager, admin_ids, known_active)
        except asyncio.CancelledError:
            raise
        except Exception:  # noqa: BLE001 - watcher must never die
            logger.exception("watcher loop iteration failed")
        await asyncio.sleep(POLL_INTERVAL_SECONDS)


async def _poll_once(bot: Bot, bot_manager: BotManager, admin_ids: frozenset[int], known_active: dict[str, bool]) -> None:
    bots = await bot_manager.list_bots()
    for record in bots:
        if record.status not in ("running", "failed"):
            continue

        status = await bot_manager.systemd.status(record.service_name)
        was_active = known_active.get(record.id, status.is_running)
        known_active[record.id] = status.is_running

        if status.n_restarts != record.restart_count:
            await bot_manager.db.increment_restart_count(record.id, to_value=status.n_restarts)

        if status.is_start_limit_hit:
            await bot_manager.db.set_status(record.id, "stopped")
            await _notify(
                bot, admin_ids,
                f"⚠️ <b>Bot repeatedly crashed.</b>\n\n"
                f"🤖 Bot: {record.name}\n\nRestart limit reached.\n"
                f"Bot has been stopped automatically.",
            )
            continue

        if was_active and not status.is_running:
            restarted = False
            if record.auto_restart and getattr(bot_manager.systemd, "requires_active_restart", False):
                restarted = await bot_manager.systemd.restart_with_limit_check(record.service_name)
                if not restarted:
                    await bot_manager.db.set_status(record.id, "stopped")
                    await _notify(
                        bot, admin_ids,
                        f"⚠️ <b>Bot repeatedly crashed.</b>\n\n"
                        f"🤖 Bot: {record.name}\n\nRestart limit reached.\n"
                        f"Bot has been stopped automatically.",
                    )
                    continue

            await bot_manager.db.set_status(record.id, "crashed" if record.auto_restart else "stopped")
            when = dt.datetime.now().strftime("%H:%M:%S")
            await _notify(
                bot, admin_ids,
                f"{render('error')} <b>Bot crashed</b>\n\n"
                f"🤖 Bot: {record.name}\n⏰ Time: {when}\n"
                f"🔄 Auto Restart: {'Enabled' if record.auto_restart else 'Disabled'}\n\n"
                f"{'♻️ Restarted.' if restarted else ('♻️ Restarting...' if record.auto_restart else 'Bot is stopped.')}",
            )
        elif not was_active and status.is_running:
            await bot_manager.db.set_status(record.id, "running")


async def _notify(bot: Bot, admin_ids: frozenset[int], text: str) -> None:
    for admin_id in admin_ids:
        try:
            await bot.send_message(admin_id, text)
        except Exception:  # noqa: BLE001 - one admin's blocked chat shouldn't stop the others
            logger.warning("failed to notify admin %s", admin_id)

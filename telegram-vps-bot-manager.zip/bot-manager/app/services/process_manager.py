"""Per-process resource stats for a single managed bot, via psutil."""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass

import psutil


@dataclass
class ProcessStats:
    pid: int
    cpu_percent: float
    ram_mb: float
    uptime_seconds: float
    alive: bool


def _read(pid: int) -> ProcessStats:
    if pid <= 0:
        return ProcessStats(pid=0, cpu_percent=0.0, ram_mb=0.0, uptime_seconds=0.0, alive=False)
    try:
        proc = psutil.Process(pid)
        cpu = proc.cpu_percent(interval=0.15)
        mem = proc.memory_info().rss / (1024 * 1024)
        uptime = max(0.0, time.time() - proc.create_time())
        return ProcessStats(pid=pid, cpu_percent=cpu, ram_mb=mem, uptime_seconds=uptime, alive=True)
    except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
        return ProcessStats(pid=pid, cpu_percent=0.0, ram_mb=0.0, uptime_seconds=0.0, alive=False)


async def get_process_stats(pid: int) -> ProcessStats:
    return await asyncio.to_thread(_read, pid)

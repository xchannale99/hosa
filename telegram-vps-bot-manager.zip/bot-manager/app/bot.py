"""
Entry point.

    python -m app.bot

Wires together config -> database -> services -> middleware -> handlers,
then starts long polling. Meant to run under its own systemd service
(see install.sh) so it survives reboots just like the bots it manages.
"""

from __future__ import annotations

import asyncio
import logging

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.exceptions import TelegramBadRequest
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import ErrorEvent

from app.config import load_settings
from app.database import Database
from app.handlers import bots as bots_handlers
from app.handlers import logs as logs_handlers
from app.handlers import manager as manager_handlers
from app.handlers import search as search_handlers
from app.handlers import settings as settings_handlers
from app.handlers import start as start_handlers
from app.handlers import stats as stats_handlers
from app.handlers import upload as upload_handlers
from app.logging_setup import setup_logging
from app.middleware.auth import AuthMiddleware
from app.services.backup_manager import BackupManager
from app.services.bot_manager import BotManager
from app.services.watcher import watch_loop

logger = logging.getLogger("manager")


async def main() -> None:
    settings = load_settings()
    setup_logging(settings.logs_dir, settings.log_level)
    logger.info("starting VPS Bot Manager (base_dir=%s)", settings.base_dir)

    db = Database(settings.database_path)
    await db.connect()

    bot_manager = BotManager(settings, db)
    backup_manager = BackupManager(settings.backups_dir, settings.managed_bots_dir, settings.backup_encryption_key)

    bot = Bot(token=settings.bot_token, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = Dispatcher(storage=MemoryStorage())

    dp["settings"] = settings
    dp["bot_manager"] = bot_manager
    dp["backup_manager"] = backup_manager

    auth = AuthMiddleware(settings, db)
    dp.message.outer_middleware(auth)
    dp.callback_query.outer_middleware(auth)

    dp.include_router(start_handlers.router)
    dp.include_router(upload_handlers.router)
    dp.include_router(bots_handlers.router)
    dp.include_router(stats_handlers.router)
    dp.include_router(logs_handlers.router)
    dp.include_router(settings_handlers.router)
    dp.include_router(search_handlers.router)
    dp.include_router(manager_handlers.router)

    @dp.errors()
    async def on_error(event: ErrorEvent) -> bool:
        if isinstance(event.exception, TelegramBadRequest) and "message is not modified" in str(event.exception).lower():
            # Harmless: user tapped Refresh/etc. with nothing new to show.
            return True

        logger.exception("unhandled error while processing update", exc_info=event.exception)
        update = event.update
        chat = None
        if update.message:
            chat = update.message.chat.id
        elif update.callback_query and update.callback_query.message:
            chat = update.callback_query.message.chat.id
        if chat is not None:
            try:
                await bot.send_message(
                    chat,
                    "❌ <b>Something went wrong.</b>\n\nThe error has been logged. Please try again.",
                )
            except Exception:  # noqa: BLE001
                pass
        return True

    watcher_task = asyncio.create_task(watch_loop(bot, bot_manager, settings.admin_ids))

    try:
        await dp.start_polling(bot)
    finally:
        watcher_task.cancel()
        await db.close()
        await bot.session.close()


if __name__ == "__main__":
    asyncio.run(main())

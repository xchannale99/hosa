#!/usr/bin/env bash
# Stops both the watchdog loop and the running manager process.
set -u
cd "$(dirname "${BASH_SOURCE[0]}")"

if [ -f logs/watchdog.pid ]; then
    pid="$(cat logs/watchdog.pid)"
    kill "$pid" 2>/dev/null && echo "Stopped watchdog (pid $pid)"
    rm -f logs/watchdog.pid
fi

pkill -f "\.venv/bin/python -m app\.bot" 2>/dev/null && echo "Stopped manager process"

echo "Done."

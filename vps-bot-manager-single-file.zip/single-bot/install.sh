#!/usr/bin/env bash
# One-time setup for the single-file VPS Bot Manager. No root required.
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"

echo "== VPS Bot Manager (single-file) setup =="
command -v python3 >/dev/null || { echo "python3 not found."; exit 1; }
echo "Python: $(python3 -c 'import sys;print(f"{sys.version_info[0]}.{sys.version_info[1]}")')"

mkdir -p managed_bots database logs backups

if [ ! -d ".venv" ]; then
    echo "Creating virtual environment..."
    python3 -m venv .venv
fi
echo "Installing dependencies..."
.venv/bin/pip install --disable-pip-version-check -q -r requirements.txt

echo
echo "!! এখন bot.py খুলে উপরের CONFIG সেকশনে BOT_TOKEN আর ADMIN_IDS বসান:"
echo "   nano bot.py"
echo
echo "তারপর চালু করুন:"
echo "   nohup ./run_manager.sh > /dev/null 2>&1 & disown"
echo
echo "== Setup complete =="

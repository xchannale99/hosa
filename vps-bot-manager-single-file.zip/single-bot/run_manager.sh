#!/usr/bin/env bash
# Keeps bot.py alive WITHOUT systemd/root.
# Start detached:  nohup ./run_manager.sh > /dev/null 2>&1 & disown
# Stop cleanly:    ./stop_manager.sh
set -u
cd "$(dirname "${BASH_SOURCE[0]}")"
mkdir -p logs

echo "$$" > logs/watchdog.pid
echo "$(date '+%F %T') watchdog started (pid $$)" >> logs/watchdog.log

while true; do
    echo "$(date '+%F %T') starting bot.py" >> logs/watchdog.log
    .venv/bin/python bot.py >> logs/manager_stdout.log 2>&1
    code=$?
    echo "$(date '+%F %T') bot.py exited (code $code) — restarting in 5s" >> logs/watchdog.log
    sleep 5
done

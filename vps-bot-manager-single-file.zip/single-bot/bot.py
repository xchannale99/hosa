# -*- coding: utf-8 -*-
"""
============================================================
  VPS BOT MANAGER — single-file edition
  Telegram bot that installs/runs/monitors other Python bots
  on this VPS, with no systemd/root required.
============================================================
"""

import asyncio
import json
import logging
import os
import platform
import shlex
import shutil
import signal
import socket
import sqlite3
import time
import zipfile
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, AsyncIterator, Optional

import psutil
from aiogram import Bot, Dispatcher, F
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.exceptions import TelegramBadRequest
from aiogram.filters import Command, CommandStart
from aiogram.filters.callback_data import CallbackData
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import (
    BufferedInputFile,
    CallbackQuery,
    ErrorEvent,
    FSInputFile,
    KeyboardButton,
    Message,
    ReplyKeyboardMarkup,
    ReplyKeyboardRemove,
)
from aiogram.utils.keyboard import InlineKeyboardBuilder

# ============================================================
# CONFIG — EDIT THESE VALUES
# ============================================================
BOT_TOKEN = "8864825024:AAG1G39F38T9jFPzQ1idoVhRXQwdqf1Wmv0"
ADMIN_IDS = {6849685931}          # your Telegram numeric user id(s)
BASE_DIR = Path(__file__).resolve().parent
MAX_UPLOAD_SIZE_MB = 100
LOG_LEVEL = "INFO"
SERVICE_PREFIX = "nyx-bot-"
# ============================================================

MANAGED_BOTS_DIR = BASE_DIR / "managed_bots"
DATABASE_PATH = BASE_DIR / "database" / "manager.db"
LOGS_DIR = BASE_DIR / "logs"
BACKUPS_DIR = BASE_DIR / "backups"
MAX_UPLOAD_SIZE_BYTES = MAX_UPLOAD_SIZE_MB * 1024 * 1024

for _d in (MANAGED_BOTS_DIR, DATABASE_PATH.parent, LOGS_DIR, BACKUPS_DIR):
    _d.mkdir(parents=True, exist_ok=True)

# ============================================================
# LOGGING
# ============================================================
logging.basicConfig(level=LOG_LEVEL, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
_file_handler = logging.FileHandler(LOGS_DIR / "manager.log", encoding="utf-8")
_file_handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
logger = logging.getLogger("manager")
logger.addHandler(_file_handler)
logger.setLevel(LOG_LEVEL)

# ============================================================
# HACKER-STYLE UI HELPERS
# ============================================================
_FANCY_MAP = {}
_UPPER_START, _LOWER_START, _DIGIT_START = 0x1D5D4, 0x1D5EE, 0x1D7EC
for _i, _c in enumerate("ABCDEFGHIJKLMNOPQRSTUVWXYZ"):
    _FANCY_MAP[_c] = chr(_UPPER_START + _i)
for _i, _c in enumerate("abcdefghijklmnopqrstuvwxyz"):
    _FANCY_MAP[_c] = chr(_LOWER_START + _i)
for _i, _c in enumerate("0123456789"):
    _FANCY_MAP[_c] = chr(_DIGIT_START + _i)


def fancy(text: str) -> str:
    """Render ASCII text in bold sans-serif unicode — a distinct 'font' look."""
    return "".join(_FANCY_MAP.get(c, c) for c in text)


def banner(title: str) -> str:
    line = "▓" * 30
    return f"{line}\n   {fancy(title.upper())}\n{line}"


def hr() -> str:
    return "─" * 26


def progress_bar(percent: float, length: int = 12) -> str:
    percent = max(0.0, min(100.0, percent))
    filled = round(length * percent / 100)
    return "█" * filled + "░" * (length - filled)


def status_dot(status: str) -> str:
    return {
        "running": "🟢", "stopped": "🔴", "installing": "🟡",
        "failed": "🔴", "crashed": "🟠",
    }.get(status, "⚪")


def human_size(num_bytes: float) -> str:
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if num_bytes < 1024 or unit == "TB":
            return f"{int(num_bytes)} {unit}" if unit == "B" else f"{num_bytes:.1f} {unit}"
        num_bytes /= 1024
    return f"{num_bytes:.1f} TB"


def human_duration_long(seconds: float) -> str:
    seconds = int(seconds)
    days, seconds = divmod(seconds, 86400)
    hours, seconds = divmod(seconds, 3600)
    minutes, _ = divmod(seconds, 60)
    parts = []
    if days: parts.append(f"{days}d")
    if hours: parts.append(f"{hours}h")
    if not days and minutes: parts.append(f"{minutes}m")
    return " ".join(parts) if parts else "just now"


def human_duration_short(seconds: float) -> str:
    seconds = int(seconds)
    days, seconds = divmod(seconds, 86400)
    hours, seconds = divmod(seconds, 3600)
    minutes, _ = divmod(seconds, 60)
    if days: return f"{days}d {hours}h"
    if hours: return f"{hours}h {minutes}m"
    return f"{minutes}m"


def mask_secret(value: str) -> str:
    if not value:
        return "••••••••"
    if len(value) <= 6:
        return "•" * len(value)
    return f"{value[:4]}{'•' * 8}{value[-3:]}"


def truncate(text: str, limit: int = 3500) -> str:
    return text if len(text) <= limit else text[-limit:]


def slugify(name: str) -> str:
    import re
    slug = re.sub(r"[^a-z0-9]+", "-", name.strip().lower()).strip("-")
    return slug or "bot"

# ============================================================
# DATABASE (sync sqlite3, wrapped via asyncio.to_thread)
# ============================================================
_DB_LOCK = None  # set in main() to a threading.Lock via to_thread safety

_SCHEMA = """
CREATE TABLE IF NOT EXISTS bots (
    id TEXT PRIMARY KEY, name TEXT NOT NULL, slug TEXT NOT NULL UNIQUE,
    description TEXT NOT NULL DEFAULT '', source_path TEXT NOT NULL,
    venv_path TEXT NOT NULL, main_file TEXT NOT NULL,
    service_name TEXT NOT NULL UNIQUE, status TEXT NOT NULL DEFAULT 'stopped',
    auto_restart INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL, restart_count INTEGER NOT NULL DEFAULT 0,
    last_started_at TEXT, last_stopped_at TEXT
);
CREATE TABLE IF NOT EXISTS audit_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT, admin_id INTEGER NOT NULL,
    action TEXT NOT NULL, bot_id TEXT, timestamp TEXT NOT NULL,
    result TEXT NOT NULL, detail TEXT
);
"""


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _conn() -> sqlite3.Connection:
    c = sqlite3.connect(DATABASE_PATH)
    c.row_factory = sqlite3.Row
    return c


def _db_init() -> None:
    c = _conn()
    c.executescript(_SCHEMA)
    c.commit()
    c.close()


@dataclass
class BotRecord:
    id: str; name: str; slug: str; description: str; source_path: str
    venv_path: str; main_file: str; service_name: str; status: str
    auto_restart: bool; created_at: str; updated_at: str; restart_count: int
    last_started_at: Optional[str]; last_stopped_at: Optional[str]

    @staticmethod
    def from_row(row: sqlite3.Row) -> "BotRecord":
        d = dict(row)
        d["auto_restart"] = bool(d["auto_restart"])
        return BotRecord(**d)


def _db_add_bot(bot_id, name, slug, source_path, venv_path, main_file, service_name) -> None:
    now = _now()
    c = _conn()
    c.execute(
        "INSERT INTO bots (id,name,slug,description,source_path,venv_path,main_file,"
        "service_name,status,auto_restart,created_at,updated_at,restart_count,"
        "last_started_at,last_stopped_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,0,NULL,NULL)",
        (bot_id, name, slug, "", source_path, venv_path, main_file, service_name,
         "installing", 1, now, now),
    )
    c.commit(); c.close()


def _db_get_bot(bot_id: str) -> Optional[BotRecord]:
    c = _conn()
    row = c.execute("SELECT * FROM bots WHERE id = ?", (bot_id,)).fetchone()
    c.close()
    return BotRecord.from_row(row) if row else None


def _db_list_bots() -> list:
    c = _conn()
    rows = c.execute("SELECT * FROM bots ORDER BY created_at ASC").fetchall()
    c.close()
    return [BotRecord.from_row(r) for r in rows]


def _db_search_bots(query: str) -> list:
    c = _conn()
    rows = c.execute("SELECT * FROM bots WHERE name LIKE ? ORDER BY name ASC", (f"%{query}%",)).fetchall()
    c.close()
    return [BotRecord.from_row(r) for r in rows]


def _db_update_bot(bot_id: str, **fields) -> None:
    if not fields:
        return
    fields["updated_at"] = _now()
    if "auto_restart" in fields:
        fields["auto_restart"] = int(bool(fields["auto_restart"]))
    cols = ", ".join(f"{k} = ?" for k in fields)
    vals = list(fields.values()) + [bot_id]
    c = _conn()
    c.execute(f"UPDATE bots SET {cols} WHERE id = ?", vals)
    c.commit(); c.close()


def _db_set_status(bot_id: str, status: str) -> None:
    extra = {}
    if status == "running": extra["last_started_at"] = _now()
    elif status == "stopped": extra["last_stopped_at"] = _now()
    _db_update_bot(bot_id, status=status, **extra)


def _db_set_restart_count(bot_id: str, value: int) -> None:
    _db_update_bot(bot_id, restart_count=value)


def _db_delete_bot(bot_id: str) -> None:
    c = _conn()
    c.execute("DELETE FROM bots WHERE id = ?", (bot_id,))
    c.commit(); c.close()


def _db_next_bot_id() -> str:
    c = _conn()
    rows = c.execute("SELECT id FROM bots").fetchall()
    c.close()
    used = set()
    for r in rows:
        try: used.add(int(r["id"].split("_")[-1]))
        except (ValueError, IndexError): pass
    n = 1
    while n in used: n += 1
    return f"bot_{n:03d}"


def _db_log_audit(admin_id: int, action: str, bot_id: Optional[str], result: str, detail: str = None) -> None:
    c = _conn()
    c.execute(
        "INSERT INTO audit_logs (admin_id,action,bot_id,timestamp,result,detail) VALUES (?,?,?,?,?,?)",
        (admin_id, action, bot_id, _now(), result, detail),
    )
    c.commit(); c.close()


def _db_get_audit_logs(limit: int = 15) -> list:
    c = _conn()
    rows = c.execute("SELECT * FROM audit_logs ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    c.close()
    return [dict(r) for r in rows]


async def db_add_bot(*a, **kw): return await asyncio.to_thread(_db_add_bot, *a, **kw)
async def db_get_bot(bot_id): return await asyncio.to_thread(_db_get_bot, bot_id)
async def db_list_bots(): return await asyncio.to_thread(_db_list_bots)
async def db_search_bots(q): return await asyncio.to_thread(_db_search_bots, q)
async def db_update_bot(bot_id, **f): return await asyncio.to_thread(_db_update_bot, bot_id, **f)
async def db_set_status(bot_id, s): return await asyncio.to_thread(_db_set_status, bot_id, s)
async def db_set_restart_count(bot_id, v): return await asyncio.to_thread(_db_set_restart_count, bot_id, v)
async def db_delete_bot(bot_id): return await asyncio.to_thread(_db_delete_bot, bot_id)
async def db_next_bot_id(): return await asyncio.to_thread(_db_next_bot_id)
async def db_log_audit(*a, **kw): return await asyncio.to_thread(_db_log_audit, *a, **kw)
async def db_get_audit_logs(limit=15): return await asyncio.to_thread(_db_get_audit_logs, limit)

# ============================================================
# ZIP SAFETY + INSTALLER
# ============================================================
MAIN_FILE_CANDIDATES = ("bot.py", "main.py", "app.py", "run.py")


class ZipValidationError(ValueError):
    pass


class InstallError(RuntimeError):
    def __init__(self, step: str, message: str):
        super().__init__(message)
        self.step = step
        self.message = message


def _safe_member_path(name: str, dest_root: Path) -> Optional[Path]:
    if name.startswith("/") or name.startswith("\\"):
        return None
    candidate = (dest_root / name).resolve()
    try:
        candidate.relative_to(dest_root.resolve())
    except ValueError:
        return None
    return candidate


def _validate_zip(zip_path: Path, dest_root: Path) -> None:
    if not zipfile.is_zipfile(zip_path):
        raise ZipValidationError("এটা বৈধ ZIP ফাইল না।")
    total_uncompressed = total_compressed = file_count = 0
    with zipfile.ZipFile(zip_path) as zf:
        infos = zf.infolist()
        if not infos:
            raise ZipValidationError("Archive খালি।")
        if len(infos) > 5000:
            raise ZipValidationError("অনেক বেশি ফাইল আছে archive-এ।")
        for info in infos:
            unix_mode = info.external_attr >> 16
            if unix_mode and (unix_mode & 0xF000) == 0xA000:
                raise ZipValidationError(f"Symlink allowed না: {info.filename}")
            if _safe_member_path(info.filename, dest_root) is None:
                raise ZipValidationError(f"Unsafe path: {info.filename}")
            file_count += 1
            total_uncompressed += info.file_size
            total_compressed += info.compress_size
            if total_uncompressed > MAX_UPLOAD_SIZE_BYTES:
                raise ZipValidationError(f"Archive সাইজ লিমিট ({MAX_UPLOAD_SIZE_MB}MB) ছাড়িয়ে গেছে।")
        if total_compressed > 0 and (total_uncompressed / max(total_compressed, 1)) > 200:
            raise ZipValidationError("সন্দেহজনক compression ratio (zip bomb?)।")


def _safe_extract(zip_path: Path, dest_root: Path) -> None:
    dest_root.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path) as zf:
        for info in zf.infolist():
            target = _safe_member_path(info.filename, dest_root)
            if target is None:
                raise ZipValidationError(f"Unsafe path during extraction: {info.filename}")
            if info.is_dir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            with zf.open(info) as src, open(target, "wb") as dst:
                dst.write(src.read())
        roots = {n.split("/", 1)[0] for n in zf.namelist() if n.strip("/")}
    if len(roots) == 1:
        wrapped = dest_root / next(iter(roots))
        if wrapped.is_dir():
            for item in wrapped.iterdir():
                item.rename(dest_root / item.name)
            wrapped.rmdir()


def _detect_main_files(source_dir: Path) -> list:
    return [c for c in MAIN_FILE_CANDIDATES if (source_dir / c).is_file()]


async def _run_cmd(*argv, cwd=None):
    proc = await asyncio.create_subprocess_exec(
        *argv, cwd=str(cwd) if cwd else None,
        stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
    )
    out, err = await proc.communicate()
    return proc.returncode or 0, out.decode(errors="replace"), err.decode(errors="replace")


def bot_dir(bot_id: str) -> Path:
    return MANAGED_BOTS_DIR / bot_id


@dataclass
class InstallStep:
    key: str; label: str; ok: bool = True; detail: str = ""


async def install_pipeline(bot_id: str, zip_bytes: bytes) -> AsyncIterator[InstallStep]:
    yield InstallStep("received", "File received")

    bdir = bot_dir(bot_id)
    bdir.mkdir(parents=True, exist_ok=True)
    (bdir / "logs").mkdir(exist_ok=True)
    zip_path = bdir / "_upload.zip"
    zip_path.write_bytes(zip_bytes)

    source_dir = bdir / "source"
    if source_dir.exists():
        shutil.rmtree(source_dir)
    source_dir.mkdir(parents=True)
    try:
        await asyncio.to_thread(_validate_zip, zip_path, source_dir)
        await asyncio.to_thread(_safe_extract, zip_path, source_dir)
        zip_path.unlink(missing_ok=True)
    except ZipValidationError as exc:
        yield InstallStep("extract", "Archive verified", ok=False, detail=str(exc))
        return
    yield InstallStep("extract", "Archive verified & extracted")

    venv_path = bdir / "venv"
    if venv_path.exists():
        shutil.rmtree(venv_path)
    rc, _, err = await _run_cmd("python3", "-m", "venv", str(venv_path))
    if rc != 0:
        yield InstallStep("venv", "Virtual environment created", ok=False, detail=err.strip())
        return
    yield InstallStep("venv", "Virtual environment created")

    req_file = source_dir / "requirements.txt"
    if req_file.exists():
        pip = venv_path / "bin" / "pip"
        rc, out, err = await _run_cmd(
            str(pip), "install", "--disable-pip-version-check", "--no-input",
            "-r", str(req_file), cwd=source_dir,
        )
        if rc != 0:
            yield InstallStep("deps", "Dependencies installed", ok=False, detail=(err or out)[-1500:])
            return
    yield InstallStep("deps", "Dependencies installed")

    candidates = _detect_main_files(source_dir)
    yield InstallStep("mainfile", "Entry file detected", detail=",".join(candidates))


def remove_bot_files(bot_id: str) -> None:
    bdir = bot_dir(bot_id)
    if bdir.exists():
        shutil.rmtree(bdir)

# ============================================================
# PROCESS SUPERVISOR (no root / no systemd needed)
# ============================================================
SUPERVISOR_STATE_DIR = MANAGED_BOTS_DIR / "_supervisor_state"
SUPERVISOR_STATE_DIR.mkdir(parents=True, exist_ok=True)
BURST_WINDOW_SECONDS = 60
BURST_LIMIT = 5


class SupervisorError(RuntimeError):
    pass


@dataclass
class UnitStatus:
    active_state: str; sub_state: str; main_pid: int; result: str; n_restarts: int

    @property
    def is_running(self) -> bool:
        return self.active_state == "active" and self.sub_state == "running"

    @property
    def is_start_limit_hit(self) -> bool:
        return self.sub_state == "failed" and self.result == "start-limit-hit"


def service_name(bot_id: str) -> str:
    return f"{SERVICE_PREFIX}{bot_id.replace('bot_', '')}"


def _spec_path(svc: str) -> Path:
    return SUPERVISOR_STATE_DIR / f"{svc}.json"


def _spec_load(svc: str) -> dict:
    p = _spec_path(svc)
    if not p.exists():
        raise SupervisorError(f"{svc}-এর কোনো process record নেই।")
    data = json.loads(p.read_text(encoding="utf-8"))
    data.setdefault("crash_timestamps", [])
    return data


def _spec_save(svc: str, spec: dict) -> None:
    _spec_path(svc).write_text(json.dumps(spec), encoding="utf-8")


def create_spec(bot_id: str, main_file: str, auto_restart: bool) -> None:
    bdir = bot_dir(bot_id)
    source_dir = bdir / "source"
    venv_py = bdir / "venv" / "bin" / "python"
    log_path = bdir / "logs" / "output.log"
    log_path.parent.mkdir(parents=True, exist_ok=True)
    env_file = bdir / ".env"
    spec = {
        "argv": [str(venv_py), str(source_dir / main_file)],
        "cwd": str(source_dir),
        "log_path": str(log_path),
        "env_file": str(env_file) if env_file.exists() else None,
        "auto_restart": auto_restart,
        "enabled": False, "should_run": False, "pid": None,
        "restart_count": 0, "crash_timestamps": [], "result": "",
    }
    svc = service_name(bot_id)
    try:
        old = _spec_load(svc)
        spec["pid"] = old.get("pid")
        spec["restart_count"] = old.get("restart_count", 0)
        spec["should_run"] = old.get("should_run", False)
    except SupervisorError:
        pass
    _spec_save(svc, spec)


def _load_env_dict(env_file: Optional[str]) -> dict:
    env = os.environ.copy()
    if env_file and Path(env_file).exists():
        for line in Path(env_file).read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            env[k.strip()] = v.strip()
    return env


async def _spawn(spec: dict) -> int:
    log_path = Path(spec["log_path"])
    log_path.parent.mkdir(parents=True, exist_ok=True)
    log_fh = open(log_path, "ab", buffering=0)
    env = _load_env_dict(spec.get("env_file"))
    proc = await asyncio.create_subprocess_exec(
        *spec["argv"], cwd=spec["cwd"], env=env,
        stdout=log_fh, stderr=log_fh, stdin=asyncio.subprocess.DEVNULL,
        start_new_session=True,
    )
    log_fh.close()
    return proc.pid


def _is_alive(pid: Optional[int]) -> bool:
    return bool(pid) and psutil.pid_exists(pid)


def _kill_sync(pid: int) -> None:
    try:
        os.kill(pid, signal.SIGTERM)
    except ProcessLookupError:
        return
    for _ in range(20):
        if not psutil.pid_exists(pid):
            return
        time.sleep(0.25)
    try:
        os.kill(pid, signal.SIGKILL)
    except ProcessLookupError:
        pass


async def svc_start(bot_id: str) -> None:
    svc = service_name(bot_id)
    spec = _spec_load(svc)
    if _is_alive(spec.get("pid")):
        spec["should_run"] = True
        _spec_save(svc, spec)
        return
    spec["pid"] = await _spawn(spec)
    spec["should_run"] = True
    spec["result"] = "success"
    _spec_save(svc, spec)


async def svc_stop(bot_id: str) -> None:
    svc = service_name(bot_id)
    spec = _spec_load(svc)
    if spec.get("pid") and _is_alive(spec["pid"]):
        await asyncio.to_thread(_kill_sync, spec["pid"])
    spec["pid"] = None
    spec["should_run"] = False
    _spec_save(svc, spec)


async def svc_restart(bot_id: str) -> None:
    await svc_stop(bot_id)
    await svc_start(bot_id)


async def svc_enable(bot_id: str) -> None:
    svc = service_name(bot_id)
    spec = _spec_load(svc)
    spec["enabled"] = True
    _spec_save(svc, spec)


async def svc_reset_failed(bot_id: str) -> None:
    svc = service_name(bot_id)
    spec = _spec_load(svc)
    spec["crash_timestamps"] = []
    spec["result"] = "success"
    _spec_save(svc, spec)


async def svc_remove(bot_id: str) -> None:
    svc = service_name(bot_id)
    try:
        await svc_stop(bot_id)
    except SupervisorError:
        pass
    p = _spec_path(svc)
    if p.exists():
        p.unlink()


async def svc_status(bot_id: str) -> UnitStatus:
    svc = service_name(bot_id)
    try:
        spec = _spec_load(svc)
    except SupervisorError:
        return UnitStatus("inactive", "dead", 0, "", 0)
    alive = _is_alive(spec.get("pid"))
    return UnitStatus(
        active_state="active" if alive else ("failed" if spec.get("result") == "start-limit-hit" else "inactive"),
        sub_state="running" if alive else ("failed" if spec.get("result") in ("start-limit-hit", "crashed") else "dead"),
        main_pid=spec.get("pid") or 0,
        result=spec.get("result", ""),
        n_restarts=spec.get("restart_count", 0),
    )


async def svc_restart_with_limit_check(bot_id: str) -> bool:
    svc = service_name(bot_id)
    spec = _spec_load(svc)
    now = time.time()
    timestamps = [t for t in spec.get("crash_timestamps", []) if now - t < BURST_WINDOW_SECONDS]
    timestamps.append(now)
    spec["crash_timestamps"] = timestamps
    spec["restart_count"] = spec.get("restart_count", 0) + 1
    if len(timestamps) > BURST_LIMIT:
        spec["result"] = "start-limit-hit"
        spec["should_run"] = False
        spec["pid"] = None
        _spec_save(svc, spec)
        return False
    spec["result"] = "crashed"
    spec["pid"] = await _spawn(spec)
    spec["should_run"] = True
    _spec_save(svc, spec)
    return True


async def update_env_for_spec(bot_id: str) -> None:
    """Refresh the spec's env_file pointer after env vars are edited."""
    svc = service_name(bot_id)
    try:
        spec = _spec_load(svc)
    except SupervisorError:
        return
    env_file = bot_dir(bot_id) / ".env"
    spec["env_file"] = str(env_file) if env_file.exists() else None
    _spec_save(svc, spec)

# ============================================================
# LOGS
# ============================================================
def log_path_for(bot_id: str) -> Path:
    d = bot_dir(bot_id) / "logs"
    d.mkdir(parents=True, exist_ok=True)
    return d / "output.log"


def _tail_sync(bot_id: str, lines: int) -> str:
    path = log_path_for(bot_id)
    if not path.exists() or path.stat().st_size == 0:
        return "(no logs yet)"
    with open(path, "rb") as f:
        block = 4096
        f.seek(0, 2)
        size = f.tell()
        data = b""
        read = 0
        while read < size and data.count(b"\n") <= lines:
            step = min(block, size - read)
            read += step
            f.seek(size - read)
            data = f.read(step) + data
    text = data.decode(errors="replace").splitlines()
    return "\n".join(text[-lines:]) or "(no logs yet)"


async def tail_log(bot_id: str, lines: int = 50) -> str:
    return await asyncio.to_thread(_tail_sync, bot_id, lines)


async def clear_log(bot_id: str) -> None:
    def _clear():
        log_path_for(bot_id).write_text("", encoding="utf-8")
    await asyncio.to_thread(_clear)


# ============================================================
# CONTAINER-AWARE VPS STATS
# ============================================================
_V2_MEM_MAX = Path("/sys/fs/cgroup/memory.max")
_V2_MEM_CUR = Path("/sys/fs/cgroup/memory.current")
_V2_CPU_MAX = Path("/sys/fs/cgroup/cpu.max")
_V2_CPU_STAT = Path("/sys/fs/cgroup/cpu.stat")
_V1_MEM_LIMIT = Path("/sys/fs/cgroup/memory/memory.limit_in_bytes")
_V1_MEM_USAGE = Path("/sys/fs/cgroup/memory/memory.usage_in_bytes")
_V1_CPU_QUOTA = Path("/sys/fs/cgroup/cpu/cpu.cfs_quota_us")
_V1_CPU_PERIOD = Path("/sys/fs/cgroup/cpu/cpu.cfs_period_us")
_V1_CPUACCT_USAGE = Path("/sys/fs/cgroup/cpuacct/cpuacct.usage")
_NO_LIMIT_SENTINEL = 1 << 62


def _read_int(path: Path) -> Optional[int]:
    try:
        text = path.read_text().strip()
    except OSError:
        return None
    if text == "max":
        return None
    try:
        return int(text)
    except ValueError:
        return None


def _detect_cgroup_limits():
    if _V2_MEM_MAX.exists():
        mem = _read_int(_V2_MEM_MAX)
        cpu_cores = None
        if _V2_CPU_MAX.exists():
            try:
                parts = _V2_CPU_MAX.read_text().split()
                if parts and parts[0] != "max":
                    cpu_cores = int(parts[0]) / int(parts[1])
            except (OSError, ValueError, IndexError, ZeroDivisionError):
                pass
        return mem, cpu_cores
    if _V1_MEM_LIMIT.exists():
        mem = _read_int(_V1_MEM_LIMIT)
        if mem is not None and mem >= _NO_LIMIT_SENTINEL:
            mem = None
        cpu_cores = None
        quota, period = _read_int(_V1_CPU_QUOTA), _read_int(_V1_CPU_PERIOD)
        if quota and quota > 0 and period:
            cpu_cores = quota / period
        return mem, cpu_cores
    return None, None


def _cgroup_mem_used() -> Optional[int]:
    if _V2_MEM_CUR.exists():
        return _read_int(_V2_MEM_CUR)
    if _V1_MEM_USAGE.exists():
        return _read_int(_V1_MEM_USAGE)
    return None


def _cgroup_cpu_seconds() -> Optional[float]:
    if _V2_CPU_STAT.exists():
        try:
            for line in _V2_CPU_STAT.read_text().splitlines():
                if line.startswith("usage_usec"):
                    return int(line.split()[1]) / 1_000_000
        except (OSError, ValueError, IndexError):
            return None
        return None
    if _V1_CPUACCT_USAGE.exists():
        val = _read_int(_V1_CPUACCT_USAGE)
        return val / 1_000_000_000 if val is not None else None
    return None


@dataclass
class VpsStats:
    cpu_percent: float; cpu_cores: float; ram_percent: float; ram_used_mb: float
    ram_total_mb: float; swap_percent: float; disk_percent: float; disk_used_gb: float
    disk_total_gb: float; load_avg: tuple; uptime_seconds: float; python_version: str
    hostname: str; scope: str


def _read_vps_stats() -> VpsStats:
    mem_limit, cpu_limit_cores = _detect_cgroup_limits()
    scope = "host"

    vm = psutil.virtual_memory()
    ram_total, ram_used = vm.total, vm.used
    if mem_limit and mem_limit < vm.total:
        scope = "container"
        ram_total = mem_limit
        cg_used = _cgroup_mem_used()
        ram_used = cg_used if cg_used is not None else vm.used
    ram_percent = (ram_used / ram_total * 100) if ram_total else 0.0

    cpu_cores = cpu_limit_cores or (os.cpu_count() or 1)
    if cpu_limit_cores:
        scope = "container"
        u1 = _cgroup_cpu_seconds()
        time.sleep(0.3)
        u2 = _cgroup_cpu_seconds()
        if u1 is not None and u2 is not None:
            cpu_percent = min(100.0, (max(0.0, u2 - u1) / (0.3 * cpu_limit_cores)) * 100)
        else:
            cpu_percent = psutil.cpu_percent(interval=0.0)
    else:
        cpu_percent = psutil.cpu_percent(interval=0.3)

    disk = psutil.disk_usage(str(BASE_DIR))
    swap = psutil.swap_memory()
    try:
        load = os.getloadavg()
    except (OSError, AttributeError):
        load = (0.0, 0.0, 0.0)

    return VpsStats(
        cpu_percent=cpu_percent, cpu_cores=cpu_cores, ram_percent=ram_percent,
        ram_used_mb=ram_used / (1024 * 1024), ram_total_mb=ram_total / (1024 * 1024),
        swap_percent=swap.percent, disk_percent=disk.percent,
        disk_used_gb=disk.used / (1024 ** 3), disk_total_gb=disk.total / (1024 ** 3),
        load_avg=load, uptime_seconds=time.time() - psutil.boot_time(),
        python_version=platform.python_version(), hostname=socket.gethostname(), scope=scope,
    )


async def get_vps_stats() -> VpsStats:
    return await asyncio.to_thread(_read_vps_stats)


# ============================================================
# ENV VARS (per bot, plain .env file)
# ============================================================
def _env_file(bot_id: str) -> Path:
    return bot_dir(bot_id) / ".env"


def _list_env_sync(bot_id: str) -> dict:
    path = _env_file(bot_id)
    if not path.exists():
        return {}
    env = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        env[k.strip()] = v.strip()
    return env


async def list_env(bot_id: str) -> dict:
    return await asyncio.to_thread(_list_env_sync, bot_id)


async def list_env_masked(bot_id: str) -> dict:
    env = await list_env(bot_id)
    return {k: mask_secret(v) for k, v in env.items()}


def _validate_env_key(key: str) -> bool:
    return bool(key) and all(c.isalnum() or c == "_" for c in key) and not key[0].isdigit()


async def set_env(bot_id: str, key: str, value: str) -> None:
    if not _validate_env_key(key):
        raise ValueError("ভুল variable নাম — শুধু letters/digits/underscore ব্যবহার করুন।")
    env = await list_env(bot_id)
    env[key] = value

    def _write():
        _env_file(bot_id).write_text("\n".join(f"{k}={v}" for k, v in env.items()) + "\n", encoding="utf-8")
    await asyncio.to_thread(_write)
    await update_env_for_spec(bot_id)


async def delete_env(bot_id: str, key: str) -> None:
    env = await list_env(bot_id)
    env.pop(key, None)

    def _write():
        content = "\n".join(f"{k}={v}" for k, v in env.items())
        _env_file(bot_id).write_text(content + ("\n" if content else ""), encoding="utf-8")
    await asyncio.to_thread(_write)
    await update_env_for_spec(bot_id)


# ============================================================
# BACKUP / RESTORE (plain zip)
# ============================================================
def _backup_dir(bot_id: str) -> Path:
    d = BACKUPS_DIR / bot_id
    d.mkdir(parents=True, exist_ok=True)
    return d


def _create_backup_sync(bot: BotRecord) -> Path:
    ts = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    dest = _backup_dir(bot.id) / f"{bot.id}_{ts}.zip"
    source_dir = Path(bot.source_path)
    with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as zf:
        for path in source_dir.rglob("*"):
            if path.is_file():
                zf.write(path, arcname=path.relative_to(source_dir))
    return dest


async def create_backup(bot: BotRecord) -> Path:
    return await asyncio.to_thread(_create_backup_sync, bot)


def list_backups(bot_id: str) -> list:
    return sorted(_backup_dir(bot_id).glob("*.zip"), reverse=True)


def _restore_backup_sync(backup_path: Path, target_source_dir: Path) -> None:
    if target_source_dir.exists():
        shutil.rmtree(target_source_dir)
    target_source_dir.mkdir(parents=True)
    with zipfile.ZipFile(backup_path) as zf:
        zf.extractall(target_source_dir)


async def restore_backup(backup_path: Path, target_source_dir: Path) -> None:
    await asyncio.to_thread(_restore_backup_sync, backup_path, target_source_dir)

# ============================================================
# HIGH-LEVEL BOT LIFECYCLE
# ============================================================
async def start_install(name: str) -> BotRecord:
    bot_id = await db_next_bot_id()
    slug = f"{slugify(name)}-{bot_id.split('_')[-1]}"
    source_path = bot_dir(bot_id) / "source"
    venv_path = bot_dir(bot_id) / "venv"
    svc = service_name(bot_id)
    await db_add_bot(bot_id, name, slug, str(source_path), str(venv_path), "", svc)
    return await db_get_bot(bot_id)


async def finalize_install(bot_id: str, main_file: str):
    bot = await db_get_bot(bot_id)
    if bot is None:
        raise RuntimeError("Bot পাওয়া যায়নি।")
    await db_update_bot(bot_id, main_file=main_file)
    await asyncio.to_thread(create_spec, bot_id, main_file, bot.auto_restart)
    await svc_enable(bot_id)
    try:
        await svc_start(bot_id)
    except Exception as exc:
        await db_set_status(bot_id, "failed")
        return False, str(exc)

    for _ in range(5):
        await asyncio.sleep(1.0)
        st = await svc_status(bot_id)
        if st.is_running:
            await db_set_status(bot_id, "running")
            return True, "running"
        if st.sub_state == "failed":
            await db_set_status(bot_id, "failed")
            return False, f"process exited (result: {st.result or 'unknown'})"
    await db_set_status(bot_id, "failed")
    return False, "startup timed out"


async def bot_start(bot_id: str) -> None:
    await svc_reset_failed(bot_id)
    await svc_start(bot_id)
    await db_set_status(bot_id, "running")


async def bot_stop(bot_id: str) -> None:
    await svc_stop(bot_id)
    await db_set_status(bot_id, "stopped")


async def bot_restart(bot_id: str) -> None:
    await svc_reset_failed(bot_id)
    await svc_restart(bot_id)
    await db_set_status(bot_id, "running")


async def bot_delete(bot_id: str) -> None:
    await svc_remove(bot_id)
    await asyncio.to_thread(remove_bot_files, bot_id)
    await db_delete_bot(bot_id)


async def toggle_auto_restart(bot_id: str, enabled: bool) -> None:
    bot = await db_get_bot(bot_id)
    await db_update_bot(bot_id, auto_restart=enabled)
    await asyncio.to_thread(create_spec, bot_id, bot.main_file, enabled)


@dataclass
class FullStatus:
    record: BotRecord
    unit: UnitStatus
    cpu_percent: float
    ram_mb: float
    uptime_seconds: float
    alive: bool


def _process_stats_sync(pid: int):
    if pid <= 0:
        return 0.0, 0.0, 0.0, False
    try:
        proc = psutil.Process(pid)
        cpu = proc.cpu_percent(interval=0.15)
        mem = proc.memory_info().rss / (1024 * 1024)
        uptime = max(0.0, time.time() - proc.create_time())
        return cpu, mem, uptime, True
    except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
        return 0.0, 0.0, 0.0, False


async def get_full_status(bot_id: str) -> FullStatus:
    bot = await db_get_bot(bot_id)
    if bot is None:
        raise RuntimeError("Bot পাওয়া যায়নি — হয়তো delete হয়ে গেছে।")
    unit = await svc_status(bot_id)
    cpu, ram, uptime, alive = await asyncio.to_thread(_process_stats_sync, unit.main_pid)
    return FullStatus(record=bot, unit=unit, cpu_percent=cpu, ram_mb=ram, uptime_seconds=uptime, alive=alive)


# ============================================================
# FSM STATES
# ============================================================
class AddBotFSM(StatesGroup):
    waiting_for_zip = State()
    waiting_for_confirm = State()
    waiting_for_name = State()
    waiting_for_mainfile = State()


class UpdateBotFSM(StatesGroup):
    waiting_for_zip = State()


class DeleteBotFSM(StatesGroup):
    waiting_for_confirm_text = State()


class EnvVarFSM(StatesGroup):
    waiting_for_key = State()
    waiting_for_value = State()


class SearchFSM(StatesGroup):
    waiting_for_query = State()


class SettingsFSM(StatesGroup):
    waiting_for_new_name = State()
    waiting_for_new_description = State()


# ============================================================
# CALLBACK DATA
# ============================================================
class MenuNav(CallbackData, prefix="nav"):
    target: str


class BotOpen(CallbackData, prefix="bopen"):
    bot_id: str


class BotAction(CallbackData, prefix="bact"):
    action: str
    bot_id: str


class BotsPage(CallbackData, prefix="bpage"):
    page: int


class LogsAction(CallbackData, prefix="blog"):
    action: str
    bot_id: str
    lines: int = 50


class ConfirmDelete(CallbackData, prefix="cdel"):
    bot_id: str
    step: str


class MainFileChoice(CallbackData, prefix="mfile"):
    file: str


class InstallConfirm(CallbackData, prefix="binst"):
    value: str


class AutoRestartToggle(CallbackData, prefix="arst"):
    bot_id: str
    value: str


class EnvAction(CallbackData, prefix="env"):
    action: str
    bot_id: str
    idx: int = -1


class SettingsAction(CallbackData, prefix="bset"):
    action: str
    bot_id: str


class BackupAction(CallbackData, prefix="bkup"):
    action: str
    bot_id: str
    idx: int = -1


class UpdateBotAction(CallbackData, prefix="upd"):
    action: str
    bot_id: str

# ============================================================
# KEYBOARDS
# ============================================================
MAIN_MENU_LAYOUT = [
    ["📊 Dashboard", "🤖 My Bots"],
    ["➕ Add Bot", "📈 VPS Stats"],
    ["📜 System Logs", "⚙️ Settings"],
    ["🛠️ Tools", "🙈 Hide Keyboard"],
]
MAIN_MENU_LABELS = {label for row in MAIN_MENU_LAYOUT for label in row}


def main_menu_reply_keyboard() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[[KeyboardButton(text=t) for t in row] for row in MAIN_MENU_LAYOUT],
        resize_keyboard=True, is_persistent=True,
        input_field_placeholder="মেনু থেকে বেছে নিন...",
    )


def back_button(target: str = "dashboard"):
    b = InlineKeyboardBuilder()
    b.button(text="⬅️ Back", callback_data=MenuNav(target=target))
    return b.as_markup()


PAGE_SIZE = 6


def bots_list_keyboard(bots: list, page: int = 0):
    b = InlineKeyboardBuilder()
    start = page * PAGE_SIZE
    for bot in bots[start:start + PAGE_SIZE]:
        b.button(text=f"{status_dot(bot.status)} {bot.name}", callback_data=BotOpen(bot_id=bot.id))
    b.adjust(1)

    total_pages = max(1, (len(bots) + PAGE_SIZE - 1) // PAGE_SIZE)
    if total_pages > 1:
        nav = InlineKeyboardBuilder()
        if page > 0:
            nav.button(text="⬅️", callback_data=BotsPage(page=page - 1))
        nav.button(text=f"{page + 1}/{total_pages}", callback_data=BotsPage(page=page))
        if page < total_pages - 1:
            nav.button(text="➡️", callback_data=BotsPage(page=page + 1))
        nav.adjust(3)
        b.attach(nav)
    return b.as_markup()


def bot_detail_keyboard(bot: BotRecord):
    b = InlineKeyboardBuilder()
    if bot.status == "running":
        b.button(text="⏹️ Stop", callback_data=BotAction(action="stop", bot_id=bot.id))
    else:
        b.button(text="▶️ Start", callback_data=BotAction(action="start", bot_id=bot.id))
    b.button(text="🔄 Restart", callback_data=BotAction(action="restart", bot_id=bot.id))
    b.button(text="📜 Logs", callback_data=BotAction(action="logs", bot_id=bot.id))
    b.button(text="📊 Stats", callback_data=BotAction(action="stats", bot_id=bot.id))
    b.button(text="⚙️ Settings", callback_data=BotAction(action="settings", bot_id=bot.id))
    b.button(text="🗑️ Delete", callback_data=ConfirmDelete(bot_id=bot.id, step="ask"))
    b.button(text="⬅️ Back", callback_data=MenuNav(target="mybots"))
    b.adjust(2, 2, 2, 1)
    return b.as_markup()


def logs_keyboard(bot_id: str, lines: int):
    b = InlineKeyboardBuilder()
    b.button(text="🔄 Refresh", callback_data=LogsAction(action="refresh", bot_id=bot_id, lines=lines))
    b.button(text="📥 Download", callback_data=LogsAction(action="download", bot_id=bot_id, lines=lines))
    b.button(text="🧹 Clear", callback_data=LogsAction(action="clear", bot_id=bot_id, lines=lines))
    b.button(text="20", callback_data=LogsAction(action="more", bot_id=bot_id, lines=20))
    b.button(text="50", callback_data=LogsAction(action="more", bot_id=bot_id, lines=50))
    b.button(text="100", callback_data=LogsAction(action="more", bot_id=bot_id, lines=100))
    b.button(text="⬅️ Back", callback_data=BotAction(action="back", bot_id=bot_id))
    b.adjust(3, 3, 1)
    return b.as_markup()


def delete_confirm_keyboard(bot_id: str):
    b = InlineKeyboardBuilder()
    b.button(text="❌ Cancel", callback_data=ConfirmDelete(bot_id=bot_id, step="no"))
    b.button(text="🗑️ Continue", callback_data=ConfirmDelete(bot_id=bot_id, step="yes"))
    b.adjust(2)
    return b.as_markup()


def install_confirm_keyboard():
    b = InlineKeyboardBuilder()
    b.button(text="✅ Install", callback_data=InstallConfirm(value="yes"))
    b.button(text="❌ Cancel", callback_data=InstallConfirm(value="no"))
    b.adjust(2)
    return b.as_markup()


def update_confirm_keyboard(bot_id: str):
    b = InlineKeyboardBuilder()
    b.button(text="✅ Update", callback_data=UpdateBotAction(action="confirm", bot_id=bot_id))
    b.button(text="❌ Cancel", callback_data=UpdateBotAction(action="cancel", bot_id=bot_id))
    b.adjust(2)
    return b.as_markup()


def main_file_keyboard(candidates: list):
    b = InlineKeyboardBuilder()
    for c in candidates:
        b.button(text=c, callback_data=MainFileChoice(file=c))
    b.adjust(2)
    return b.as_markup()


def settings_keyboard(bot: BotRecord):
    b = InlineKeyboardBuilder()
    b.button(text="🤖 Rename", callback_data=SettingsAction(action="rename", bot_id=bot.id))
    b.button(text="📝 Description", callback_data=SettingsAction(action="describe", bot_id=bot.id))
    label = "🔄 Auto Restart: ON" if bot.auto_restart else "⏸️ Auto Restart: OFF"
    toggle_value = "off" if bot.auto_restart else "on"
    b.button(text=label, callback_data=AutoRestartToggle(bot_id=bot.id, value=toggle_value))
    b.button(text="🌐 Environment", callback_data=SettingsAction(action="env", bot_id=bot.id))
    b.button(text="🔄 Update Bot", callback_data=UpdateBotAction(action="start", bot_id=bot.id))
    b.button(text="💾 Backup", callback_data=BackupAction(action="create", bot_id=bot.id))
    b.button(text="♻️ Restore", callback_data=BackupAction(action="list", bot_id=bot.id))
    b.button(text="⬅️ Back", callback_data=BotAction(action="back", bot_id=bot.id))
    b.adjust(2, 2, 2, 1)
    return b.as_markup()


def env_list_keyboard(bot_id: str, keys: list):
    keys_b = InlineKeyboardBuilder()
    for idx, key in enumerate(keys):
        keys_b.button(text=f"✏️ {key}", callback_data=EnvAction(action="delete", bot_id=bot_id, idx=idx))
    keys_b.adjust(2)
    footer = InlineKeyboardBuilder()
    footer.button(text="➕ Add Variable", callback_data=EnvAction(action="add", bot_id=bot_id))
    footer.button(text="⬅️ Back", callback_data=SettingsAction(action="back", bot_id=bot_id))
    footer.adjust(1)
    b = InlineKeyboardBuilder()
    b.attach(keys_b)
    b.attach(footer)
    return b.as_markup()


def backup_list_keyboard(bot_id: str, count: int):
    b = InlineKeyboardBuilder()
    for idx in range(count):
        b.button(text=f"♻️ Backup #{idx + 1}", callback_data=BackupAction(action="restore", bot_id=bot_id, idx=idx))
    b.button(text="⬅️ Back", callback_data=SettingsAction(action="back", bot_id=bot_id))
    b.adjust(1)
    return b.as_markup()

# ============================================================
# BOT / DISPATCHER SETUP
# ============================================================
bot = Bot(token=BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
dp = Dispatcher(storage=MemoryStorage())


@dp.message.outer_middleware()
async def auth_middleware(handler, event: Message, data):
    user = data.get("event_from_user")
    uid = getattr(user, "id", None)
    if uid is None or uid not in ADMIN_IDS:
        await db_log_audit(uid or 0, "unauthorized_access", None, "denied")
        await event.answer("🚫 আপনি এই bot ব্যবহারের অনুমতিপ্রাপ্ত না।")
        return None
    return await handler(event, data)


@dp.callback_query.outer_middleware()
async def auth_middleware_cb(handler, event: CallbackQuery, data):
    user = data.get("event_from_user")
    uid = getattr(user, "id", None)
    if uid is None or uid not in ADMIN_IDS:
        await db_log_audit(uid or 0, "unauthorized_access", None, "denied")
        await event.answer("🚫 Not authorized.", show_alert=True)
        return None
    return await handler(event, data)

# ============================================================
# HANDLERS — Dashboard / Menu / Start
# ============================================================
def dashboard_text() -> str:
    return (
        f"{banner('VPS Bot Manager')}\n\n"
        f"🖥️ status: <b>online</b>\n"
        f"🔐 access: admin-only\n"
        f"{hr()}\n"
        f"এই bot দিয়ে VPS-এর যেকোনো Python bot install, start/stop, "
        f"monitor আর crash-এ auto-restart করতে পারবেন — কোনো SSH/shell লাগবে না।\n\n"
        f"👇 নিচের মেনু থেকে বেছে নিন।"
    )


@dp.message(Command("cancel"))
async def cmd_cancel(message: Message, state: FSMContext):
    if await state.get_state() is None:
        await message.answer("Cancel করার মতো কিছু চলছে না।")
        return
    await state.clear()
    await message.answer("✅ Cancelled.", reply_markup=main_menu_reply_keyboard())


@dp.message(Command("menu"))
async def cmd_menu(message: Message):
    await message.answer("⌨️ Menu প্রস্তুত।", reply_markup=main_menu_reply_keyboard())


@dp.message(CommandStart())
async def cmd_start(message: Message):
    await message.answer(dashboard_text(), reply_markup=main_menu_reply_keyboard())


@dp.message(F.text == "📊 Dashboard")
async def reply_dashboard(message: Message, state: FSMContext):
    await state.clear()
    await message.answer(dashboard_text())


@dp.callback_query(MenuNav.filter(F.target == "dashboard"))
async def nav_dashboard(callback: CallbackQuery):
    await callback.message.edit_text(dashboard_text())
    await callback.answer()


@dp.message(F.text == "🙈 Hide Keyboard")
async def hide_keyboard(message: Message, state: FSMContext):
    await state.clear()
    b = InlineKeyboardBuilder()
    b.button(text="⌨️ Show Keyboard", callback_data=MenuNav(target="show_keyboard"))
    await message.answer("Keyboard hidden. /menu পাঠান বা নিচে ট্যাপ করুন আবার আনতে।",
                          reply_markup=ReplyKeyboardRemove())
    await message.answer("👇", reply_markup=b.as_markup())


@dp.callback_query(MenuNav.filter(F.target == "show_keyboard"))
async def show_keyboard(callback: CallbackQuery):
    await callback.message.answer("⌨️ Menu ফিরিয়ে আনা হলো।", reply_markup=main_menu_reply_keyboard())
    await callback.answer()


# ============================================================
# HANDLERS — My Bots / Bot Detail
# ============================================================
def _list_text(bots: list) -> str:
    if not bots:
        return f"{banner('My Bots')}\n\nকোনো bot install করা নেই। ➕ Add Bot চাপুন।"
    lines = [f"{status_dot(b.status)} {b.name}" for b in bots]
    return f"{banner('My Bots')}\n\n" + "\n".join(lines)


@dp.callback_query(MenuNav.filter(F.target == "mybots"))
async def nav_mybots(callback: CallbackQuery):
    bots = await db_list_bots()
    await callback.message.edit_text(_list_text(bots), reply_markup=bots_list_keyboard(bots, page=0))
    await callback.answer()


@dp.message(F.text == "🤖 My Bots")
async def reply_mybots(message: Message, state: FSMContext):
    await state.clear()
    bots = await db_list_bots()
    await message.answer(_list_text(bots), reply_markup=bots_list_keyboard(bots, page=0))


@dp.callback_query(BotsPage.filter())
async def nav_bots_page(callback: CallbackQuery, callback_data: BotsPage):
    bots = await db_list_bots()
    await callback.message.edit_text(_list_text(bots), reply_markup=bots_list_keyboard(bots, page=callback_data.page))
    await callback.answer()


def _detail_text(fs: FullStatus) -> str:
    b = fs.record
    lines = [f"{banner(b.name[:20])}\n", f"স্ট্যাটাস: {status_dot(b.status)} {b.status.title()}"]
    if fs.alive:
        lines.append(f"PID: {fs.unit.main_pid}")
        lines.append(f"CPU: {fs.cpu_percent:.1f}%")
        lines.append(f"RAM: {fs.ram_mb:.0f} MB")
        lines.append(f"Uptime: {human_duration_short(fs.uptime_seconds)}")
    lines.append(f"Auto Restart: {'🔄 ON' if b.auto_restart else '⏸️ OFF'}")
    if b.restart_count:
        lines.append(f"Restarts: {b.restart_count}")
    return "\n".join(lines)


@dp.callback_query(BotOpen.filter())
async def open_bot(callback: CallbackQuery, callback_data: BotOpen):
    try:
        fs = await get_full_status(callback_data.bot_id)
    except RuntimeError as exc:
        await callback.answer(str(exc), show_alert=True)
        return
    await callback.message.edit_text(_detail_text(fs), reply_markup=bot_detail_keyboard(fs.record))
    await callback.answer()


@dp.callback_query(BotAction.filter(F.action == "back"))
async def back_to_detail(callback: CallbackQuery, callback_data: BotAction):
    try:
        fs = await get_full_status(callback_data.bot_id)
    except RuntimeError as exc:
        await callback.answer(str(exc), show_alert=True)
        return
    await callback.message.edit_text(_detail_text(fs), reply_markup=bot_detail_keyboard(fs.record))
    await callback.answer()


@dp.callback_query(BotAction.filter(F.action.in_({"start", "stop", "restart"})))
async def bot_lifecycle_action(callback: CallbackQuery, callback_data: BotAction):
    action, bot_id, admin_id = callback_data.action, callback_data.bot_id, callback.from_user.id
    verbs = {"start": "চালু", "stop": "বন্ধ", "restart": "restart"}
    try:
        if action == "start": await bot_start(bot_id)
        elif action == "stop": await bot_stop(bot_id)
        else: await bot_restart(bot_id)
        await db_log_audit(admin_id, action, bot_id, "success")
        await callback.answer(f"✅ Bot {verbs[action]} হলো।")
    except Exception as exc:
        await db_log_audit(admin_id, action, bot_id, "error", str(exc))
        await callback.answer(f"❌ {action} failed: {exc}", show_alert=True)
        return
    fs = await get_full_status(bot_id)
    await callback.message.edit_text(_detail_text(fs), reply_markup=bot_detail_keyboard(fs.record))


@dp.callback_query(ConfirmDelete.filter(F.step == "ask"))
async def delete_ask(callback: CallbackQuery, callback_data: ConfirmDelete):
    bot_rec = await db_get_bot(callback_data.bot_id)
    if bot_rec is None:
        await callback.answer("Bot পাওয়া যায়নি।", show_alert=True)
        return
    text = (f"⚠️ <b>Delete Bot</b>\n\nBot: {bot_rec.name}\n\n"
            f"এতে মুছে যাবে:\n• Source files\n• Virtual environment\n• Logs\n• Process config\n\nনিশ্চিত?")
    await callback.message.edit_text(text, reply_markup=delete_confirm_keyboard(bot_rec.id))
    await callback.answer()


@dp.callback_query(ConfirmDelete.filter(F.step == "no"))
async def delete_cancel(callback: CallbackQuery, callback_data: ConfirmDelete):
    fs = await get_full_status(callback_data.bot_id)
    await callback.message.edit_text(_detail_text(fs), reply_markup=bot_detail_keyboard(fs.record))
    await callback.answer("Cancelled.")


@dp.callback_query(ConfirmDelete.filter(F.step == "yes"))
async def delete_step2(callback: CallbackQuery, callback_data: ConfirmDelete, state: FSMContext):
    await state.update_data(delete_bot_id=callback_data.bot_id)
    await state.set_state(DeleteBotFSM.waiting_for_confirm_text)
    await callback.message.edit_text("নিশ্চিত করতে <b>DELETE</b> লিখুন।", reply_markup=back_button("mybots"))
    await callback.answer()


@dp.message(DeleteBotFSM.waiting_for_confirm_text, ~F.text.in_(MAIN_MENU_LABELS))
async def delete_confirm_text(message: Message, state: FSMContext):
    data = await state.get_data()
    bot_id = data.get("delete_bot_id")
    await state.clear()
    if (message.text or "").strip() != "DELETE":
        await message.answer("Cancelled — টেক্সট মিলেনি।")
        return
    bot_rec = await db_get_bot(bot_id)
    name = bot_rec.name if bot_rec else bot_id
    try:
        await bot_delete(bot_id)
        await db_log_audit(message.from_user.id, "delete", bot_id, "success")
        await message.answer(f"🗑️ <b>{name}</b> delete হয়ে গেছে।")
    except Exception as exc:
        await db_log_audit(message.from_user.id, "delete", bot_id, "error", str(exc))
        await message.answer(f"❌ {exc}")

# ============================================================
# HANDLERS — Add Bot
# ============================================================
@dp.callback_query(MenuNav.filter(F.target == "addbot"))
async def start_add_bot(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    await state.set_state(AddBotFSM.waiting_for_zip)
    await callback.message.edit_text(f"{banner('Add New Bot')}\n\nআপনার bot-এর ZIP ফাইল পাঠান।",
                                      reply_markup=back_button("dashboard"))
    await callback.answer()


@dp.message(F.text == "➕ Add Bot")
async def reply_start_add_bot(message: Message, state: FSMContext):
    await state.clear()
    await state.set_state(AddBotFSM.waiting_for_zip)
    await message.answer(f"{banner('Add New Bot')}\n\nআপনার bot-এর ZIP ফাইল পাঠান।")


@dp.message(AddBotFSM.waiting_for_zip, F.document)
async def receive_zip(message: Message, state: FSMContext):
    doc = message.document
    if not doc.file_name.lower().endswith(".zip"):
        await message.answer("দয়া করে একটা <b>.zip</b> ফাইল পাঠান।")
        return
    if doc.file_size and doc.file_size > MAX_UPLOAD_SIZE_BYTES:
        await message.answer(f"❌ ফাইল বড় বেশি। লিমিট {MAX_UPLOAD_SIZE_MB} MB.")
        return
    await state.update_data(file_id=doc.file_id, file_name=doc.file_name, file_size=doc.file_size or 0)
    await state.set_state(AddBotFSM.waiting_for_confirm)
    await message.answer(
        f"📦 File: {doc.file_name}\n📏 Size: {human_size(doc.file_size or 0)}\n\nContinue?",
        reply_markup=install_confirm_keyboard(),
    )


@dp.message(AddBotFSM.waiting_for_zip, ~F.text.in_(MAIN_MENU_LABELS))
async def receive_zip_wrong_type(message: Message):
    await message.answer("আপনার bot-টা <b>.zip</b> attachment হিসেবে পাঠান।")


@dp.callback_query(AddBotFSM.waiting_for_confirm, InstallConfirm.filter(F.value == "no"))
async def cancel_install(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    await callback.message.edit_text("Cancelled.")
    await callback.answer()


@dp.callback_query(AddBotFSM.waiting_for_confirm, InstallConfirm.filter(F.value == "yes"))
async def confirm_install(callback: CallbackQuery, state: FSMContext):
    await state.set_state(AddBotFSM.waiting_for_name)
    await callback.message.edit_text("এই bot-টার নাম কী দিব?\n\nউদাহরণ: <i>NYX SMS Bot</i>")
    await callback.answer()


@dp.message(AddBotFSM.waiting_for_name, F.text, ~F.text.in_(MAIN_MENU_LABELS))
async def receive_name(message: Message, state: FSMContext):
    name = message.text.strip()
    if not (1 <= len(name) <= 64):
        await message.answer("নাম ১-৬৪ অক্ষরের মধ্যে দিন।")
        return
    data = await state.get_data()
    progress = await message.answer(f"{banner('Installing')}\n\n⏳ Downloading...")

    tg_file = await message.bot.get_file(data["file_id"])
    buf = await message.bot.download_file(tg_file.file_path)
    zip_bytes = buf.read()

    record = await start_install(name)
    lines = [f"{banner('Installing')}\n"]
    ok = True
    async for step in install_pipeline(record.id, zip_bytes):
        icon = "✅" if step.ok else "❌"
        lines.append(f"{icon} {step.label}")
        await progress.edit_text("\n".join(lines))
        if not step.ok:
            ok = False
            lines.append(f"\nError:\n<code>{step.detail[:600]}</code>")
            await progress.edit_text("\n".join(lines), reply_markup=back_button("mybots"))
            await db_log_audit(message.from_user.id, "install", record.id, "error", step.detail[:500])
            break

    if not ok:
        await state.clear()
        return

    candidates = await asyncio.to_thread(_detect_main_files, bot_dir(record.id) / "source")
    if len(candidates) == 1:
        await _finish_install(progress, state, record.id, candidates[0], lines, message.from_user.id)
        return
    if len(candidates) == 0:
        lines.append("\n⚠️ Entry file (bot.py/main.py/app.py/run.py) পাওয়া যায়নি। ফাইলের নাম টাইপ করুন, বা /cancel.")
        await progress.edit_text("\n".join(lines))
        await state.update_data(bot_id=record.id, lines=lines)
        await state.set_state(AddBotFSM.waiting_for_mainfile)
        return

    lines.append("\nSelect Main File")
    await progress.edit_text("\n".join(lines), reply_markup=main_file_keyboard(candidates))
    await state.update_data(bot_id=record.id, lines=lines)
    await state.set_state(AddBotFSM.waiting_for_mainfile)


@dp.callback_query(AddBotFSM.waiting_for_mainfile, MainFileChoice.filter())
async def choose_main_file(callback: CallbackQuery, callback_data: MainFileChoice, state: FSMContext):
    data = await state.get_data()
    await _finish_install(callback.message, state, data["bot_id"], callback_data.file,
                           data.get("lines", []), callback.from_user.id)
    await callback.answer()


@dp.message(AddBotFSM.waiting_for_mainfile, F.text, ~F.text.in_(MAIN_MENU_LABELS))
async def manual_main_file(message: Message, state: FSMContext):
    data = await state.get_data()
    bot_id, filename = data["bot_id"], message.text.strip()
    rec = await db_get_bot(bot_id)
    if rec is None or not (Path(rec.source_path) / filename).is_file():
        await message.answer("এই নামে ফাইল পাওয়া যায়নি। আবার চেষ্টা করুন, বা /cancel.")
        return
    progress = await message.answer("Finishing installation...")
    await _finish_install(progress, state, bot_id, filename, data.get("lines", []), message.from_user.id)


@dp.message(AddBotFSM.waiting_for_name, ~F.text.in_(MAIN_MENU_LABELS))
async def receive_name_wrong_type(message: Message):
    await message.answer("bot-এর নাম text আকারে পাঠান।")


async def _finish_install(progress_msg, state: FSMContext, bot_id: str, main_file: str, lines: list, admin_id: int):
    lines = list(lines) + [f"✅ Entry file: {main_file}", "✅ Process config তৈরি হলো"]
    await progress_msg.edit_text("\n".join(lines) + "\n\n⏳ Starting & health-check করা হচ্ছে...")
    ok, reason = await finalize_install(bot_id, main_file)
    await db_log_audit(admin_id, "install", bot_id, "success" if ok else "error", reason)
    tail = "\n🚀 Bot সফলভাবে চালু হয়েছে।" if ok else f"\n\n❌ Bot চালু হয়নি।\n\nReason:\n<code>{reason}</code>"
    await progress_msg.edit_text("\n".join(lines) + tail, reply_markup=back_button("mybots"))
    await state.clear()

# ============================================================
# HANDLERS — VPS Stats / Bot Stats
# ============================================================
async def render_vps_stats() -> str:
    stats = await get_vps_stats()
    bots = await db_list_bots()
    running = sum(1 for b in bots if b.status == "running")
    stopped = len(bots) - running
    scope_label = "🐳 Container limit" if stats.scope == "container" else "🖥️ Host (no container limit)"

    return (
        f"{banner('VPS Status')}\n<i>{scope_label}</i>\n\n"
        f"⚙️ CPU ({stats.cpu_cores:.2g} core{'s' if stats.cpu_cores != 1 else ''})\n"
        f"{progress_bar(stats.cpu_percent)} {stats.cpu_percent:.0f}%\n\n"
        f"🧠 RAM\n{progress_bar(stats.ram_percent)} {stats.ram_percent:.0f}%  "
        f"({stats.ram_used_mb:.0f}/{stats.ram_total_mb:.0f} MB)\n\n"
        f"💾 Disk\n{progress_bar(stats.disk_percent)} {stats.disk_percent:.0f}%  "
        f"({stats.disk_used_gb:.1f}/{stats.disk_total_gb:.1f} GB)\n\n"
        f"{hr()}\n"
        f"🔁 Swap: {stats.swap_percent:.0f}%\n"
        f"📈 Load: {stats.load_avg[0]:.2f}, {stats.load_avg[1]:.2f}, {stats.load_avg[2]:.2f}\n"
        f"⏱️ Uptime: {human_duration_long(stats.uptime_seconds)}\n"
        f"🐍 Python: {stats.python_version}\n"
        f"🖥️ Host: {stats.hostname}\n\n"
        f"🟢 Running: {running}   🔴 Stopped: {stopped}"
    )


@dp.callback_query(MenuNav.filter(F.target == "vpsstats"))
async def nav_vps_stats(callback: CallbackQuery):
    await callback.message.edit_text(await render_vps_stats())
    await callback.answer()


@dp.message(F.text == "📈 VPS Stats")
async def reply_vps_stats(message: Message, state: FSMContext):
    await state.clear()
    await message.answer(await render_vps_stats())


@dp.callback_query(BotAction.filter(F.action == "stats"))
async def bot_stats(callback: CallbackQuery, callback_data: BotAction):
    fs = await get_full_status(callback_data.bot_id)
    if fs.alive:
        body = f"PID: {fs.unit.main_pid}\nCPU: {fs.cpu_percent:.1f}%\nRAM: {fs.ram_mb:.0f} MB\nUptime: {human_duration_short(fs.uptime_seconds)}\n"
    else:
        body = "Process এখন running না।\n"
    text = (f"{banner('Bot Stats')}\n\n{fs.record.name}\n\n{body}"
            f"Restart count: {fs.unit.n_restarts}\nAuto Restart: {'ON' if fs.record.auto_restart else 'OFF'}")
    await callback.message.edit_text(text, reply_markup=bot_detail_keyboard(fs.record))
    await callback.answer()


# ============================================================
# HANDLERS — Logs
# ============================================================
async def _render_logs(callback: CallbackQuery, bot_id: str, lines: int):
    bot_rec = await db_get_bot(bot_id)
    if bot_rec is None:
        await callback.answer("Bot পাওয়া যায়নি।", show_alert=True)
        return
    content = await tail_log(bot_id, lines)
    text = f"{banner('Bot Logs')}\n{bot_rec.name} — last {lines} lines\n\n<code>{truncate(content, 3500)}</code>"
    await callback.message.edit_text(text, reply_markup=logs_keyboard(bot_id, lines))


@dp.callback_query(BotAction.filter(F.action == "logs"))
async def open_logs(callback: CallbackQuery, callback_data: BotAction):
    await _render_logs(callback, callback_data.bot_id, 50)
    await callback.answer()


@dp.callback_query(LogsAction.filter(F.action.in_({"refresh", "more"})))
async def refresh_logs(callback: CallbackQuery, callback_data: LogsAction):
    await _render_logs(callback, callback_data.bot_id, callback_data.lines)
    await callback.answer("Refreshed" if callback_data.action == "refresh" else None)


@dp.callback_query(LogsAction.filter(F.action == "download"))
async def download_logs(callback: CallbackQuery, callback_data: LogsAction):
    path = log_path_for(callback_data.bot_id)
    if not path.exists() or path.stat().st_size == 0:
        await callback.answer("Log এখনো খালি।", show_alert=True)
        return
    bot_rec = await db_get_bot(callback_data.bot_id)
    filename = f"{(bot_rec.slug if bot_rec else callback_data.bot_id)}.log.txt"
    await callback.message.answer_document(FSInputFile(path, filename=filename))
    await callback.answer()


@dp.callback_query(LogsAction.filter(F.action == "clear"))
async def clear_logs_cb(callback: CallbackQuery, callback_data: LogsAction):
    await clear_log(callback_data.bot_id)
    await db_log_audit(callback.from_user.id, "clear_logs", callback_data.bot_id, "success")
    await _render_logs(callback, callback_data.bot_id, callback_data.lines)
    await callback.answer("🧹 Cleared.")

# ============================================================
# HANDLERS — Settings / Env / Update / Backup
# ============================================================
def _settings_text(bot_rec: BotRecord) -> str:
    return (f"{banner('Settings')}\n{bot_rec.name}\n\n"
            f"📄 Main File: {bot_rec.main_file}\n"
            f"📝 Description: {bot_rec.description or '(none)'}\n"
            f"🔄 Auto Restart: {'ON' if bot_rec.auto_restart else 'OFF'}")


@dp.callback_query(BotAction.filter(F.action == "settings"))
async def open_settings(callback: CallbackQuery, callback_data: BotAction):
    bot_rec = await db_get_bot(callback_data.bot_id)
    if bot_rec is None:
        await callback.answer("Bot পাওয়া যায়নি।", show_alert=True)
        return
    await callback.message.edit_text(_settings_text(bot_rec), reply_markup=settings_keyboard(bot_rec))
    await callback.answer()


@dp.callback_query(SettingsAction.filter(F.action == "back"))
async def settings_back(callback: CallbackQuery, callback_data: SettingsAction):
    bot_rec = await db_get_bot(callback_data.bot_id)
    if bot_rec is None:
        await callback.answer("Bot পাওয়া যায়নি।", show_alert=True)
        return
    await callback.message.edit_text(_settings_text(bot_rec), reply_markup=settings_keyboard(bot_rec))
    await callback.answer()


@dp.callback_query(AutoRestartToggle.filter())
async def toggle_auto_restart_cb(callback: CallbackQuery, callback_data: AutoRestartToggle):
    enabled = callback_data.value == "on"
    await toggle_auto_restart(callback_data.bot_id, enabled)
    await db_log_audit(callback.from_user.id, "auto_restart_toggle", callback_data.bot_id, "on" if enabled else "off")
    bot_rec = await db_get_bot(callback_data.bot_id)
    await callback.message.edit_text(_settings_text(bot_rec), reply_markup=settings_keyboard(bot_rec))
    await callback.answer("🔄 আপডেট হলো।")


@dp.callback_query(SettingsAction.filter(F.action == "rename"))
async def ask_rename(callback: CallbackQuery, callback_data: SettingsAction, state: FSMContext):
    await state.update_data(target_bot_id=callback_data.bot_id)
    await state.set_state(SettingsFSM.waiting_for_new_name)
    await callback.message.edit_text("নতুন নাম পাঠান।")
    await callback.answer()


@dp.message(SettingsFSM.waiting_for_new_name, F.text, ~F.text.in_(MAIN_MENU_LABELS))
async def do_rename(message: Message, state: FSMContext):
    data = await state.get_data()
    bot_id = data["target_bot_id"]
    await db_update_bot(bot_id, name=message.text.strip()[:64])
    await state.clear()
    bot_rec = await db_get_bot(bot_id)
    await message.answer(_settings_text(bot_rec), reply_markup=settings_keyboard(bot_rec))


@dp.callback_query(SettingsAction.filter(F.action == "describe"))
async def ask_describe(callback: CallbackQuery, callback_data: SettingsAction, state: FSMContext):
    await state.update_data(target_bot_id=callback_data.bot_id)
    await state.set_state(SettingsFSM.waiting_for_new_description)
    await callback.message.edit_text("একটা ছোট description পাঠান।")
    await callback.answer()


@dp.message(SettingsFSM.waiting_for_new_description, F.text, ~F.text.in_(MAIN_MENU_LABELS))
async def do_describe(message: Message, state: FSMContext):
    data = await state.get_data()
    bot_id = data["target_bot_id"]
    await db_update_bot(bot_id, description=message.text.strip()[:256])
    await state.clear()
    bot_rec = await db_get_bot(bot_id)
    await message.answer(_settings_text(bot_rec), reply_markup=settings_keyboard(bot_rec))


@dp.callback_query(SettingsAction.filter(F.action == "env"))
async def open_env(callback: CallbackQuery, callback_data: SettingsAction):
    env = await list_env_masked(callback_data.bot_id)
    body = "\n".join(f"{k} = {v}" for k, v in env.items()) or "(কোনো variable নেই)"
    text = f"{banner('Environment')}\n\n{body}\n\nDelete করতে variable-এ ট্যাপ করুন।"
    await callback.message.edit_text(text, reply_markup=env_list_keyboard(callback_data.bot_id, list(env.keys())))
    await callback.answer()


@dp.callback_query(EnvAction.filter(F.action == "add"))
async def ask_env_key(callback: CallbackQuery, callback_data: EnvAction, state: FSMContext):
    await state.update_data(target_bot_id=callback_data.bot_id)
    await state.set_state(EnvVarFSM.waiting_for_key)
    await callback.message.edit_text("Variable-এর নাম পাঠান (যেমন <code>API_KEY</code>)।")
    await callback.answer()


@dp.message(EnvVarFSM.waiting_for_key, F.text, ~F.text.in_(MAIN_MENU_LABELS))
async def receive_env_key(message: Message, state: FSMContext):
    await state.update_data(env_key=message.text.strip())
    await state.set_state(EnvVarFSM.waiting_for_value)
    await message.answer("এখন value পাঠান।")


@dp.message(EnvVarFSM.waiting_for_value, F.text, ~F.text.in_(MAIN_MENU_LABELS))
async def receive_env_value(message: Message, state: FSMContext):
    data = await state.get_data()
    bot_id, key = data["target_bot_id"], data["env_key"]
    try:
        await set_env(bot_id, key, message.text.strip())
    except ValueError as exc:
        await message.answer(f"❌ {exc}")
        await state.clear()
        return
    await state.clear()
    await db_log_audit(message.from_user.id, "env_set", bot_id, "success")
    await message.answer(f"✅ {key} সেভ হলো। Apply করতে bot restart করুন।")
    env = await list_env_masked(bot_id)
    text = f"{banner('Environment')}\n\n" + "\n".join(f"{k} = {v}" for k, v in env.items())
    await message.answer(text, reply_markup=env_list_keyboard(bot_id, list(env.keys())))


@dp.callback_query(EnvAction.filter(F.action == "delete"))
async def delete_env_var(callback: CallbackQuery, callback_data: EnvAction):
    env = await list_env(callback_data.bot_id)
    keys = list(env.keys())
    if 0 <= callback_data.idx < len(keys):
        await delete_env(callback_data.bot_id, keys[callback_data.idx])
        await db_log_audit(callback.from_user.id, "env_delete", callback_data.bot_id, "success")
    env = await list_env_masked(callback_data.bot_id)
    body = "\n".join(f"{k} = {v}" for k, v in env.items()) or "(কোনো variable নেই)"
    await callback.message.edit_text(f"{banner('Environment')}\n\n{body}",
                                      reply_markup=env_list_keyboard(callback_data.bot_id, list(env.keys())))
    await callback.answer("Deleted.")


@dp.callback_query(UpdateBotAction.filter(F.action == "start"))
async def start_update(callback: CallbackQuery, callback_data: UpdateBotAction, state: FSMContext):
    await state.update_data(update_bot_id=callback_data.bot_id)
    await state.set_state(UpdateBotFSM.waiting_for_zip)
    await callback.message.edit_text(f"{banner('Update Bot')}\n\nনতুন ZIP পাঠান। Bot stop→backup→update→restart হবে।")
    await callback.answer()


@dp.message(UpdateBotFSM.waiting_for_zip, F.document)
async def update_receive_zip(message: Message, state: FSMContext):
    doc = message.document
    if not doc.file_name.lower().endswith(".zip"):
        await message.answer("দয়া করে .zip পাঠান।")
        return
    await state.update_data(update_file_id=doc.file_id)
    data = await state.get_data()
    await message.answer(f"📦 {doc.file_name} পাওয়া গেছে। Update করবেন?",
                          reply_markup=update_confirm_keyboard(data["update_bot_id"]))


@dp.callback_query(UpdateBotAction.filter(F.action == "cancel"))
async def update_cancel(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    await callback.message.edit_text("Update cancelled.")
    await callback.answer()


@dp.callback_query(UpdateBotAction.filter(F.action == "confirm"))
async def update_confirm(callback: CallbackQuery, callback_data: UpdateBotAction, state: FSMContext):
    bot_id = callback_data.bot_id
    data = await state.get_data()
    file_id = data.get("update_file_id")
    await state.clear()
    bot_rec = await db_get_bot(bot_id)
    if bot_rec is None or file_id is None:
        await callback.answer("Update করার কিছু নেই।", show_alert=True)
        return

    msg = callback.message
    await msg.edit_text(f"{banner('Updating')}\n\n⏳ Stopping...")
    try: await bot_stop(bot_id)
    except Exception: pass

    await msg.edit_text(f"{banner('Updating')}\n\n✅ Stopped\n⏳ Backing up...")
    try: await create_backup(bot_rec)
    except Exception: pass

    tg_file = await callback.bot.get_file(file_id)
    buf = await callback.bot.download_file(tg_file.file_path)
    zip_bytes = buf.read()

    lines = [f"{banner('Updating')}\n", "✅ Stopped", "✅ Backed up"]
    ok = True
    async for step in install_pipeline(bot_id, zip_bytes):
        icon = "✅" if step.ok else "❌"
        lines.append(f"{icon} {step.label}")
        await msg.edit_text("\n".join(lines))
        if not step.ok:
            ok = False
            lines.append(f"\nError:\n<code>{step.detail[:500]}</code>\n\nRolling back...")
            await msg.edit_text("\n".join(lines))
            backups = list_backups(bot_id)
            if backups:
                await restore_backup(backups[0], bot_dir(bot_id) / "source")
            try: await bot_start(bot_id)
            except Exception: pass
            break

    if not ok:
        await db_log_audit(callback.from_user.id, "update", bot_id, "rolled_back")
        await callback.answer()
        return

    candidates = await asyncio.to_thread(_detect_main_files, bot_dir(bot_id) / "source")
    main_file = bot_rec.main_file if bot_rec.main_file in candidates else (candidates[0] if candidates else bot_rec.main_file)
    ok, reason = await finalize_install(bot_id, main_file)
    await db_log_audit(callback.from_user.id, "update", bot_id, "success" if ok else "error", reason)
    tail = "\n🚀 Update complete, bot restarted." if ok else f"\n❌ Health check failed: {reason}"
    await msg.edit_text("\n".join(lines) + tail)
    await callback.answer()


@dp.callback_query(BackupAction.filter(F.action == "create"))
async def create_backup_cb(callback: CallbackQuery, callback_data: BackupAction):
    bot_rec = await db_get_bot(callback_data.bot_id)
    if bot_rec is None:
        await callback.answer("Bot পাওয়া যায়নি।", show_alert=True)
        return
    path = await create_backup(bot_rec)
    await db_log_audit(callback.from_user.id, "backup_create", bot_rec.id, "success")
    await callback.answer(f"💾 Backup saved: {path.name}", show_alert=True)


@dp.callback_query(BackupAction.filter(F.action == "list"))
async def list_backups_cb(callback: CallbackQuery, callback_data: BackupAction):
    backups = list_backups(callback_data.bot_id)
    if not backups:
        await callback.answer("কোনো backup নেই।", show_alert=True)
        return
    text = f"{banner('Restore Backup')}\n\n" + "\n".join(f"{i+1}. {b.name}" for i, b in enumerate(backups))
    await callback.message.edit_text(text, reply_markup=backup_list_keyboard(callback_data.bot_id, len(backups)))
    await callback.answer()


@dp.callback_query(BackupAction.filter(F.action == "restore"))
async def restore_backup_cb(callback: CallbackQuery, callback_data: BackupAction):
    bot_rec = await db_get_bot(callback_data.bot_id)
    backups = list_backups(callback_data.bot_id)
    if bot_rec is None or not (0 <= callback_data.idx < len(backups)):
        await callback.answer("Backup পাওয়া যায়নি।", show_alert=True)
        return
    try: await bot_stop(bot_rec.id)
    except Exception: pass
    await restore_backup(backups[callback_data.idx], bot_dir(bot_rec.id) / "source")
    try: await bot_start(bot_rec.id)
    except Exception: pass
    await db_log_audit(callback.from_user.id, "backup_restore", bot_rec.id, "success")
    await callback.answer("♻️ Restored & restarted.", show_alert=True)

# ============================================================
# HANDLERS — Search / Audit / System Logs / Manager Settings / Tools
# ============================================================
@dp.callback_query(MenuNav.filter(F.target == "search"))
async def start_search(callback: CallbackQuery, state: FSMContext):
    await state.set_state(SearchFSM.waiting_for_query)
    await callback.message.edit_text("🔎 Bot-এর নামের অংশ পাঠান।", reply_markup=back_button("dashboard"))
    await callback.answer()


@dp.message(SearchFSM.waiting_for_query, F.text, ~F.text.in_(MAIN_MENU_LABELS))
async def do_search(message: Message, state: FSMContext):
    query = message.text.strip()
    results = await db_search_bots(query)
    await state.clear()
    if not results:
        await message.answer(f"“{query}” মিলে এমন bot নেই।", reply_markup=back_button("dashboard"))
        return
    lines = [f"{status_dot(b.status)} {b.name}" for b in results]
    text = f"{banner('Search Results')}\n\n" + "\n".join(lines)
    await message.answer(text, reply_markup=bots_list_keyboard(results, page=0))


@dp.callback_query(MenuNav.filter(F.target == "audit"))
async def nav_audit(callback: CallbackQuery):
    logs = await db_get_audit_logs(limit=15)
    if not logs:
        text = f"{banner('Audit Log')}\n\nকোনো action রেকর্ড করা নেই।"
    else:
        lines = [f"• <code>{e['timestamp']}</code> — {e['action']} ({e['bot_id'] or '-'}) → {e['result']}" for e in logs]
        text = f"{banner('Audit Log')}\n(last 15)\n\n" + "\n".join(lines)
    await callback.message.edit_text(text, reply_markup=back_button("dashboard"))
    await callback.answer()


def _syslogs_text() -> str:
    manager_log = LOGS_DIR / "manager.log"
    content = "(manager.log এখনো তৈরি হয়নি)"
    if manager_log.exists():
        lines = manager_log.read_text(encoding="utf-8", errors="replace").splitlines()
        content = "\n".join(lines[-40:]) or content
    return f"{banner('System Logs')}\nLast 40 lines\n\n<code>{truncate(content, 3500)}</code>"


@dp.callback_query(MenuNav.filter(F.target == "syslogs"))
async def nav_syslogs(callback: CallbackQuery):
    await callback.message.edit_text(_syslogs_text(), reply_markup=back_button("dashboard"))
    await callback.answer()


@dp.message(F.text == "📜 System Logs")
async def reply_syslogs(message: Message, state: FSMContext):
    await state.clear()
    await message.answer(_syslogs_text())


def _manager_settings_text() -> str:
    return (f"{banner('Manager Settings')}\n\n"
            f"Base dir: <code>{BASE_DIR}</code>\n"
            f"Process backend: supervisor (no root/systemd needed)\n"
            f"Log level: {LOG_LEVEL}\n"
            f"Max upload size: {MAX_UPLOAD_SIZE_MB} MB\n"
            f"Admins configured: {len(ADMIN_IDS)}\n\n"
            f"এসব বদলাতে bot.py-এর CONFIG সেকশন এডিট করে manager restart করুন।")


@dp.callback_query(MenuNav.filter(F.target == "settings"))
async def nav_settings(callback: CallbackQuery):
    await callback.message.edit_text(_manager_settings_text(), reply_markup=back_button("dashboard"))
    await callback.answer()


@dp.message(F.text == "⚙️ Settings")
async def reply_settings(message: Message, state: FSMContext):
    await state.clear()
    await message.answer(_manager_settings_text())


def _tools_keyboard():
    b = InlineKeyboardBuilder()
    b.button(text="🔎 Search Bot", callback_data=MenuNav(target="search"))
    b.button(text="📜 Audit Log", callback_data=MenuNav(target="audit"))
    b.adjust(1, 1)
    return b.as_markup()


@dp.callback_query(MenuNav.filter(F.target == "tools"))
async def nav_tools(callback: CallbackQuery):
    await callback.message.edit_text(f"{banner('Tools')}", reply_markup=_tools_keyboard())
    await callback.answer()


@dp.message(F.text == "🛠️ Tools")
async def reply_tools(message: Message, state: FSMContext):
    await state.clear()
    await message.answer(f"{banner('Tools')}", reply_markup=_tools_keyboard())

# ============================================================
# WATCHER — crash detection, restart-limit protection, notify
# ============================================================
async def watch_loop():
    known_active = {}
    while True:
        try:
            await _poll_once(known_active)
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("watcher iteration failed")
        await asyncio.sleep(15)


async def _poll_once(known_active: dict):
    bots = await db_list_bots()
    for rec in bots:
        if rec.status not in ("running", "failed", "crashed"):
            continue
        st = await svc_status(rec.id)
        was_active = known_active.get(rec.id, st.is_running)
        known_active[rec.id] = st.is_running

        if st.n_restarts != rec.restart_count:
            await db_set_restart_count(rec.id, st.n_restarts)

        if st.is_start_limit_hit:
            await db_set_status(rec.id, "stopped")
            await _notify(f"⚠️ <b>বারবার crash করছে।</b>\n\n🤖 {rec.name}\n\nRestart limit reached — bot বন্ধ করে দেওয়া হয়েছে।")
            continue

        if was_active and not st.is_running:
            restarted = False
            if rec.auto_restart:
                restarted = await svc_restart_with_limit_check(rec.id)
                if not restarted:
                    await db_set_status(rec.id, "stopped")
                    await _notify(f"⚠️ <b>বারবার crash করছে।</b>\n\n🤖 {rec.name}\n\nRestart limit reached — bot বন্ধ করে দেওয়া হয়েছে।")
                    continue
            await db_set_status(rec.id, "crashed" if rec.auto_restart else "stopped")
            when = datetime.now().strftime("%H:%M:%S")
            await _notify(
                f"🔴 <b>Bot crashed</b>\n\n🤖 {rec.name}\n⏰ {when}\n"
                f"🔄 Auto Restart: {'Enabled' if rec.auto_restart else 'Disabled'}\n\n"
                f"{'♻️ Restarted.' if restarted else ('♻️ Restarting...' if rec.auto_restart else 'বন্ধ আছে।')}"
            )
        elif not was_active and st.is_running:
            await db_set_status(rec.id, "running")


async def _notify(text: str):
    for admin_id in ADMIN_IDS:
        try:
            await bot.send_message(admin_id, text)
        except Exception:
            logger.warning("failed to notify admin %s", admin_id)


# ============================================================
# ERROR HANDLER
# ============================================================
@dp.errors()
async def on_error(event: ErrorEvent):
    if isinstance(event.exception, TelegramBadRequest) and "message is not modified" in str(event.exception).lower():
        return True
    logger.exception("unhandled error", exc_info=event.exception)
    update = event.update
    chat_id = None
    if update.message:
        chat_id = update.message.chat.id
    elif update.callback_query and update.callback_query.message:
        chat_id = update.callback_query.message.chat.id
    if chat_id is not None:
        try:
            await bot.send_message(chat_id, "❌ কিছু একটা সমস্যা হয়েছে। Log-এ লেখা হয়েছে, আবার চেষ্টা করুন।")
        except Exception:
            pass
    return True


# ============================================================
# MAIN
# ============================================================
async def main():
    if BOT_TOKEN == "PUT_YOUR_BOT_TOKEN_HERE" or not BOT_TOKEN:
        raise SystemExit("bot.py-এর উপরে CONFIG সেকশনে BOT_TOKEN বসান আগে।")
    if not ADMIN_IDS:
        raise SystemExit("bot.py-এর উপরে CONFIG সেকশনে ADMIN_IDS বসান আগে।")

    await asyncio.to_thread(_db_init)
    logger.info("VPS Bot Manager starting (base_dir=%s)", BASE_DIR)

    watcher_task = asyncio.create_task(watch_loop())
    try:
        await dp.start_polling(bot)
    finally:
        watcher_task.cancel()
        await bot.session.close()


if __name__ == "__main__":
    asyncio.run(main())

#!/usr/bin/env bash
set -u
cd "$(dirname "${BASH_SOURCE[0]}")"

if [ -f logs/watchdog.pid ]; then
    pid="$(cat logs/watchdog.pid)"
    kill "$pid" 2>/dev/null && echo "Stopped watchdog (pid $pid)"
    rm -f logs/watchdog.pid
fi

pkill -f "\.venv/bin/python bot\.py" 2>/dev/null && echo "Stopped bot.py"
echo "Done."
